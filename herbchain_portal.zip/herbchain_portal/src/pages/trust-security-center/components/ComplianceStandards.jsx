import React from 'react';
import Icon from '../../../components/AppIcon';

const ComplianceStandards = () => {
  const complianceStandards = [
    {
      icon: "Shield",
      category: "Data Protection",
      standards: [
        {
          name: "GDPR",
          description: "European General Data Protection Regulation compliance for user privacy rights",
          status: "Certified",
          region: "European Union"
        },
        {
          name: "CCPA",
          description: "California Consumer Privacy Act compliance for data transparency",
          status: "Certified",
          region: "California, USA"
        },
        {
          name: "ISO 27001",
          description: "International standard for information security management systems",
          status: "Certified",
          region: "Global"
        }
      ]
    },
    {
      icon: "Leaf",
      category: "Food Safety",
      standards: [
        {
          name: "FDA FSMA",
          description: "Food Safety Modernization Act compliance for agricultural traceability",
          status: "Compliant",
          region: "United States"
        },
        {
          name: "EU Organic",
          description: "European Union organic farming and certification standards",
          status: "Recognized",
          region: "European Union"
        },
        {
          name: "HACCP",
          description: "Hazard Analysis Critical Control Points for food safety management",
          status: "Aligned",
          region: "Global"
        }
      ]
    },
    {
      icon: "Globe",
      category: "International Trade",
      standards: [
        {
          name: "WTO TBT",
          description: "World Trade Organization Technical Barriers to Trade agreement",
          status: "Compliant",
          region: "Global"
        },
        {
          name: "Codex Alimentarius",
          description: "International food standards for consumer protection",
          status: "Aligned",
          region: "Global"
        },
        {
          name: "GS1 Standards",
          description: "Global standards for supply chain visibility and traceability",
          status: "Implemented",
          region: "Global"
        }
      ]
    }
  ];

  const certifications = [
    {
      icon: "Award",
      title: "SOC 2 Type II",
      issuer: "AICPA",
      validUntil: "December 2025",
      description: "Security, availability, and confidentiality controls audit"
    },
    {
      icon: "Shield",
      title: "ISO 27001:2013",
      issuer: "BSI Group",
      validUntil: "March 2026",
      description: "Information security management system certification"
    },
    {
      icon: "FileCheck",
      title: "GDPR Compliance",
      issuer: "DPO Services",
      validUntil: "Ongoing",
      description: "European data protection regulation compliance"
    },
    {
      icon: "Leaf",
      title: "Organic Certification",
      issuer: "USDA",
      validUntil: "September 2025",
      description: "Organic farming standards recognition program"
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Certified':
        return 'text-success bg-success/10';
      case 'Compliant':
        return 'text-primary bg-primary/10';
      case 'Recognized':
        return 'text-accent bg-accent/10';
      case 'Aligned':
        return 'text-warning bg-warning/10';
      case 'Implemented':
        return 'text-secondary bg-secondary/10';
      default:
        return 'text-text-secondary bg-muted';
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Compliance Standards
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            HerbChain meets international standards for data protection, food safety, and agricultural compliance across multiple jurisdictions.
          </p>
        </div>

        {/* Compliance Categories */}
        <div className="space-y-12 mb-16">
          {complianceStandards?.map((category, categoryIndex) => (
            <div key={categoryIndex} className="bg-card rounded-2xl p-8 border border-border">
              <div className="flex items-center space-x-4 mb-8">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name={category?.icon} size={24} className="text-primary" />
                </div>
                <h3 className="font-headline text-2xl font-semibold text-text-primary">
                  {category?.category}
                </h3>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {category?.standards?.map((standard, standardIndex) => (
                  <div key={standardIndex} className="bg-background rounded-xl p-6 border border-border">
                    <div className="flex items-start justify-between mb-4">
                      <h4 className="font-semibold text-text-primary text-lg">{standard?.name}</h4>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(standard?.status)}`}>
                        {standard?.status}
                      </span>
                    </div>
                    <p className="text-text-secondary mb-4 leading-relaxed">
                      {standard?.description}
                    </p>
                    <div className="flex items-center space-x-2 text-sm text-text-secondary">
                      <Icon name="MapPin" size={14} />
                      <span>{standard?.region}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Active Certifications */}
        <div>
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Active Certifications
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {certifications?.map((cert, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border text-center hover:shadow-warm transition-smooth">
                <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Icon name={cert?.icon} size={32} className="text-primary" />
                </div>
                <h4 className="font-semibold text-text-primary mb-2">{cert?.title}</h4>
                <p className="text-sm text-text-secondary mb-3">{cert?.description}</p>
                <div className="space-y-2">
                  <div className="text-xs text-text-secondary">
                    <strong>Issued by:</strong> {cert?.issuer}
                  </div>
                  <div className="text-xs text-text-secondary">
                    <strong>Valid until:</strong> {cert?.validUntil}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance Contact */}
        <div className="bg-primary/5 rounded-2xl p-8 mt-16 text-center">
          <Icon name="FileText" size={48} className="text-primary mx-auto mb-4" />
          <h3 className="font-headline text-xl font-semibold text-text-primary mb-4">
            Need Compliance Documentation?
          </h3>
          <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
            Access detailed compliance reports, audit results, and certification documents for your regulatory requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-smooth flex items-center justify-center">
              <Icon name="Download" size={16} className="mr-2" />
              Download Reports
            </button>
            <button className="px-6 py-3 border border-primary text-primary rounded-lg hover:bg-primary/5 transition-smooth flex items-center justify-center">
              <Icon name="Mail" size={16} className="mr-2" />
              Contact Compliance Team
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComplianceStandards;