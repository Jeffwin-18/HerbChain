import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityOverview = () => {
  const securityStats = [
    {
      icon: "Shield",
      value: "256-bit",
      label: "Encryption Standard",
      description: "Military-grade encryption protects all data"
    },
    {
      icon: "Database",
      value: "99.9%",
      label: "Uptime Guarantee",
      description: "Reliable blockchain infrastructure"
    },
    {
      icon: "Users",
      value: "50K+",
      label: "Protected Users",
      description: "Farmers and consumers trust our platform"
    },
    {
      icon: "Award",
      value: "ISO 27001",
      label: "Certified Security",
      description: "International security standards compliance"
    }
  ];

  const securityLayers = [
    {
      icon: "Globe",
      title: "Network Security",
      description: "DDoS protection, firewall systems, and secure CDN delivery ensure platform availability and protection against attacks."
    },
    {
      icon: "Database",
      title: "Data Encryption",
      description: "End-to-end encryption for all data transmission and storage, with blockchain immutability for critical records."
    },
    {
      icon: "UserCheck",
      title: "Access Control",
      description: "Multi-factor authentication, role-based permissions, and secure session management protect user accounts."
    },
    {
      icon: "Eye",
      title: "Monitoring & Auditing",
      description: "24/7 security monitoring, automated threat detection, and comprehensive audit trails for all activities."
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Security Stats */}
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Security by the Numbers
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto mb-12">
            Our commitment to security is measurable and transparent
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {securityStats?.map((stat, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border hover:shadow-warm transition-smooth">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Icon name={stat?.icon} size={24} className="text-primary" />
                </div>
                <div className="text-3xl font-bold text-primary mb-2">{stat?.value}</div>
                <div className="font-semibold text-text-primary mb-2">{stat?.label}</div>
                <p className="text-sm text-text-secondary">{stat?.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Security Layers */}
        <div>
          <div className="text-center mb-12">
            <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Multi-Layer Security Architecture
            </h2>
            <p className="text-lg text-text-secondary max-w-3xl mx-auto">
              Like protecting a valuable harvest, our security uses multiple layers of defense to safeguard your agricultural data and blockchain records.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {securityLayers?.map((layer, index) => (
              <div key={index} className="bg-card rounded-xl p-8 border border-border hover:shadow-warm transition-smooth">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={layer?.icon} size={24} className="text-primary" />
                  </div>
                  <div>
                    <h3 className="font-headline text-xl font-semibold text-text-primary mb-3">
                      {layer?.title}
                    </h3>
                    <p className="text-text-secondary leading-relaxed">
                      {layer?.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityOverview;