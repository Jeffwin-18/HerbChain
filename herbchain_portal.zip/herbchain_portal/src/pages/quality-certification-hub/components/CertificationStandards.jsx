import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CertificationStandards = () => {
  const [activeStandard, setActiveStandard] = useState('organic');

  const standards = [
    {
      id: 'organic',
      name: 'Organic Certification',
      icon: 'Leaf',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      description: 'Herbs grown without synthetic pesticides, fertilizers, or GMOs using natural farming methods.',
      requirements: [
        'No synthetic pesticides or fertilizers',
        'Non-GMO seeds and practices',
        'Soil health maintenance',
        'Regular third-party inspections',
        'Detailed record keeping',
        'Buffer zones from conventional farms'
      ],
      benefits: [
        'Higher nutritional value',
        'Better taste and aroma',
        'Environmental sustainability',
        'Consumer health protection'
      ],
      timeToAchieve: '3 years',
      renewalPeriod: 'Annual',
      averageCost: '$2,500 - $5,000'
    },
    {
      id: 'sustainable',
      name: 'Sustainable Farming',
      icon: 'Recycle',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-200',
      description: 'Environmentally responsible farming practices that preserve resources for future generations.',
      requirements: [
        'Water conservation systems',
        'Renewable energy usage',
        'Waste reduction programs',
        'Biodiversity preservation',
        'Carbon footprint monitoring',
        'Community engagement'
      ],
      benefits: [
        'Reduced environmental impact',
        'Long-term soil fertility',
        'Water resource protection',
        'Climate change mitigation'
      ],
      timeToAchieve: '2 years',
      renewalPeriod: 'Bi-annual',
      averageCost: '$1,800 - $3,500'
    },
    {
      id: 'premium',
      name: 'Premium Quality',
      icon: 'Star',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
      description: 'Highest quality standards for exceptional herbs with superior characteristics.',
      requirements: [
        'Superior genetic varieties',
        'Optimal growing conditions',
        'Precise harvesting timing',
        'Advanced processing methods',
        'Quality testing protocols',
        'Traceability systems'
      ],
      benefits: [
        'Maximum potency and flavor',
        'Consistent quality batches',
        'Premium market positioning',
        'Higher profit margins'
      ],
      timeToAchieve: '1 year',
      renewalPeriod: 'Annual',
      averageCost: '$3,000 - $6,000'
    },
    {
      id: 'fairtrade',
      name: 'Fair Trade',
      icon: 'Handshake',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      description: 'Ethical trading practices ensuring fair compensation and working conditions for farmers.',
      requirements: [
        'Fair pricing guarantees',
        'Safe working conditions',
        'Community development funds',
        'Democratic organization',
        'Environmental protection',
        'Long-term trading relationships'
      ],
      benefits: [
        'Stable income for farmers',
        'Community development',
        'Social responsibility',
        'Consumer trust building'
      ],
      timeToAchieve: '18 months',
      renewalPeriod: 'Tri-annual',
      averageCost: '$2,000 - $4,000'
    }
  ];

  const currentStandard = standards?.find(s => s?.id === activeStandard);

  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Certification Standards
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Understanding our rigorous quality standards that ensure every certified herb meets the highest levels of excellence, sustainability, and ethical production.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Standards Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-xl border border-border p-6 sticky top-24">
              <h3 className="font-headline text-xl font-bold text-text-primary mb-6">
                Quality Standards
              </h3>
              <div className="space-y-2">
                {standards?.map((standard) => (
                  <button
                    key={standard?.id}
                    onClick={() => setActiveStandard(standard?.id)}
                    className={`w-full flex items-center space-x-3 p-4 rounded-lg text-left transition-smooth ${
                      activeStandard === standard?.id
                        ? `${standard?.bgColor} ${standard?.borderColor} border-2`
                        : 'hover:bg-muted border-2 border-transparent'
                    }`}
                  >
                    <div className={`p-2 rounded-lg ${standard?.bgColor}`}>
                      <Icon name={standard?.icon} size={20} className={standard?.color} />
                    </div>
                    <div>
                      <div className={`font-semibold ${
                        activeStandard === standard?.id ? standard?.color : 'text-text-primary'
                      }`}>
                        {standard?.name}
                      </div>
                      <div className="text-sm text-text-secondary">
                        {standard?.timeToAchieve} to achieve
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Standard Details */}
          <div className="lg:col-span-2">
            {currentStandard && (
              <div className="bg-card rounded-xl border border-border overflow-hidden">
                {/* Header */}
                <div className={`${currentStandard?.bgColor} p-8 border-b border-border`}>
                  <div className="flex items-center space-x-4 mb-4">
                    <div className={`p-3 rounded-xl bg-white shadow-sm`}>
                      <Icon name={currentStandard?.icon} size={32} className={currentStandard?.color} />
                    </div>
                    <div>
                      <h3 className="font-headline text-2xl font-bold text-text-primary">
                        {currentStandard?.name}
                      </h3>
                      <p className="text-text-secondary">
                        {currentStandard?.description}
                      </p>
                    </div>
                  </div>

                  {/* Quick Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-white/70 rounded-lg p-4">
                      <div className="text-sm text-text-secondary">Time to Achieve</div>
                      <div className="font-semibold text-text-primary">{currentStandard?.timeToAchieve}</div>
                    </div>
                    <div className="bg-white/70 rounded-lg p-4">
                      <div className="text-sm text-text-secondary">Renewal</div>
                      <div className="font-semibold text-text-primary">{currentStandard?.renewalPeriod}</div>
                    </div>
                    <div className="bg-white/70 rounded-lg p-4">
                      <div className="text-sm text-text-secondary">Average Cost</div>
                      <div className="font-semibold text-text-primary">{currentStandard?.averageCost}</div>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Requirements */}
                    <div>
                      <h4 className="font-headline text-lg font-bold text-text-primary mb-4 flex items-center">
                        <Icon name="CheckCircle" size={20} className="mr-2 text-primary" />
                        Requirements
                      </h4>
                      <ul className="space-y-3">
                        {currentStandard?.requirements?.map((requirement, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <Icon name="Check" size={16} className="text-primary mt-0.5 flex-shrink-0" />
                            <span className="text-text-secondary">{requirement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Benefits */}
                    <div>
                      <h4 className="font-headline text-lg font-bold text-text-primary mb-4 flex items-center">
                        <Icon name="Award" size={20} className="mr-2 text-secondary" />
                        Benefits
                      </h4>
                      <ul className="space-y-3">
                        {currentStandard?.benefits?.map((benefit, index) => (
                          <li key={index} className="flex items-start space-x-3">
                            <Icon name="Star" size={16} className="text-secondary mt-0.5 flex-shrink-0" />
                            <span className="text-text-secondary">{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-4 mt-8 pt-8 border-t border-border">
                    <Button variant="default" className="flex-1">
                      <Icon name="FileText" size={16} className="mr-2" />
                      Download Requirements Guide
                    </Button>
                    <Button variant="outline" className="flex-1">
                      <Icon name="MessageCircle" size={16} className="mr-2" />
                      Contact Certification Team
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Certification Process */}
        <div className="mt-16">
          <div className="text-center mb-12">
            <h3 className="font-headline text-2xl lg:text-3xl font-bold text-text-primary mb-4">
              Certification Process
            </h3>
            <p className="text-text-secondary max-w-2xl mx-auto">
              Our streamlined certification process ensures thorough evaluation while minimizing complexity for farmers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: 1,
                title: 'Application',
                description: 'Submit initial application with farm details and current practices',
                icon: 'FileText',
                color: 'text-blue-600',
                bgColor: 'bg-blue-50'
              },
              {
                step: 2,
                title: 'Assessment',
                description: 'On-site inspection and evaluation of farming practices and facilities',
                icon: 'Search',
                color: 'text-orange-600',
                bgColor: 'bg-orange-50'
              },
              {
                step: 3,
                title: 'Verification',
                description: 'Third-party verification and blockchain record creation',
                icon: 'Shield',
                color: 'text-purple-600',
                bgColor: 'bg-purple-50'
              },
              {
                step: 4,
                title: 'Certification',
                description: 'Certificate issuance and marketplace listing activation',
                icon: 'Award',
                color: 'text-green-600',
                bgColor: 'bg-green-50'
              }
            ]?.map((process) => (
              <div key={process.step} className="text-center">
                <div className={`w-16 h-16 ${process.bgColor} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <Icon name={process.icon} size={24} className={process.color} />
                </div>
                <div className="text-sm font-semibold text-text-secondary mb-2">
                  Step {process.step}
                </div>
                <h4 className="font-headline text-lg font-bold text-text-primary mb-2">
                  {process.title}
                </h4>
                <p className="text-sm text-text-secondary">
                  {process.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CertificationStandards;