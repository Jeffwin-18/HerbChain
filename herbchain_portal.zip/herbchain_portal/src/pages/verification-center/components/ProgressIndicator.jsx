import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressIndicator = ({ currentStep, totalSteps }) => {
  const steps = [
    { id: 1, title: 'Farm Profile', icon: 'MapPin' },
    { id: 2, title: 'Harvest Data', icon: 'Leaf' },
    { id: 3, title: 'Quality Docs', icon: 'FileText' },
    { id: 4, title: 'Blockchain', icon: 'Zap' },
    { id: 5, title: 'QR Code', icon: 'QrCode' }
  ];

  return (
    <div className="bg-card rounded-xl border border-border p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-text-primary">
          Verification Progress
        </h3>
        <span className="text-sm text-text-secondary">
          Step {currentStep} of {totalSteps}
        </span>
      </div>
      <div className="flex items-center justify-between">
        {steps?.map((step, index) => {
          const isActive = step?.id === currentStep;
          const isCompleted = step?.id < currentStep;
          const isUpcoming = step?.id > currentStep;
          
          return (
            <React.Fragment key={step?.id}>
              <div className="flex flex-col items-center space-y-2">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isActive ? 'bg-primary text-white ring-4 ring-primary/20' :
                  isCompleted ? 'bg-success text-white': 'bg-muted text-text-secondary'
                }`}>
                  {isCompleted ? (
                    <Icon name="Check" size={20} />
                  ) : (
                    <Icon name={step?.icon} size={20} />
                  )}
                </div>
                
                <div className="text-center">
                  <div className={`text-xs font-medium ${
                    isActive ? 'text-primary' :
                    isCompleted ? 'text-success': 'text-text-secondary'
                  }`}>
                    {step?.title}
                  </div>
                </div>
              </div>
              {index < steps?.length - 1 && (
                <div className={`flex-1 h-0.5 mx-2 transition-all ${
                  step?.id < currentStep ? 'bg-success' : 'bg-muted'
                }`} />
              )}
            </React.Fragment>
          );
        })}
      </div>
      {/* Progress Bar */}
      <div className="mt-4">
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-primary to-success h-2 rounded-full transition-all duration-500"
            style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ProgressIndicator;