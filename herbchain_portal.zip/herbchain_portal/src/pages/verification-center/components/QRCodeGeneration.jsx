import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QRCodeGeneration = ({ onBack, verificationData }) => {
  const [qrCode, setQrCode] = useState('');
  const [isGenerating, setIsGenerating] = useState(true);
  const [downloadFormat, setDownloadFormat] = useState('png');

  const verificationId = 'VH2024-0892';
  const qrCodeUrl = `https://herbchain.com/verify/${verificationId}`;

  useEffect(() => {
    // Simulate QR code generation
    const timer = setTimeout(() => {
      // Generate mock QR code SVG
      const qrCodeSvg = `data:image/svg+xml;base64,${btoa(`
        <svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
          <rect width="200" height="200" fill="white"/>
          <g fill="black">
            <!-- Mock QR code pattern -->
            <rect x="20" y="20" width="20" height="20"/>
            <rect x="60" y="20" width="20" height="20"/>
            <rect x="100" y="20" width="20" height="20"/>
            <rect x="140" y="20" width="20" height="20"/>
            <rect x="20" y="60" width="20" height="20"/>
            <rect x="140" y="60" width="20" height="20"/>
            <rect x="20" y="100" width="20" height="20"/>
            <rect x="60" y="100" width="20" height="20"/>
            <rect x="100" y="100" width="20" height="20"/>
            <rect x="140" y="100" width="20" height="20"/>
            <rect x="20" y="140" width="20" height="20"/>
            <rect x="60" y="140" width="20" height="20"/>
            <rect x="100" y="140" width="20" height="20"/>
            <rect x="140" y="140" width="20" height="20"/>
            <!-- Corner markers -->
            <rect x="10" y="10" width="40" height="40" fill="none" stroke="black" stroke-width="4"/>
            <rect x="150" y="10" width="40" height="40" fill="none" stroke="black" stroke-width="4"/>
            <rect x="10" y="150" width="40" height="40" fill="none" stroke="black" stroke-width="4"/>
            <rect x="20" y="20" width="20" height="20"/>
            <rect x="160" y="20" width="20" height="20"/>
            <rect x="20" y="160" width="20" height="20"/>
          </g>
        </svg>
      `)}`;
      
      setQrCode(qrCodeSvg);
      setIsGenerating(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleDownload = (format) => {
    // Simulate download
    const link = document.createElement('a');
    link.download = `herbchain-verification-${verificationId}.${format}`;
    link.href = qrCode;
    link?.click();
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    printWindow?.document?.write(`
      <html>
        <head>
          <title>HerbChain Verification - ${verificationId}</title>
          <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 20px; }
            .qr-container { margin: 20px 0; }
            .verification-info { margin-top: 20px; }
          </style>
        </head>
        <body>
          <h1>HerbChain Verification</h1>
          <div class="qr-container">
            <img src="${qrCode}" alt="QR Code" style="width: 200px; height: 200px;" />
          </div>
          <div class="verification-info">
            <p><strong>Verification ID:</strong> ${verificationId}</p>
            <p><strong>Farm:</strong> Green Valley Herbs</p>
            <p><strong>Product:</strong> Organic Basil - Premium Grade A</p>
            <p><strong>Harvest Date:</strong> September 5, 2024</p>
            <p><strong>Scan to verify authenticity</strong></p>
          </div>
        </body>
      </html>
    `);
    printWindow?.document?.close();
    printWindow?.print();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'HerbChain Verification',
          text: `Verify this organic herb harvest: ${verificationId}`,
          url: qrCodeUrl
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard?.writeText(qrCodeUrl);
      alert('Verification URL copied to clipboard!');
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
          <Icon name="QrCode" size={20} className="text-success" />
        </div>
        <div>
          <h2 className="text-xl font-headline font-semibold text-text-primary">
            QR Code Generated
          </h2>
          <p className="text-sm text-text-secondary">
            Your verification QR code is ready for use
          </p>
        </div>
      </div>

      {/* Success Banner */}
      <div className="bg-gradient-to-r from-success/10 to-primary/10 border border-success/20 rounded-lg p-6 mb-8">
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center">
            <Icon name="CheckCircle" size={32} className="text-white" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-success mb-1">
              Verification Complete!
            </h3>
            <p className="text-text-secondary">
              Your harvest is now blockchain-verified and ready for market
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-lg font-bold text-primary">
              {verificationId}
            </div>
            <div className="text-sm text-text-secondary">
              Verification ID
            </div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-success">
              +$127.50
            </div>
            <div className="text-sm text-text-secondary">
              Premium Value
            </div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-accent">
              98.7%
            </div>
            <div className="text-sm text-text-secondary">
              Quality Score
            </div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-primary">
              Block #15,847,392
            </div>
            <div className="text-sm text-text-secondary">
              Blockchain Record
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* QR Code Display */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border-2 border-border p-8 text-center">
            {isGenerating ? (
              <div className="flex flex-col items-center space-y-4">
                <div className="w-48 h-48 bg-muted rounded-lg flex items-center justify-center">
                  <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
                <p className="text-text-secondary">Generating QR code...</p>
              </div>
            ) : (
              <div className="space-y-4">
                <img 
                  src={qrCode} 
                  alt="Verification QR Code" 
                  className="w-48 h-48 mx-auto border border-border rounded-lg"
                />
                <div className="space-y-2">
                  <p className="font-medium text-text-primary">
                    Verification ID: {verificationId}
                  </p>
                  <p className="text-sm text-text-secondary">
                    Scan to verify product authenticity
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* QR Code Actions */}
          {!isGenerating && (
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => handleDownload('png')}
                iconName="Download"
                iconPosition="left"
                size="sm"
              >
                Download PNG
              </Button>
              
              <Button
                variant="outline"
                onClick={() => handleDownload('svg')}
                iconName="Download"
                iconPosition="left"
                size="sm"
              >
                Download SVG
              </Button>
              
              <Button
                variant="outline"
                onClick={handlePrint}
                iconName="Printer"
                iconPosition="left"
                size="sm"
              >
                Print
              </Button>
              
              <Button
                variant="outline"
                onClick={handleShare}
                iconName="Share"
                iconPosition="left"
                size="sm"
              >
                Share
              </Button>
            </div>
          )}
        </div>

        {/* Verification Details */}
        <div className="space-y-6">
          <div className="bg-muted/50 rounded-lg p-6">
            <h3 className="font-semibold text-text-primary mb-4">
              Verification Details
            </h3>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-text-secondary">Farm Name:</span>
                <span className="text-text-primary font-medium">Green Valley Herbs</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Owner:</span>
                <span className="text-text-primary">Sarah Johnson</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Location:</span>
                <span className="text-text-primary">Sonoma County, CA</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Herb Variety:</span>
                <span className="text-text-primary">Organic Basil</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Quality Grade:</span>
                <span className="text-text-primary">Premium Grade A</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Harvest Date:</span>
                <span className="text-text-primary">September 5, 2024</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Quantity:</span>
                <span className="text-text-primary">50 lbs</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Certification:</span>
                <span className="text-text-primary">USDA Organic</span>
              </div>
            </div>
          </div>

          <div className="bg-primary/5 border border-primary/20 rounded-lg p-6">
            <h3 className="font-semibold text-primary mb-4">
              Blockchain Information
            </h3>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-text-secondary">Transaction Hash:</span>
                <span className="text-text-primary font-mono text-xs">
                  0x7a8b9c1d...8a9b
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Block Number:</span>
                <span className="text-text-primary">15,847,392</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Network:</span>
                <span className="text-text-primary">HerbChain Mainnet</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Timestamp:</span>
                <span className="text-text-primary">Sep 9, 2024 06:57 UTC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-text-secondary">Verification URL:</span>
                <span className="text-text-primary text-xs break-all">
                  {qrCodeUrl}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-success/5 border border-success/20 rounded-lg p-6">
            <h3 className="font-semibold text-success mb-4">
              Next Steps
            </h3>
            
            <ul className="space-y-2 text-sm text-text-secondary">
              <li className="flex items-start space-x-2">
                <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                <span>Print QR codes for product packaging</span>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                <span>Share verification with buyers and distributors</span>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                <span>Track premium pricing in your dashboard</span>
              </li>
              <li className="flex items-start space-x-2">
                <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
                <span>Monitor consumer verification scans</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-8">
        <Button
          variant="outline"
          onClick={onBack}
          iconName="ArrowLeft"
          iconPosition="left"
        >
          Back
        </Button>
        
        <div className="flex space-x-3">
          <Button
            variant="outline"
            onClick={() => window.location.href = '/verification-center'}
            iconName="Plus"
            iconPosition="left"
          >
            New Verification
          </Button>
          
          <Button
            variant="default"
            onClick={() => window.location.href = '/homepage'}
            iconName="Home"
            iconPosition="left"
            className="bg-success hover:bg-success/90"
          >
            Return to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default QRCodeGeneration;