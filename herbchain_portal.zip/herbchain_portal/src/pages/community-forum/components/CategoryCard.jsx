import React from 'react';
import Icon from '../../../components/AppIcon';

const CategoryCard = ({ category, onClick }) => {
  return (
    <div 
      onClick={() => onClick(category)}
      className="bg-card border border-border rounded-lg p-6 cursor-pointer transition-smooth hover:shadow-warm hover:border-primary/20 group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`p-3 rounded-lg ${category?.bgColor} group-hover:scale-110 transition-smooth`}>
            <Icon name={category?.icon} size={24} className={category?.iconColor} />
          </div>
          <div>
            <h3 className="font-headline font-semibold text-lg text-text-primary group-hover:text-primary transition-smooth">
              {category?.name}
            </h3>
            <p className="text-sm text-text-secondary">
              {category?.postCount} posts
            </p>
          </div>
        </div>
        <Icon name="ChevronRight" size={20} className="text-text-secondary group-hover:text-primary transition-smooth" />
      </div>
      <p className="text-text-secondary text-sm mb-4 line-clamp-2">
        {category?.description}
      </p>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="flex -space-x-2">
            {category?.recentUsers?.slice(0, 3)?.map((user, index) => (
              <div key={index} className="w-6 h-6 rounded-full bg-primary/10 border-2 border-background flex items-center justify-center">
                <span className="text-xs font-medium text-primary">
                  {user?.name?.charAt(0)}
                </span>
              </div>
            ))}
          </div>
          <span className="text-xs text-text-secondary">
            {category?.activeUsers} active
          </span>
        </div>
        
        <div className="flex items-center space-x-1 text-xs text-text-secondary">
          <Icon name="Clock" size={14} />
          <span>{category?.lastActivity}</span>
        </div>
      </div>
    </div>
  );
};

export default CategoryCard;