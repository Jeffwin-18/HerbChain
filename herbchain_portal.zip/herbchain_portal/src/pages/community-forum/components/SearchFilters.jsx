import React from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const SearchFilters = ({ 
  searchQuery, 
  setSearchQuery, 
  selectedCategory, 
  setSelectedCategory, 
  selectedSort, 
  setSelectedSort,
  onClearFilters 
}) => {
  const categoryOptions = [
    { value: 'all', label: 'All Categories' },
    { value: 'farmer-stories', label: 'Farmer Success Stories' },
    { value: 'growing-tips', label: 'Growing Tips & Techniques' },
    { value: 'blockchain', label: 'Blockchain Questions' },
    { value: 'consumer-feedback', label: 'Consumer Feedback' },
    { value: 'industry-news', label: 'Industry News' },
    { value: 'general', label: 'General Discussion' }
  ];

  const sortOptions = [
    { value: 'recent', label: 'Most Recent' },
    { value: 'popular', label: 'Most Popular' },
    { value: 'replies', label: 'Most Replies' },
    { value: 'likes', label: 'Most Liked' },
    { value: 'views', label: 'Most Viewed' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Search" size={20} className="text-primary" />
        <h3 className="font-headline font-semibold text-lg text-text-primary">
          Search & Filter
        </h3>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-1">
          <Input
            type="search"
            placeholder="Search discussions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full"
          />
        </div>
        
        <div>
          <Select
            placeholder="Select category"
            options={categoryOptions}
            value={selectedCategory}
            onChange={setSelectedCategory}
          />
        </div>
        
        <div className="flex space-x-2">
          <div className="flex-1">
            <Select
              placeholder="Sort by"
              options={sortOptions}
              value={selectedSort}
              onChange={setSelectedSort}
            />
          </div>
          
          <Button
            variant="outline"
            size="default"
            onClick={onClearFilters}
            iconName="X"
            className="flex-shrink-0"
          >
            Clear
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;