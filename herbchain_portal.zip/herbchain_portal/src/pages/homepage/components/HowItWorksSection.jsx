import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const HowItWorksSection = () => {
  const [activeStep, setActiveStep] = useState(0);

  const steps = [
    {
      id: 1,
      title: "Farm Registration",
      subtitle: "Join the Network",
      description: "Farmers register their operations, providing detailed information about their growing practices, certifications, and herb varieties. Our verification team conducts initial assessments to ensure quality standards.",
      icon: "Sprout",
      color: "primary",
      features: [
        "Digital farm profile creation",
        "Certification document upload",
        "Growing practice verification",
        "Quality standard assessment"
      ],
      stats: { label: "Registered Farms", value: "342+" }
    },
    {
      id: 2,
      title: "Blockchain Verification",
      subtitle: "Immutable Records",
      description: "Each herb batch receives a unique blockchain record containing harvest data, quality metrics, and certification details. Smart contracts ensure data integrity and create an unalterable chain of custody.",
      icon: "Database",
      color: "accent",
      features: [
        "Immutable blockchain records",
        "Smart contract automation",
        "Real-time data validation",
        "Cryptographic security"
      ],
      stats: { label: "Verifications", value: "28,956+" }
    },
    {
      id: 3,
      title: "Consumer Trust",
      subtitle: "Transparent Access",
      description: "Consumers scan QR codes to access complete herb histories - from soil conditions to harvest dates. This transparency builds trust and allows informed purchasing decisions based on verified quality data.",
      icon: "Shield",
      color: "conversion",
      features: [
        "QR code instant access",
        "Complete traceability",
        "Quality transparency",
        "Informed decision making"
      ],
      stats: { label: "QR Scans", value: "156,789+" }
    }
  ];

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Icon name="Workflow" size={16} />
            <span>Simple Process</span>
          </div>
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            How It Works
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Our three-step process transforms traditional herb supply chains into transparent, 
            blockchain-verified networks that benefit farmers and consumers alike.
          </p>
        </div>

        {/* Desktop View */}
        <div className="hidden lg:block">
          <div className="relative">
            {/* Connection Lines */}
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-accent to-conversion transform -translate-y-1/2 z-0"></div>
            
            {/* Steps */}
            <div className="relative z-10 grid grid-cols-3 gap-8">
              {steps?.map((step, index) => (
                <div
                  key={step?.id}
                  className={`relative bg-card rounded-2xl p-8 border-2 transition-all duration-500 cursor-pointer ${
                    activeStep === index 
                      ? `border-${step?.color} shadow-warm scale-105` 
                      : 'border-border hover:border-border/60 hover:shadow-md'
                  }`}
                  onClick={() => setActiveStep(index)}
                >
                  {/* Step Number */}
                  <div className={`absolute -top-4 left-8 w-8 h-8 rounded-full border-4 border-background flex items-center justify-center text-sm font-bold ${
                    step?.color === 'primary' ? 'bg-primary text-white' :
                    step?.color === 'accent'? 'bg-accent text-white' : 'bg-conversion text-white'
                  }`}>
                    {step?.id}
                  </div>

                  {/* Icon */}
                  <div className={`w-16 h-16 rounded-xl flex items-center justify-center mb-6 ${
                    step?.color === 'primary' ? 'bg-primary/10' :
                    step?.color === 'accent'? 'bg-accent/10' : 'bg-conversion/10'
                  }`}>
                    <Icon 
                      name={step?.icon} 
                      size={32} 
                      className={
                        step?.color === 'primary' ? 'text-primary' :
                        step?.color === 'accent'? 'text-accent' : 'text-conversion'
                      } 
                    />
                  </div>

                  {/* Content */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-headline text-xl font-bold text-text-primary mb-1">
                        {step?.title}
                      </h3>
                      <p className={`text-sm font-medium ${
                        step?.color === 'primary' ? 'text-primary' :
                        step?.color === 'accent'? 'text-accent' : 'text-conversion'
                      }`}>
                        {step?.subtitle}
                      </p>
                    </div>

                    <p className="text-text-secondary text-sm leading-relaxed">
                      {step?.description}
                    </p>

                    {/* Features */}
                    <ul className="space-y-2">
                      {step?.features?.map((feature, idx) => (
                        <li key={idx} className="flex items-center space-x-2 text-sm">
                          <Icon name="Check" size={14} className="text-conversion flex-shrink-0" />
                          <span className="text-text-secondary">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Stats */}
                    <div className={`pt-4 border-t border-border`}>
                      <div className={`text-2xl font-bold font-headline ${
                        step?.color === 'primary' ? 'text-primary' :
                        step?.color === 'accent'? 'text-accent' : 'text-conversion'
                      }`}>
                        {step?.stats?.value}
                      </div>
                      <div className="text-xs text-text-secondary font-medium">
                        {step?.stats?.label}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Mobile View */}
        <div className="lg:hidden space-y-6">
          {steps?.map((step, index) => (
            <div
              key={step?.id}
              className="bg-card rounded-xl p-6 border border-border shadow-sm"
            >
              <div className="flex items-start space-x-4">
                {/* Step Number & Icon */}
                <div className="flex-shrink-0">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                    step?.color === 'primary' ? 'bg-primary/10' :
                    step?.color === 'accent'? 'bg-accent/10' : 'bg-conversion/10'
                  }`}>
                    <Icon 
                      name={step?.icon} 
                      size={24} 
                      className={
                        step?.color === 'primary' ? 'text-primary' :
                        step?.color === 'accent'? 'text-accent' : 'text-conversion'
                      } 
                    />
                  </div>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white mt-2 mx-auto ${
                    step?.color === 'primary' ? 'bg-primary' :
                    step?.color === 'accent'? 'bg-accent' : 'bg-conversion'
                  }`}>
                    {step?.id}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 space-y-3">
                  <div>
                    <h3 className="font-headline text-lg font-bold text-text-primary">
                      {step?.title}
                    </h3>
                    <p className={`text-sm font-medium ${
                      step?.color === 'primary' ? 'text-primary' :
                      step?.color === 'accent'? 'text-accent' : 'text-conversion'
                    }`}>
                      {step?.subtitle}
                    </p>
                  </div>

                  <p className="text-text-secondary text-sm leading-relaxed">
                    {step?.description}
                  </p>

                  <div className={`inline-flex items-center space-x-2 text-sm font-medium ${
                    step?.color === 'primary' ? 'text-primary' :
                    step?.color === 'accent'? 'text-accent' : 'text-conversion'
                  }`}>
                    <span>{step?.stats?.value}</span>
                    <span className="text-text-secondary">{step?.stats?.label}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-4 bg-card rounded-xl p-6 border border-border shadow-warm">
            <div className="text-left">
              <h3 className="font-headline text-lg font-semibold text-text-primary mb-1">
                Ready to Get Started?
              </h3>
              <p className="text-text-secondary text-sm">
                Join our network of verified farms and transparent consumers
              </p>
            </div>
            <div className="flex space-x-3">
              <button className="px-4 py-2 bg-primary text-white rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                For Farmers
              </button>
              <button className="px-4 py-2 bg-accent text-white rounded-lg text-sm font-medium hover:bg-accent/90 transition-colors">
                For Consumers
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;