import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PrivacyPolicy = () => {
  const [viewMode, setViewMode] = useState('simple'); // 'simple' or 'legal'

  const dataTypes = [
    {
      icon: "User",
      category: "Personal Information",
      simple: "Your name, email, and contact details when you register",
      legal: "Personal identifiers including full name, email address, phone number, and mailing address collected during account registration and profile management.",
      usage: "Account creation, communication, and support services"
    },
    {
      icon: "MapPin",
      category: "Farm Location Data",
      simple: "Your farm's location to verify authenticity and enable traceability",
      legal: "Geolocation data including GPS coordinates, farm boundaries, and regional identifiers necessary for supply chain verification and compliance reporting.",
      usage: "Traceability verification, compliance reporting, and fraud prevention"
    },
    {
      icon: "Leaf",
      category: "Agricultural Data",
      simple: "Information about your crops, harvest dates, and farming practices",
      legal: "Agricultural production data including crop types, planting and harvest dates, farming methodologies, quality assessments, and certification records.",
      usage: "Quality verification, blockchain recording, and consumer transparency"
    },
    {
      icon: "Activity",
      category: "Platform Usage",
      simple: "How you use our platform to improve your experience",
      legal: "Technical data including IP addresses, browser information, device identifiers, usage patterns, and interaction logs for platform optimization and security.",
      usage: "Platform improvement, security monitoring, and user experience optimization"
    }
  ];

  const userRights = [
    {
      icon: "Eye",
      title: "Access Your Data",
      description: "Request a complete copy of all personal data we have about you"
    },
    {
      icon: "Edit",
      title: "Correct Information",
      description: "Update or correct any inaccurate personal information"
    },
    {
      icon: "Download",
      title: "Data Portability",
      description: "Export your data in a machine-readable format"
    },
    {
      icon: "Trash2",
      title: "Request Deletion",
      description: "Delete your account and associated data (where legally permitted)"
    },
    {
      icon: "Shield",
      title: "Limit Processing",
      description: "Restrict how we use your data in certain circumstances"
    },
    {
      icon: "AlertCircle",
      title: "Object to Processing",
      description: "Object to certain types of data processing activities"
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Data Privacy Policies
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto mb-8">
            Clear explanations of what data we collect, how it's used, and your control options - available in both simple and legal language.
          </p>
          
          {/* View Mode Toggle */}
          <div className="flex justify-center mb-12">
            <div className="bg-muted rounded-lg p-1">
              <Button
                variant={viewMode === 'simple' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('simple')}
                className="mr-1"
              >
                <Icon name="MessageCircle" size={16} className="mr-2" />
                Simple Language
              </Button>
              <Button
                variant={viewMode === 'legal' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('legal')}
              >
                <Icon name="FileText" size={16} className="mr-2" />
                Legal Version
              </Button>
            </div>
          </div>
        </div>

        {/* Data Collection */}
        <div className="mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8">
            What Data We Collect
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {dataTypes?.map((type, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={type?.icon} size={24} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-text-primary mb-2">{type?.category}</h4>
                    <p className="text-text-secondary mb-3">
                      {viewMode === 'simple' ? type?.simple : type?.legal}
                    </p>
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-sm text-text-secondary">
                        <strong>Used for:</strong> {type?.usage}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Data Sharing */}
        <div className="bg-card rounded-2xl p-8 lg:p-12 border border-border mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-6">
            How We Share Your Data
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-success/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Icon name="Users" size={32} className="text-success" />
              </div>
              <h4 className="font-semibold text-text-primary mb-2">With Consumers</h4>
              <p className="text-sm text-text-secondary">
                Only verification data needed for traceability - never personal details
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-warning/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Icon name="Building" size={32} className="text-warning" />
              </div>
              <h4 className="font-semibold text-text-primary mb-2">With Regulators</h4>
              <p className="text-sm text-text-secondary">
                Compliance data when required by law - with advance notice to you
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-error/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Icon name="X" size={32} className="text-error" />
              </div>
              <h4 className="font-semibold text-text-primary mb-2">Never Sold</h4>
              <p className="text-sm text-text-secondary">
                We never sell your personal data to third parties - ever
              </p>
            </div>
          </div>
        </div>

        {/* User Rights */}
        <div>
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8">
            Your Data Rights & Controls
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {userRights?.map((right, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border hover:shadow-warm transition-smooth">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
                  <Icon name={right?.icon} size={24} className="text-accent" />
                </div>
                <h4 className="font-semibold text-text-primary mb-2">{right?.title}</h4>
                <p className="text-sm text-text-secondary">{right?.description}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-text-secondary mb-6">
              To exercise any of these rights, contact our privacy team
            </p>
            <Button variant="outline">
              <Icon name="Mail" size={16} className="mr-2" />
              Contact Privacy Team
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PrivacyPolicy;