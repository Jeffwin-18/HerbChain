import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import TrustSecurityCenter from './pages/trust-security-center';
import VerificationCenter from './pages/verification-center';
import CommunityForum from './pages/community-forum';
import QualityCertificationHub from './pages/quality-certification-hub';
import ConsumerQRScanner from './pages/consumer-qr-scanner';
import Homepage from './pages/homepage';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<CommunityForum />} />
        <Route path="/trust-security-center" element={<TrustSecurityCenter />} />
        <Route path="/verification-center" element={<VerificationCenter />} />
        <Route path="/community-forum" element={<CommunityForum />} />
        <Route path="/quality-certification-hub" element={<QualityCertificationHub />} />
        <Route path="/consumer-qr-scanner" element={<ConsumerQRScanner />} />
        <Route path="/homepage" element={<Homepage />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
