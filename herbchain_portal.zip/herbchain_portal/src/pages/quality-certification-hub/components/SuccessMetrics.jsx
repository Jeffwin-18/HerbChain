import React from 'react';
import Icon from '../../../components/AppIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const SuccessMetrics = () => {
  const incomeData = [
    { year: '2020', income: 28000 },
    { year: '2021', income: 35000 },
    { year: '2022', income: 48000 },
    { year: '2023', income: 62000 },
    { year: '2024', income: 78000 }
  ];

  const adoptionData = [
    { month: 'Jan', farms: 120 },
    { month: 'Feb', farms: 145 },
    { month: 'Mar', farms: 178 },
    { month: 'Apr', farms: 210 },
    { month: 'May', farms: 245 },
    { month: 'Jun', farms: 289 }
  ];

  const satisfactionData = [
    { name: 'Excellent', value: 68, color: '#16A34A' },
    { name: 'Good', value: 24, color: '#84CC16' },
    { name: 'Average', value: 6, color: '#F59E0B' },
    { name: 'Poor', value: 2, color: '#EF4444' }
  ];

  const keyMetrics = [
    {
      title: 'Average Income Increase',
      value: '178%',
      change: '+23%',
      icon: 'TrendingUp',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      description: 'Since joining HerbChain'
    },
    {
      title: 'Quality Score Average',
      value: '96.8',
      change: '+2.1',
      icon: 'Star',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      description: 'Out of 100 points'
    },
    {
      title: 'Consumer Satisfaction',
      value: '92%',
      change: '+5%',
      icon: 'Heart',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      description: 'Positive feedback rate'
    },
    {
      title: 'Certification Retention',
      value: '98.5%',
      change: '+1.2%',
      icon: 'Shield',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      description: 'Annual renewal rate'
    }
  ];

  const impactStats = [
    {
      category: 'Environmental Impact',
      stats: [
        { label: 'Carbon Footprint Reduction', value: '34%', icon: 'Leaf' },
        { label: 'Water Usage Efficiency', value: '28%', icon: 'Droplets' },
        { label: 'Soil Health Improvement', value: '45%', icon: 'Mountain' }
      ]
    },
    {
      category: 'Economic Benefits',
      stats: [
        { label: 'Premium Price Achievement', value: '156%', icon: 'DollarSign' },
        { label: 'Market Access Expansion', value: '89%', icon: 'Globe' },
        { label: 'Cost Reduction', value: '23%', icon: 'TrendingDown' }
      ]
    },
    {
      category: 'Social Impact',
      stats: [
        { label: 'Job Creation', value: '2,847', icon: 'Users' },
        { label: 'Community Investment', value: '$1.2M', icon: 'Building' },
        { label: 'Education Programs', value: '156', icon: 'BookOpen' }
      ]
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Platform Impact & Success Metrics
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Real data showcasing the transformative impact of blockchain verification on farmers, consumers, and the entire herb supply chain ecosystem.
          </p>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {keyMetrics?.map((metric, index) => (
            <div key={index} className="bg-card rounded-xl border border-border p-6 hover:shadow-warm transition-smooth">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${metric?.bgColor}`}>
                  <Icon name={metric?.icon} size={24} className={metric?.color} />
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-text-primary">{metric?.value}</div>
                  <div className="text-sm text-green-600 font-medium">{metric?.change}</div>
                </div>
              </div>
              <h3 className="font-semibold text-text-primary mb-1">{metric?.title}</h3>
              <p className="text-sm text-text-secondary">{metric?.description}</p>
            </div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Income Growth Chart */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-headline text-xl font-bold text-text-primary">
                  Average Farmer Income Growth
                </h3>
                <p className="text-text-secondary">Annual income progression since certification</p>
              </div>
              <Icon name="TrendingUp" size={24} className="text-green-600" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incomeData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="year" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    formatter={(value) => [`$${value?.toLocaleString()}`, 'Income']}
                    labelStyle={{ color: '#1A1A1A' }}
                    contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px' }}
                  />
                  <Bar dataKey="income" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Adoption Rate Chart */}
          <div className="bg-card rounded-xl border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-headline text-xl font-bold text-text-primary">
                  Monthly Farm Adoption
                </h3>
                <p className="text-text-secondary">New farms joining the platform</p>
              </div>
              <Icon name="Users" size={24} className="text-blue-600" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={adoptionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    formatter={(value) => [value, 'New Farms']}
                    labelStyle={{ color: '#1A1A1A' }}
                    contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="farms" 
                    stroke="var(--color-accent)" 
                    strokeWidth={3}
                    dot={{ fill: 'var(--color-accent)', strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Satisfaction Chart */}
        <div className="bg-card rounded-xl border border-border p-6 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="font-headline text-xl font-bold text-text-primary mb-4">
                Consumer Satisfaction Distribution
              </h3>
              <p className="text-text-secondary mb-6">
                Based on 15,000+ verified product reviews and feedback
              </p>
              <div className="space-y-4">
                {satisfactionData?.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div 
                        className="w-4 h-4 rounded-full"
                        style={{ backgroundColor: item?.color }}
                      ></div>
                      <span className="text-text-primary font-medium">{item?.name}</span>
                    </div>
                    <span className="text-text-secondary font-semibold">{item?.value}%</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={satisfactionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {satisfactionData?.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry?.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`${value}%`, 'Satisfaction']}
                    contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Impact Statistics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {impactStats?.map((category, categoryIndex) => (
            <div key={categoryIndex} className="bg-card rounded-xl border border-border p-6">
              <h3 className="font-headline text-lg font-bold text-text-primary mb-6">
                {category?.category}
              </h3>
              <div className="space-y-4">
                {category?.stats?.map((stat, statIndex) => (
                  <div key={statIndex} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Icon name={stat?.icon} size={20} className="text-primary" />
                      <span className="text-sm text-text-secondary">{stat?.label}</span>
                    </div>
                    <span className="font-bold text-text-primary">{stat?.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-2xl p-8">
            <h3 className="font-headline text-2xl font-bold text-text-primary mb-4">
              Ready to Join Our Success Story?
            </h3>
            <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
              Become part of the growing community of certified farmers who are transforming their businesses through blockchain verification and quality certification.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-smooth flex items-center justify-center">
                <Icon name="UserPlus" size={20} className="mr-2" />
                Start Certification Process
              </button>
              <button className="border border-border bg-background text-text-primary px-6 py-3 rounded-lg font-semibold hover:bg-muted transition-smooth flex items-center justify-center">
                <Icon name="Download" size={20} className="mr-2" />
                Download Impact Report
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SuccessMetrics;