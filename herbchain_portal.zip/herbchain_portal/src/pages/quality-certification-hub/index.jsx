import React from 'react';
import Header from '../../components/ui/Header';
import HeroSection from './components/HeroSection';
import FeaturedFarms from './components/FeaturedFarms';
import CertificationStandards from './components/CertificationStandards';
import SuccessMetrics from './components/SuccessMetrics';
import TestimonialsSection from './components/TestimonialsSection';
import InteractiveMap from './components/InteractiveMap';

const QualityCertificationHub = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      {/* Main Content */}
      <main className="pt-16">
        <HeroSection />
        <FeaturedFarms />
        <CertificationStandards />
        <SuccessMetrics />
        <TestimonialsSection />
        <InteractiveMap />
      </main>
      {/* Footer */}
      <footer className="bg-text-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 lg:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="relative">
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="40" height="40" rx="8" fill="white" />
                    <path
                      d="M12 28V20C12 18.5 13 17 14.5 16.5L20 15L25.5 16.5C27 17 28 18.5 28 20V28"
                      stroke="var(--color-primary)"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M20 15V12C20 10.5 18.5 9 17 9C15.5 9 14 10.5 14 12V15"
                      stroke="var(--color-primary)"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <circle cx="20" cy="22" r="2" fill="var(--color-primary)" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-headline font-bold text-xl">HerbChain Portal</h3>
                  <p className="text-sm opacity-80">Quality Certification Hub</p>
                </div>
              </div>
              <p className="text-sm opacity-80 mb-4 max-w-md">
                Transforming herb supply chain transparency through blockchain verification and quality certification standards.
              </p>
              <div className="text-xs opacity-60">
                © {new Date()?.getFullYear()} HerbChain Portal. All rights reserved.
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Certification</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Organic Standards</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Sustainable Practices</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Premium Quality</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Fair Trade</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm opacity-80">
                <li><a href="#" className="hover:opacity-100 transition-opacity">Farmer Portal</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Consumer Guide</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">API Documentation</a></li>
                <li><a href="#" className="hover:opacity-100 transition-opacity">Support Center</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default QualityCertificationHub;