import React from 'react';
import Header from '../../components/ui/Header';
import HeroSection from './components/HeroSection';
import InteractiveMap from './components/InteractiveMap';
import HowItWorksSection from './components/HowItWorksSection';
import FarmerSuccessStories from './components/FarmerSuccessStories';
import LiveActivityFeed from './components/LiveActivityFeed';
import CallToActionSection from './components/CallToActionSection';

const Homepage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <InteractiveMap />
        <HowItWorksSection />
        <FarmerSuccessStories />
        <LiveActivityFeed />
        <CallToActionSection />
      </main>
      {/* Footer */}
      <footer className="bg-text-primary text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 40 40"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <rect width="40" height="40" rx="8" fill="white" />
                    <path
                      d="M12 28V20C12 18.5 13 17 14.5 16.5L20 15L25.5 16.5C27 17 28 18.5 28 20V28"
                      stroke="var(--color-primary)"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <path
                      d="M20 15V12C20 10.5 18.5 9 17 9C15.5 9 14 10.5 14 12V15"
                      stroke="var(--color-primary)"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <circle cx="20" cy="22" r="2" fill="var(--color-primary)" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-headline font-bold text-lg">HerbChain</h3>
                  <p className="text-white/70 text-sm">Portal</p>
                </div>
              </div>
              <p className="text-white/80 text-sm leading-relaxed">
                Transforming herb supply chains through blockchain transparency and trust.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-headline font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/verification-center" className="text-white/80 hover:text-white transition-colors">Verification Center</a></li>
                <li><a href="/consumer-qr-scanner" className="text-white/80 hover:text-white transition-colors">QR Scanner</a></li>
                <li><a href="/quality-certification-hub" className="text-white/80 hover:text-white transition-colors">Certifications</a></li>
                <li><a href="/community-forum" className="text-white/80 hover:text-white transition-colors">Community</a></li>
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h4 className="font-headline font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/trust-security-center" className="text-white/80 hover:text-white transition-colors">Security Center</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">API Documentation</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-headline font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Support</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Partnership</a></li>
                <li><a href="#" className="text-white/80 hover:text-white transition-colors">Careers</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white/20 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/70 text-sm">
              © {new Date()?.getFullYear()} HerbChain Portal. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">Privacy Policy</a>
              <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">Terms of Service</a>
              <a href="#" className="text-white/70 hover:text-white transition-colors text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Homepage;