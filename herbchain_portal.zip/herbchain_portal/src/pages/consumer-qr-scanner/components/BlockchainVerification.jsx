import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BlockchainVerification = ({ verificationData }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const blockchainData = {
    transactionHash: '0x7f9a8b2c3d4e5f6789abcdef0123456789abcdef0123456789abcdef01234567',
    blockNumber: 18547892,
    blockHash: '0x1a2b3c4d5e6f789abcdef0123456789abcdef0123456789abcdef0123456789a',
    timestamp: '2024-05-16T08:30:45Z',
    confirmations: 2847,
    gasUsed: '0.00234 ETH',
    network: 'HerbChain Mainnet',
    status: 'Confirmed',
    verificationSteps: [
      {
        id: 1,
        step: 'Data Submission',
        timestamp: '2024-05-16T08:25:12Z',
        status: 'completed',
        description: 'Farm data and quality certificates submitted to blockchain',
        txHash: '0x7f9a8b2c3d4e5f67...'
      },
      {
        id: 2,
        step: 'Smart Contract Validation',
        timestamp: '2024-05-16T08:27:33Z',
        status: 'completed',
        description: 'Automated validation of data integrity and compliance',
        txHash: '0x89abcdef01234567...'
      },
      {
        id: 3,
        step: 'Consensus Verification',
        timestamp: '2024-05-16T08:29:18Z',
        status: 'completed',
        description: 'Network consensus achieved across validator nodes',
        txHash: '0x0123456789abcdef...'
      },
      {
        id: 4,
        step: 'Immutable Record Creation',
        timestamp: '2024-05-16T08:30:45Z',
        status: 'completed',
        description: 'Permanent record created and distributed across network',
        txHash: '0x456789abcdef0123...'
      }
    ],
    validators: [
      { id: 1, name: 'AgriChain Validator', location: 'US-West', status: 'active' },
      { id: 2, name: 'FarmTrust Node', location: 'EU-Central', status: 'active' },
      { id: 3, name: 'GreenChain Validator', location: 'Asia-Pacific', status: 'active' }
    ],
    dataIntegrity: {
      originalHash: 'QmX7Y8Z9A1B2C3D4E5F6789ABCDEF0123456789ABCDEF',
      currentHash: 'QmX7Y8Z9A1B2C3D4E5F6789ABCDEF0123456789ABCDEF',
      match: true,
      lastVerified: '2024-05-16T08:30:45Z'
    }
  };

  const formatHash = (hash, length = 10) => {
    if (!hash) return '';
    return `${hash?.slice(0, length)}...${hash?.slice(-8)}`;
  };

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp)?.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZoneName: 'short'
    });
  };

  const copyToClipboard = (text) => {
    navigator.clipboard?.writeText(text);
    // You could add a toast notification here
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <h3 className="text-2xl font-headline font-bold text-text-primary mb-2">
          Blockchain Verification
        </h3>
        <p className="text-text-secondary">
          Immutable proof of authenticity and traceability
        </p>
      </div>
      {/* Status Overview */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-success/10 rounded-full flex items-center justify-center">
              <Icon name="Shield" size={24} className="text-success" />
            </div>
            <div>
              <h4 className="text-lg font-headline font-semibold text-text-primary">
                Verification Complete
              </h4>
              <p className="text-text-secondary text-sm">
                This product has been successfully verified on the blockchain
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="px-4 py-2 bg-success/10 text-success rounded-full text-sm font-medium border border-success/20">
              {blockchainData?.status}
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-muted rounded-lg p-4">
            <div className="text-sm text-text-secondary mb-1">Block Number</div>
            <div className="text-lg font-bold text-text-primary">
              #{blockchainData?.blockNumber?.toLocaleString()}
            </div>
          </div>
          <div className="bg-muted rounded-lg p-4">
            <div className="text-sm text-text-secondary mb-1">Confirmations</div>
            <div className="text-lg font-bold text-success">
              {blockchainData?.confirmations?.toLocaleString()}
            </div>
          </div>
          <div className="bg-muted rounded-lg p-4">
            <div className="text-sm text-text-secondary mb-1">Network</div>
            <div className="text-lg font-bold text-primary">
              {blockchainData?.network}
            </div>
          </div>
        </div>
      </div>
      {/* Transaction Details */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm mb-6">
        <h4 className="text-lg font-headline font-semibold text-text-primary mb-4">
          Transaction Details
        </h4>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
            <span className="text-text-secondary">Transaction Hash</span>
            <div className="flex items-center gap-2">
              <code className="text-sm font-mono text-text-primary bg-muted px-2 py-1 rounded">
                {formatHash(blockchainData?.transactionHash)}
              </code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(blockchainData?.transactionHash)}
                iconName="Copy"
                className="px-2"
              >
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
            <span className="text-text-secondary">Block Hash</span>
            <div className="flex items-center gap-2">
              <code className="text-sm font-mono text-text-primary bg-muted px-2 py-1 rounded">
                {formatHash(blockchainData?.blockHash)}
              </code>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(blockchainData?.blockHash)}
                iconName="Copy"
                className="px-2"
              >
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between py-3 border-b border-border last:border-b-0">
            <span className="text-text-secondary">Timestamp</span>
            <span className="text-text-primary font-medium">
              {formatTimestamp(blockchainData?.timestamp)}
            </span>
          </div>

          <div className="flex items-center justify-between py-3">
            <span className="text-text-secondary">Gas Used</span>
            <span className="text-text-primary font-medium">
              {blockchainData?.gasUsed}
            </span>
          </div>
        </div>
      </div>
      {/* Verification Steps */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm mb-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-headline font-semibold text-text-primary">
            Verification Process
          </h4>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
          >
            {isExpanded ? 'Show Less' : 'Show Details'}
          </Button>
        </div>

        <div className="space-y-4">
          {blockchainData?.verificationSteps?.map((step, index) => (
            <div key={step?.id} className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-success/10 rounded-full flex items-center justify-center border border-success/20">
                <Icon name="Check" size={16} className="text-success" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h5 className="font-medium text-text-primary">{step?.step}</h5>
                  <span className="text-xs text-text-secondary">
                    {formatTimestamp(step?.timestamp)}
                  </span>
                </div>
                <p className="text-sm text-text-secondary mb-2">
                  {step?.description}
                </p>
                {isExpanded && (
                  <div className="flex items-center gap-2">
                    <code className="text-xs font-mono text-text-primary bg-muted px-2 py-1 rounded">
                      {formatHash(step?.txHash, 8)}
                    </code>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(step?.txHash)}
                      iconName="ExternalLink"
                      className="px-2 text-xs"
                    >
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Data Integrity */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm mb-6">
        <h4 className="text-lg font-headline font-semibold text-text-primary mb-4">
          Data Integrity Verification
        </h4>
        
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-success/10 rounded-full flex items-center justify-center">
            <Icon name="CheckCircle" size={20} className="text-success" />
          </div>
          <div>
            <div className="font-medium text-success">Data Integrity Verified</div>
            <div className="text-sm text-text-secondary">
              Original data matches current blockchain record
            </div>
          </div>
        </div>

        {isExpanded && (
          <div className="space-y-3 mt-4 pt-4 border-t border-border">
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Original Hash</span>
              <code className="text-sm font-mono text-text-primary bg-muted px-2 py-1 rounded">
                {formatHash(blockchainData?.dataIntegrity?.originalHash)}
              </code>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Current Hash</span>
              <code className="text-sm font-mono text-text-primary bg-muted px-2 py-1 rounded">
                {formatHash(blockchainData?.dataIntegrity?.currentHash)}
              </code>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-text-secondary">Last Verified</span>
              <span className="text-text-primary">
                {formatTimestamp(blockchainData?.dataIntegrity?.lastVerified)}
              </span>
            </div>
          </div>
        )}
      </div>
      {/* Network Validators */}
      {isExpanded && (
        <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
          <h4 className="text-lg font-headline font-semibold text-text-primary mb-4">
            Network Validators
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {blockchainData?.validators?.map((validator) => (
              <div key={validator?.id} className="bg-muted rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium text-text-primary">{validator?.name}</h5>
                  <div className="w-2 h-2 bg-success rounded-full"></div>
                </div>
                <div className="text-sm text-text-secondary">
                  {validator?.location}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Action Buttons */}
      <div className="mt-6 flex flex-wrap gap-3">
        <Button
          variant="outline"
          iconName="ExternalLink"
          iconPosition="left"
        >
          View on Explorer
        </Button>
        <Button
          variant="outline"
          iconName="Download"
          iconPosition="left"
        >
          Download Certificate
        </Button>
        <Button
          variant="outline"
          iconName="Share"
          iconPosition="left"
        >
          Share Verification
        </Button>
      </div>
    </div>
  );
};

export default BlockchainVerification;