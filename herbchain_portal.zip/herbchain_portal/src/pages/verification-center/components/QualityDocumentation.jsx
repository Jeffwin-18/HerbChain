import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const QualityDocumentation = ({ onNext, onBack, qualityData, setQualityData }) => {
  const [errors, setErrors] = useState({});
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isDragOver, setIsDragOver] = useState(false);

  const qualityGrades = [
    { value: 'premium', label: 'Premium Grade A' },
    { value: 'standard', label: 'Standard Grade B' },
    { value: 'commercial', label: 'Commercial Grade C' },
    { value: 'organic-premium', label: 'Organic Premium' },
    { value: 'wildcrafted', label: 'Wildcrafted Superior' }
  ];

  const testTypes = [
    { value: 'pesticide', label: 'Pesticide Residue Test' },
    { value: 'heavy-metals', label: 'Heavy Metals Analysis' },
    { value: 'microbial', label: 'Microbial Testing' },
    { value: 'potency', label: 'Active Compound Potency' },
    { value: 'moisture', label: 'Moisture Content' },
    { value: 'ash', label: 'Ash Content' },
    { value: 'foreign-matter', label: 'Foreign Matter Analysis' }
  ];

  const mockFiles = [
    {
      id: 1,
      name: 'Lab_Analysis_Report_2024.pdf',
      size: '2.4 MB',
      type: 'application/pdf',
      uploadDate: '2024-09-08',
      ipfsHash: 'QmX7Y8Z9...'
    },
    {
      id: 2,
      name: 'Organic_Certificate_2024.pdf',
      size: '1.8 MB',
      type: 'application/pdf',
      uploadDate: '2024-09-07',
      ipfsHash: 'QmA1B2C3...'
    }
  ];

  const handleInputChange = (field, value) => {
    setQualityData(prev => ({
      ...prev,
      [field]: value
    }));
    
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e?.dataTransfer?.files);
    handleFileUpload(files);
  };

  const handleFileUpload = (files) => {
    const newFiles = files?.map((file, index) => ({
      id: uploadedFiles?.length + index + 1,
      name: file?.name,
      size: `${(file?.size / 1024 / 1024)?.toFixed(1)} MB`,
      type: file?.type,
      uploadDate: new Date()?.toISOString()?.split('T')?.[0],
      ipfsHash: `QmX${Math.random()?.toString(36)?.substr(2, 9)}...`,
      status: 'uploading'
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);

    // Simulate upload progress
    newFiles?.forEach((file, index) => {
      setTimeout(() => {
        setUploadedFiles(prev => 
          prev?.map(f => 
            f?.id === file?.id 
              ? { ...f, status: 'completed' }
              : f
          )
        );
      }, (index + 1) * 1500);
    });
  };

  const removeFile = (fileId) => {
    setUploadedFiles(prev => prev?.filter(file => file?.id !== fileId));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!qualityData?.qualityGrade) {
      newErrors.qualityGrade = 'Please select quality grade';
    }
    
    if (uploadedFiles?.length === 0) {
      newErrors.files = 'Please upload at least one quality document';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      onNext();
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
          <Icon name="FileText" size={20} className="text-accent" />
        </div>
        <div>
          <h2 className="text-xl font-headline font-semibold text-text-primary">
            Quality Documentation
          </h2>
          <p className="text-sm text-text-secondary">
            Upload certificates and test results for verification
          </p>
        </div>
      </div>
      <div className="space-y-6">
        <Select
          label="Quality Grade"
          placeholder="Select quality grade"
          description="Choose the quality grade that best describes your harvest"
          options={qualityGrades}
          value={qualityData?.qualityGrade || ''}
          onChange={(value) => handleInputChange('qualityGrade', value)}
          error={errors?.qualityGrade}
          required
        />

        <Select
          label="Available Test Results"
          placeholder="Select test types you have results for"
          description="Choose all applicable test results you can provide"
          options={testTypes}
          value={qualityData?.testTypes || []}
          onChange={(value) => handleInputChange('testTypes', value)}
          multiple
          searchable
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Input
            label="Moisture Content (%)"
            type="number"
            placeholder="e.g., 8.5"
            value={qualityData?.moistureContent || ''}
            onChange={(e) => handleInputChange('moistureContent', e?.target?.value)}
            min="0"
            max="100"
            step="0.1"
            className="lg:col-span-1"
          />
          
          <Input
            label="Active Compound (%)"
            type="number"
            placeholder="e.g., 2.3"
            value={qualityData?.activeCompound || ''}
            onChange={(e) => handleInputChange('activeCompound', e?.target?.value)}
            min="0"
            step="0.1"
            className="lg:col-span-1"
          />
        </div>

        <Input
          label="Testing Laboratory"
          type="text"
          placeholder="Name of testing laboratory"
          value={qualityData?.testingLab || ''}
          onChange={(e) => handleInputChange('testingLab', e?.target?.value)}
        />

        {/* File Upload Area */}
        <div className="space-y-4">
          <label className="block text-sm font-medium text-text-primary">
            Quality Documents *
          </label>
          
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragOver 
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <Icon name="Upload" size={48} className="mx-auto text-text-secondary mb-4" />
            <h3 className="text-lg font-medium text-text-primary mb-2">
              Upload Quality Documents
            </h3>
            <p className="text-sm text-text-secondary mb-4">
              Drag and drop files here, or click to browse
            </p>
            <p className="text-xs text-text-secondary mb-4">
              Supports PDF, JPG, PNG files up to 10MB each
            </p>
            <Button variant="outline" size="sm">
              Choose Files
            </Button>
          </div>
          
          {errors?.files && (
            <p className="text-sm text-error">{errors?.files}</p>
          )}
        </div>

        {/* Uploaded Files List */}
        {uploadedFiles?.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-text-primary">
              Uploaded Documents ({uploadedFiles?.length})
            </h3>
            
            {uploadedFiles?.map((file) => (
              <div key={file?.id} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="FileText" size={20} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">{file?.name}</p>
                    <p className="text-sm text-text-secondary">
                      {file?.size} • Uploaded {file?.uploadDate}
                    </p>
                    {file?.status === 'completed' && (
                      <p className="text-xs text-success">
                        IPFS Hash: {file?.ipfsHash}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {file?.status === 'uploading' && (
                    <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  )}
                  {file?.status === 'completed' && (
                    <Icon name="CheckCircle" size={20} className="text-success" />
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(file?.id)}
                    iconName="X"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Mock existing files */}
        {mockFiles?.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-text-primary">
              Previously Uploaded Documents
            </h3>
            
            {mockFiles?.map((file) => (
              <div key={file?.id} className="flex items-center justify-between p-4 bg-success/5 border border-success/20 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                    <Icon name="FileText" size={20} className="text-success" />
                  </div>
                  <div>
                    <p className="font-medium text-text-primary">{file?.name}</p>
                    <p className="text-sm text-text-secondary">
                      {file?.size} • Uploaded {file?.uploadDate}
                    </p>
                    <p className="text-xs text-success">
                      IPFS Hash: {file?.ipfsHash}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Icon name="CheckCircle" size={20} className="text-success" />
                  <Button variant="ghost" size="sm" iconName="Download" />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="flex justify-between mt-8">
        <Button
          variant="outline"
          onClick={onBack}
          iconName="ArrowLeft"
          iconPosition="left"
        >
          Back
        </Button>
        
        <Button
          variant="default"
          onClick={handleNext}
          iconName="ArrowRight"
          iconPosition="right"
          className="min-w-32"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default QualityDocumentation;