import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const InteractiveMap = () => {
  const [selectedFarm, setSelectedFarm] = useState(null);

  const verifiedFarms = [
    {
      id: 1,
      name: "Green Valley Herbs",
      location: "California, USA",
      coordinates: { lat: 37.7749, lng: -122.4194 },
      herbs: ["Organic Basil", "Rosemary", "Thyme"],
      recentVerifications: 23,
      rating: 4.9,
      established: 2018,
      certifications: ["Organic", "Non-GMO", "Fair Trade"]
    },
    {
      id: 2,
      name: "Mountain Peak Farm",
      location: "Colorado, USA",
      coordinates: { lat: 39.7392, lng: -104.9903 },
      herbs: ["Wild Thyme", "Sage", "Lavender"],
      recentVerifications: 18,
      rating: 4.8,
      established: 2020,
      certifications: ["Organic", "Sustainable"]
    },
    {
      id: 3,
      name: "Sunrise Botanicals",
      location: "Oregon, USA",
      coordinates: { lat: 45.5152, lng: -122.6784 },
      herbs: ["Fresh Mint", "Oregano", "Cilantro"],
      recentVerifications: 31,
      rating: 4.9,
      established: 2016,
      certifications: ["Organic", "Biodynamic", "Carbon Neutral"]
    },
    {
      id: 4,
      name: "Heritage Herb Gardens",
      location: "Vermont, USA",
      coordinates: { lat: 44.2601, lng: -72.5806 },
      herbs: ["Chamomile", "Echinacea", "Lemon Balm"],
      recentVerifications: 15,
      rating: 4.7,
      established: 2015,
      certifications: ["Organic", "Heirloom Varieties"]
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Verified Farms Network
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Explore our growing network of verified herb farms. Each pin represents a trusted partner 
            in our blockchain-enabled supply chain.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map Section */}
          <div className="lg:col-span-2">
            <div className="relative bg-card rounded-xl border border-border overflow-hidden shadow-warm">
              {/* Map Container */}
              <div className="relative h-96 lg:h-[500px] bg-gradient-to-br from-muted/30 to-muted/60">
                {/* Google Maps Iframe */}
                <iframe
                  width="100%"
                  height="100%"
                  loading="lazy"
                  title="Verified Farms Network"
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://www.google.com/maps?q=39.8283,-98.5795&z=4&output=embed"
                  className="absolute inset-0"
                />

                {/* Farm Markers Overlay */}
                <div className="absolute inset-0 pointer-events-none">
                  {verifiedFarms?.map((farm, index) => (
                    <div
                      key={farm?.id}
                      className={`absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-auto cursor-pointer transition-all duration-300 ${
                        selectedFarm?.id === farm?.id ? 'scale-125 z-20' : 'hover:scale-110 z-10'
                      }`}
                      style={{
                        left: `${20 + (index * 15)}%`,
                        top: `${30 + (index * 10)}%`
                      }}
                      onClick={() => setSelectedFarm(selectedFarm?.id === farm?.id ? null : farm)}
                    >
                      <div className={`relative w-8 h-8 rounded-full border-2 border-white shadow-lg transition-colors ${
                        selectedFarm?.id === farm?.id ? 'bg-primary' : 'bg-conversion hover:bg-primary'
                      }`}>
                        <Icon 
                          name="MapPin" 
                          size={16} 
                          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white" 
                        />
                      </div>
                      
                      {/* Pulse Animation */}
                      <div className={`absolute inset-0 rounded-full border-2 animate-ping ${
                        selectedFarm?.id === farm?.id ? 'border-primary/30' : 'border-conversion/30'
                      }`}></div>
                    </div>
                  ))}
                </div>

                {/* Map Controls */}
                <div className="absolute top-4 right-4 flex flex-col space-y-2">
                  <button className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-muted transition-colors">
                    <Icon name="Plus" size={16} className="text-text-primary" />
                  </button>
                  <button className="w-10 h-10 bg-white rounded-lg shadow-md flex items-center justify-center hover:bg-muted transition-colors">
                    <Icon name="Minus" size={16} className="text-text-primary" />
                  </button>
                </div>

                {/* Legend */}
                <div className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg p-3 shadow-md">
                  <div className="flex items-center space-x-2 text-sm">
                    <div className="w-3 h-3 bg-conversion rounded-full"></div>
                    <span className="text-text-primary font-medium">Verified Farms</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Farm Details Panel */}
          <div className="space-y-6">
            <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
              <h3 className="font-headline text-lg font-semibold text-text-primary mb-4">
                Network Statistics
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Total Farms</span>
                  <span className="font-semibold text-text-primary">342</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Countries</span>
                  <span className="font-semibold text-text-primary">23</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">Avg. Rating</span>
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={14} className="text-warning fill-current" />
                    <span className="font-semibold text-text-primary">4.8</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-text-secondary">This Month</span>
                  <span className="font-semibold text-conversion">+28 farms</span>
                </div>
              </div>
            </div>

            {/* Selected Farm Details */}
            {selectedFarm ? (
              <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-headline text-lg font-semibold text-text-primary">
                      {selectedFarm?.name}
                    </h3>
                    <p className="text-text-secondary text-sm flex items-center">
                      <Icon name="MapPin" size={14} className="mr-1" />
                      {selectedFarm?.location}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedFarm(null)}
                    className="text-text-secondary hover:text-text-primary transition-colors"
                  >
                    <Icon name="X" size={16} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <Icon name="Star" size={14} className="text-warning fill-current" />
                      <span className="text-sm font-medium">{selectedFarm?.rating}</span>
                    </div>
                    <div className="text-sm text-text-secondary">
                      Est. {selectedFarm?.established}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-text-primary mb-2">Specialties</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedFarm?.herbs?.map((herb, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                        >
                          {herb}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-text-primary mb-2">Certifications</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedFarm?.certifications?.map((cert, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-conversion/10 text-conversion text-xs rounded-full"
                        >
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-border">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-text-secondary">Recent Verifications</span>
                      <span className="text-sm font-medium text-text-primary">
                        {selectedFarm?.recentVerifications} this month
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-card rounded-xl border border-border p-6 shadow-warm text-center">
                <Icon name="MousePointer" size={32} className="text-text-secondary mx-auto mb-3" />
                <h3 className="font-medium text-text-primary mb-2">Select a Farm</h3>
                <p className="text-sm text-text-secondary">
                  Click on any pin to view detailed farm information and recent verification activity.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveMap;