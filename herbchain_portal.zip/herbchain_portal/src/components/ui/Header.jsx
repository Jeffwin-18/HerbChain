import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);
  const location = useLocation();

  const primaryNavItems = [
    { path: '/homepage', label: 'Home', icon: 'Home' },
    { path: '/consumer-qr-scanner', label: 'QR Scanner', icon: 'QrCode' },
    { path: '/verification-center', label: 'Verification', icon: 'Shield' },
    { path: '/quality-certification-hub', label: 'Certification', icon: 'Award' },
  ];

  const secondaryNavItems = [
    { path: '/community-forum', label: 'Community', icon: 'Users' },
    { path: '/trust-security-center', label: 'Security', icon: 'Lock' },
  ];

  const isActivePath = (path) => location?.pathname === path;

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
    setIsMoreMenuOpen(false);
  };

  const toggleMoreMenu = () => {
    setIsMoreMenuOpen(!isMoreMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
    setIsMoreMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="w-full">
        <div className="flex items-center justify-between h-16 px-4 lg:px-6">
          {/* Logo */}
          <Link 
            to="/homepage" 
            className="flex items-center space-x-3 transition-smooth hover:opacity-80"
            onClick={closeMobileMenu}
          >
            <div className="relative">
              <svg
                width="40"
                height="40"
                viewBox="0 0 40 40"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                className="transition-smooth hover:scale-105"
              >
                <rect width="40" height="40" rx="8" fill="var(--color-primary)" />
                <path
                  d="M12 28V20C12 18.5 13 17 14.5 16.5L20 15L25.5 16.5C27 17 28 18.5 28 20V28"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M20 15V12C20 10.5 18.5 9 17 9C15.5 9 14 10.5 14 12V15"
                  stroke="white"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <circle cx="20" cy="22" r="2" fill="white" />
              </svg>
            </div>
            <div className="hidden sm:block">
              <h1 className="font-headline font-bold text-xl text-primary">
                HerbChain
              </h1>
              <p className="text-xs text-text-secondary font-medium">
                Portal
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {primaryNavItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth ${
                  isActivePath(item?.path)
                    ? 'bg-primary text-primary-foreground'
                    : 'text-text-primary hover:bg-muted hover:text-primary'
                }`}
              >
                <Icon name={item?.icon} size={18} />
                <span>{item?.label}</span>
              </Link>
            ))}
            
            {/* More Menu */}
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMoreMenu}
                className={`flex items-center space-x-2 ${
                  isMoreMenuOpen ? 'bg-muted text-primary' : ''
                }`}
              >
                <Icon name="MoreHorizontal" size={18} />
                <span>More</span>
                <Icon 
                  name="ChevronDown" 
                  size={16} 
                  className={`transition-transform ${isMoreMenuOpen ? 'rotate-180' : ''}`} 
                />
              </Button>
              
              {isMoreMenuOpen && (
                <div className="absolute top-full right-0 mt-2 w-48 bg-popover border border-border rounded-lg shadow-warm py-2 z-50">
                  {secondaryNavItems?.map((item) => (
                    <Link
                      key={item?.path}
                      to={item?.path}
                      onClick={() => setIsMoreMenuOpen(false)}
                      className={`flex items-center space-x-3 px-4 py-2 text-sm transition-smooth ${
                        isActivePath(item?.path)
                          ? 'bg-primary/10 text-primary font-medium' :'text-text-primary hover:bg-muted'
                      }`}
                    >
                      <Icon name={item?.icon} size={18} />
                      <span>{item?.label}</span>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Icon name="User" size={16} className="mr-2" />
              Sign In
            </Button>
            <Button variant="default" size="sm" className="bg-conversion hover:bg-conversion/90">
              <Icon name="Leaf" size={16} className="mr-2" />
              Start Verification
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleMobileMenu}
            className="lg:hidden"
          >
            <Icon name={isMobileMenuOpen ? "X" : "Menu"} size={24} />
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-background border-t border-border">
            <nav className="px-4 py-4 space-y-2">
              {primaryNavItems?.map((item) => (
                <Link
                  key={item?.path}
                  to={item?.path}
                  onClick={closeMobileMenu}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-smooth ${
                    isActivePath(item?.path)
                      ? 'bg-primary text-primary-foreground'
                      : 'text-text-primary hover:bg-muted'
                  }`}
                >
                  <Icon name={item?.icon} size={20} />
                  <span>{item?.label}</span>
                </Link>
              ))}
              
              <div className="border-t border-border pt-2 mt-2">
                {secondaryNavItems?.map((item) => (
                  <Link
                    key={item?.path}
                    to={item?.path}
                    onClick={closeMobileMenu}
                    className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-smooth ${
                      isActivePath(item?.path)
                        ? 'bg-primary text-primary-foreground'
                        : 'text-text-primary hover:bg-muted'
                    }`}
                  >
                    <Icon name={item?.icon} size={20} />
                    <span>{item?.label}</span>
                  </Link>
                ))}
              </div>
              
              <div className="border-t border-border pt-4 mt-4 space-y-2">
                <Button variant="outline" fullWidth onClick={closeMobileMenu}>
                  <Icon name="User" size={16} className="mr-2" />
                  Sign In
                </Button>
                <Button variant="default" fullWidth className="bg-conversion hover:bg-conversion/90" onClick={closeMobileMenu}>
                  <Icon name="Leaf" size={16} className="mr-2" />
                  Start Verification
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
      {/* Overlay for mobile menu */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          onClick={closeMobileMenu}
        />
      )}
      {/* Overlay for more menu */}
      {isMoreMenuOpen && (
        <div 
          className="fixed inset-0 z-40 hidden lg:block"
          onClick={() => setIsMoreMenuOpen(false)}
        />
      )}
    </header>
  );
};

export default Header;