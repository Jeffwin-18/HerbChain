import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const HarvestDataEntry = ({ onNext, onBack, harvestData, setHarvestData }) => {
  const [errors, setErrors] = useState({});

  const herbVarieties = [
    { value: 'basil', label: 'Basil (Ocimum basilicum)' },
    { value: 'oregano', label: 'Oregano (Origanum vulgare)' },
    { value: 'thyme', label: 'Thyme (Thymus vulgaris)' },
    { value: 'rosemary', label: 'Rosemary (Rosmarinus officinalis)' },
    { value: 'sage', label: 'Sage (Salvia officinalis)' },
    { value: 'mint', label: 'Mint (Mentha)' },
    { value: 'parsley', label: 'Parsley (Petroselinum crispum)' },
    { value: 'cilantro', label: 'Cilantro (Coriandrum sativum)' },
    { value: 'dill', label: 'Dill (Anethum graveolens)' },
    { value: 'lavender', label: 'Lavender (Lavandula)' },
    { value: 'chamomile', label: 'Chamomile (Matricaria chamomilla)' },
    { value: 'echinacea', label: 'Echinacea (Echinacea purpurea)' }
  ];

  const harvestMethods = [
    { value: 'hand-picked', label: 'Hand Picked' },
    { value: 'machine-harvested', label: 'Machine Harvested' },
    { value: 'selective-harvest', label: 'Selective Harvest' },
    { value: 'cut-and-come-again', label: 'Cut and Come Again' }
  ];

  const processingMethods = [
    { value: 'fresh', label: 'Fresh (No Processing)' },
    { value: 'air-dried', label: 'Air Dried' },
    { value: 'freeze-dried', label: 'Freeze Dried' },
    { value: 'dehydrated', label: 'Dehydrated' },
    { value: 'essential-oil', label: 'Essential Oil Extraction' }
  ];

  const handleInputChange = (field, value) => {
    setHarvestData(prev => ({
      ...prev,
      [field]: value
    }));
    
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!harvestData?.herbVariety) {
      newErrors.herbVariety = 'Please select herb variety';
    }
    
    if (!harvestData?.harvestDate) {
      newErrors.harvestDate = 'Harvest date is required';
    }
    
    if (!harvestData?.quantity?.trim()) {
      newErrors.quantity = 'Quantity is required';
    }
    
    if (!harvestData?.harvestMethod) {
      newErrors.harvestMethod = 'Please select harvest method';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      onNext();
    }
  };

  const getCurrentDate = () => {
    const today = new Date();
    return today?.toISOString()?.split('T')?.[0];
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
          <Icon name="Leaf" size={20} className="text-success" />
        </div>
        <div>
          <h2 className="text-xl font-headline font-semibold text-text-primary">
            Harvest Data Entry
          </h2>
          <p className="text-sm text-text-secondary">
            Record your harvest details for blockchain verification
          </p>
        </div>
      </div>
      <div className="space-y-6">
        <Select
          label="Herb Variety"
          placeholder="Select the herb variety you harvested"
          description="Choose the specific herb type from our verified list"
          options={herbVarieties}
          value={harvestData?.herbVariety || ''}
          onChange={(value) => handleInputChange('herbVariety', value)}
          error={errors?.herbVariety}
          required
          searchable
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Input
            label="Harvest Date"
            type="date"
            value={harvestData?.harvestDate || ''}
            onChange={(e) => handleInputChange('harvestDate', e?.target?.value)}
            error={errors?.harvestDate}
            required
            max={getCurrentDate()}
            className="lg:col-span-1"
          />
          
          <Input
            label="Quantity Harvested"
            type="text"
            placeholder="e.g., 50 lbs, 25 kg, 100 bunches"
            value={harvestData?.quantity || ''}
            onChange={(e) => handleInputChange('quantity', e?.target?.value)}
            error={errors?.quantity}
            required
            className="lg:col-span-1"
          />
        </div>

        <Select
          label="Harvest Method"
          placeholder="Select harvest method used"
          options={harvestMethods}
          value={harvestData?.harvestMethod || ''}
          onChange={(value) => handleInputChange('harvestMethod', value)}
          error={errors?.harvestMethod}
          required
        />

        <Select
          label="Processing Method"
          placeholder="Select processing method"
          description="How will this harvest be processed for market"
          options={processingMethods}
          value={harvestData?.processingMethod || ''}
          onChange={(value) => handleInputChange('processingMethod', value)}
        />

        <Input
          label="Batch/Lot Number"
          type="text"
          placeholder="Enter internal batch or lot number"
          description="Your internal tracking number for this harvest"
          value={harvestData?.batchNumber || ''}
          onChange={(e) => handleInputChange('batchNumber', e?.target?.value)}
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Input
            label="Weather Conditions"
            type="text"
            placeholder="e.g., Sunny, 75°F, Low humidity"
            value={harvestData?.weatherConditions || ''}
            onChange={(e) => handleInputChange('weatherConditions', e?.target?.value)}
            className="lg:col-span-1"
          />
          
          <Input
            label="Soil Moisture Level"
            type="text"
            placeholder="e.g., Optimal, Dry, Moist"
            value={harvestData?.soilMoisture || ''}
            onChange={(e) => handleInputChange('soilMoisture', e?.target?.value)}
            className="lg:col-span-1"
          />
        </div>

        <div className="bg-muted rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <Icon name="Camera" size={20} className="text-primary mt-1" />
            <div className="flex-1">
              <h3 className="font-medium text-text-primary mb-2">
                Photo Documentation
              </h3>
              <p className="text-sm text-text-secondary mb-3">
                Upload photos of your harvest for visual verification. GPS coordinates and timestamps will be automatically extracted.
              </p>
              <Button variant="outline" size="sm" iconName="Upload">
                Upload Photos
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="flex justify-between mt-8">
        <Button
          variant="outline"
          onClick={onBack}
          iconName="ArrowLeft"
          iconPosition="left"
        >
          Back
        </Button>
        
        <Button
          variant="default"
          onClick={handleNext}
          iconName="ArrowRight"
          iconPosition="right"
          className="min-w-32"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default HarvestDataEntry;