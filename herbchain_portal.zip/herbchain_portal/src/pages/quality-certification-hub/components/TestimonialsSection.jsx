import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const TestimonialsSection = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Martinez",
      role: "Organic Herb Farmer",
      farm: "Green Valley Herbs",
      location: "Oregon, USA",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      quote: `HerbChain has completely transformed my farming business. Before certification, I was selling my organic basil at commodity prices. Now, with blockchain verification, I'm getting 180% premium prices and have direct relationships with high-end restaurants. The transparency has built incredible trust with my customers.`,
      metrics: {
        incomeIncrease: "180%",
        qualityScore: "98.5",
        yearsCertified: "3"
      },
      videoThumbnail: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 2,
      name: "David Chen",
      role: "Sustainable Agriculture Specialist",
      farm: "Mountain Peak Botanicals",
      location: "Colorado, USA",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      quote: `The blockchain verification process was surprisingly straightforward. What impressed me most was how it helped me document and improve my sustainable practices. Consumers can now see exactly how we use renewable energy and water conservation. It's not just about selling herbs - it's about sharing our story.`,
      metrics: {
        incomeIncrease: "145%",
        qualityScore: "97.8",
        yearsCertified: "2"
      },
      videoThumbnail: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 3,
      name: "Maria Rodriguez",
      role: "Third-Generation Farmer",
      farm: "Sunshine Organic Gardens",
      location: "California, USA",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      quote: `My grandmother would be amazed to see how technology is helping preserve traditional farming wisdom. The certification process helped us document three generations of sustainable practices. Now our customers can trace their herbs back to the exact plot where they were grown. It's beautiful.`,
      metrics: {
        incomeIncrease: "210%",
        qualityScore: "96.9",
        yearsCertified: "4"
      },
      videoThumbnail: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 4,
      name: "John Thompson",
      role: "Heritage Seed Keeper",
      farm: "Heritage Herb Farm",
      location: "Vermont, USA",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      quote: `Preserving heirloom varieties is my passion, and HerbChain helps me share that passion with the world. The blockchain records don't just verify quality - they preserve the genetic history of rare herb varieties. We're not just farming; we're conserving agricultural heritage for future generations.`,
      metrics: {
        incomeIncrease: "165%",
        qualityScore: "99.2",
        yearsCertified: "5"
      },
      videoThumbnail: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
  ];

  const consumerReviews = [
    {
      id: 1,
      name: "Emily Watson",
      role: "Home Chef",
      location: "Seattle, WA",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      review: "I love being able to scan the QR code and see exactly where my herbs came from. The basil I bought from Green Valley Herbs was incredibly fresh and flavorful. Knowing the farmer\'s story makes cooking so much more meaningful.",
      product: "Organic Basil",
      purchaseDate: "2024-08-15"
    },
    {
      id: 2,
      name: "Michael Park",
      role: "Restaurant Owner",
      location: "Portland, OR",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      review: "HerbChain has revolutionized our sourcing. We can show our customers exactly where their herbs come from, and the quality is consistently exceptional. Our guests love the transparency and the story behind each dish.",
      product: "Premium Herb Collection",
      purchaseDate: "2024-08-20"
    },
    {
      id: 3,
      name: "Lisa Chen",
      role: "Wellness Enthusiast",
      location: "San Francisco, CA",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      rating: 5,
      review: "The transparency is incredible. I can see the soil tests, growing methods, and even the harvest date. As someone who cares about what I put in my body, this level of verification gives me complete confidence.",
      product: "Organic Chamomile",
      purchaseDate: "2024-08-18"
    }
  ];

  const nextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials?.length);
  };

  const prevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials?.length) % testimonials?.length);
  };

  const currentTestimonial = testimonials?.[activeTestimonial];

  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Stories of Transformation
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Real farmers sharing their journey from traditional farming to blockchain-verified success, and consumers who value transparency in their food choices.
          </p>
        </div>

        {/* Featured Farmer Testimonial */}
        <div className="bg-card rounded-2xl border border-border overflow-hidden mb-16 shadow-warm">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            {/* Video/Image Section */}
            <div className="relative h-64 lg:h-auto">
              <Image
                src={currentTestimonial?.videoThumbnail}
                alt={`${currentTestimonial?.farm} farm view`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <Button variant="default" className="bg-white/90 text-text-primary hover:bg-white">
                  <Icon name="Play" size={24} className="mr-2" />
                  Watch Story
                </Button>
              </div>
              <div className="absolute top-4 left-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-semibold">
                Featured Story
              </div>
            </div>

            {/* Content Section */}
            <div className="p-8 lg:p-12">
              <div className="flex items-center space-x-4 mb-6">
                <Image
                  src={currentTestimonial?.image}
                  alt={`${currentTestimonial?.name} portrait`}
                  className="w-16 h-16 rounded-full object-cover border-2 border-primary/20"
                />
                <div>
                  <h3 className="font-headline text-xl font-bold text-text-primary">
                    {currentTestimonial?.name}
                  </h3>
                  <p className="text-text-secondary">{currentTestimonial?.role}</p>
                  <p className="text-sm text-text-secondary">
                    {currentTestimonial?.farm} • {currentTestimonial?.location}
                  </p>
                </div>
              </div>

              <blockquote className="text-text-primary text-lg leading-relaxed mb-6 italic">
                "{currentTestimonial?.quote}"
              </blockquote>

              {/* Metrics */}
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">
                    +{currentTestimonial?.metrics?.incomeIncrease}
                  </div>
                  <div className="text-xs text-text-secondary">Income Increase</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">
                    {currentTestimonial?.metrics?.qualityScore}
                  </div>
                  <div className="text-xs text-text-secondary">Quality Score</div>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">
                    {currentTestimonial?.metrics?.yearsCertified}
                  </div>
                  <div className="text-xs text-text-secondary">Years Certified</div>
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between">
                <div className="flex space-x-2">
                  {testimonials?.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveTestimonial(index)}
                      className={`w-3 h-3 rounded-full transition-smooth ${
                        index === activeTestimonial ? 'bg-primary' : 'bg-border'
                      }`}
                    />
                  ))}
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={prevTestimonial}>
                    <Icon name="ChevronLeft" size={16} />
                  </Button>
                  <Button variant="outline" size="sm" onClick={nextTestimonial}>
                    <Icon name="ChevronRight" size={16} />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Consumer Reviews */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <h3 className="font-headline text-2xl lg:text-3xl font-bold text-text-primary mb-4">
              What Consumers Are Saying
            </h3>
            <p className="text-text-secondary">
              Authentic feedback from customers who value transparency and quality
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {consumerReviews?.map((review) => (
              <div key={review?.id} className="bg-card rounded-xl border border-border p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Image
                    src={review?.image}
                    alt={`${review?.name} portrait`}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <h4 className="font-semibold text-text-primary">{review?.name}</h4>
                    <p className="text-sm text-text-secondary">{review?.role}</p>
                    <p className="text-xs text-text-secondary">{review?.location}</p>
                  </div>
                </div>

                <div className="flex items-center mb-3">
                  {[...Array(5)]?.map((_, i) => (
                    <Icon
                      key={i}
                      name="Star"
                      size={16}
                      className={`${
                        i < review?.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>

                <p className="text-text-secondary text-sm mb-4 leading-relaxed">
                  "{review?.review}"
                </p>

                <div className="border-t border-border pt-3">
                  <div className="flex justify-between text-xs text-text-secondary">
                    <span>Product: {review?.product}</span>
                    <span>{new Date(review.purchaseDate)?.toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Success Statistics */}
        <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 text-center">
          <h3 className="font-headline text-2xl font-bold text-text-primary mb-6">
            Join Thousands of Satisfied Users
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="text-3xl font-bold text-primary mb-2">2,847</div>
              <div className="text-text-secondary">Certified Farmers</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">156K+</div>
              <div className="text-text-secondary">Happy Consumers</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">4.9/5</div>
              <div className="text-text-secondary">Average Rating</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">98.5%</div>
              <div className="text-text-secondary">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;