import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const SavedProductsList = ({ onProductSelect, onRemoveProduct }) => {
  const [sortBy, setSortBy] = useState('recent');
  const [filterBy, setFilterBy] = useState('all');

  const savedProducts = [
    {
      id: 'save-001',
      qrCode: 'HBC-2024-FARM-001-BASIL-BATCH-789',
      herbName: 'Organic Basil',
      farmName: 'Green Valley Organic Farm',
      farmer: 'Maria Rodriguez',
      location: 'Sonoma County, CA',
      image: 'https://images.unsplash.com/photo-1618375569909-3c8616cf7733?w=400&h=300&fit=crop',
      purityScore: 99.8,
      sustainabilityScore: 95.5,
      savedDate: '2024-05-15T10:30:00Z',
      lastViewed: '2024-05-16T08:45:00Z',
      category: 'herbs',
      certifications: ['USDA Organic', 'Fair Trade'],
      isFavorite: true
    },
    {
      id: 'save-002',
      qrCode: 'HBC-2024-FARM-002-OREGANO-BATCH-456',
      herbName: 'Mediterranean Oregano',
      farmName: 'Sunset Hills Farm',
      farmer: 'Giuseppe Rossi',
      location: 'Tuscany, Italy',
      image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400&h=300&fit=crop',
      purityScore: 98.5,
      sustainabilityScore: 92.3,
      savedDate: '2024-05-10T14:20:00Z',
      lastViewed: '2024-05-12T16:15:00Z',
      category: 'herbs',
      certifications: ['EU Organic', 'Biodynamic'],
      isFavorite: false
    },
    {
      id: 'save-003',
      qrCode: 'HBC-2024-FARM-003-THYME-BATCH-123',
      herbName: 'French Thyme',
      farmName: 'Provence Herbs Co.',
      farmer: 'Claire Dubois',
      location: 'Provence, France',
      image: 'https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?w=400&h=300&fit=crop',
      purityScore: 97.9,
      sustainabilityScore: 89.7,
      savedDate: '2024-05-08T09:15:00Z',
      lastViewed: '2024-05-14T11:30:00Z',
      category: 'herbs',
      certifications: ['AB Organic', 'Nature & Progrès'],
      isFavorite: true
    },
    {
      id: 'save-004',
      qrCode: 'HBC-2024-FARM-004-ROSEMARY-BATCH-321',
      herbName: 'Wild Rosemary',
      farmName: 'Mountain View Organics',
      farmer: 'James Mitchell',
      location: 'Colorado, USA',
      image: 'https://images.unsplash.com/photo-1586049001321-7b1c3b7e5b5f?w=400&h=300&fit=crop',
      purityScore: 96.8,
      sustainabilityScore: 94.2,
      savedDate: '2024-05-05T16:45:00Z',
      lastViewed: '2024-05-13T13:20:00Z',
      category: 'herbs',
      certifications: ['USDA Organic', 'Regenerative Organic'],
      isFavorite: false
    }
  ];

  const sortOptions = [
    { value: 'recent', label: 'Recently Saved' },
    { value: 'viewed', label: 'Recently Viewed' },
    { value: 'name', label: 'Name A-Z' },
    { value: 'purity', label: 'Highest Purity' },
    { value: 'sustainability', label: 'Most Sustainable' }
  ];

  const filterOptions = [
    { value: 'all', label: 'All Products' },
    { value: 'favorites', label: 'Favorites Only' },
    { value: 'herbs', label: 'Herbs' },
    { value: 'recent', label: 'Last 7 Days' }
  ];

  const getSortedProducts = () => {
    let filtered = [...savedProducts];

    // Apply filters
    if (filterBy === 'favorites') {
      filtered = filtered?.filter(product => product?.isFavorite);
    } else if (filterBy === 'recent') {
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      filtered = filtered?.filter(product => new Date(product.savedDate) > weekAgo);
    }

    // Apply sorting
    filtered?.sort((a, b) => {
      switch (sortBy) {
        case 'recent':
          return new Date(b.savedDate) - new Date(a.savedDate);
        case 'viewed':
          return new Date(b.lastViewed) - new Date(a.lastViewed);
        case 'name':
          return a?.herbName?.localeCompare(b?.herbName);
        case 'purity':
          return b?.purityScore - a?.purityScore;
        case 'sustainability':
          return b?.sustainabilityScore - a?.sustainabilityScore;
        default:
          return 0;
      }
    });

    return filtered;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.ceil(diffDays / 7)} weeks ago`;
    return date?.toLocaleDateString();
  };

  const toggleFavorite = (productId) => {
    // In a real app, this would update the backend
    console.log('Toggle favorite for:', productId);
  };

  const handleRemove = (productId) => {
    onRemoveProduct?.(productId);
  };

  const sortedProducts = getSortedProducts();

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <h3 className="text-2xl font-headline font-bold text-text-primary mb-2">
          Saved Products
        </h3>
        <p className="text-text-secondary">
          Your collection of verified herbs and their stories
        </p>
      </div>
      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1">
          <label className="block text-sm font-medium text-text-primary mb-2">
            Sort by
          </label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e?.target?.value)}
            className="w-full p-2 border border-border rounded-lg bg-background text-text-primary focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {sortOptions?.map(option => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex-1">
          <label className="block text-sm font-medium text-text-primary mb-2">
            Filter
          </label>
          <select
            value={filterBy}
            onChange={(e) => setFilterBy(e?.target?.value)}
            className="w-full p-2 border border-border rounded-lg bg-background text-text-primary focus:ring-2 focus:ring-primary focus:border-transparent"
          >
            {filterOptions?.map(option => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      {/* Products Grid */}
      {sortedProducts?.length === 0 ? (
        <div className="text-center py-12">
          <Icon name="Bookmark" size={48} className="text-muted mx-auto mb-4" />
          <h4 className="text-lg font-medium text-text-primary mb-2">
            No saved products found
          </h4>
          <p className="text-text-secondary mb-4">
            {filterBy === 'favorites' ? "You haven't marked any products as favorites yet." :"Start scanning QR codes to build your collection of verified herbs."
            }
          </p>
          <Button variant="outline">
            Start Scanning
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedProducts?.map((product) => (
            <div key={product?.id} className="bg-card rounded-xl border border-border overflow-hidden shadow-warm hover:shadow-lg transition-smooth">
              {/* Product Image */}
              <div className="relative h-48 bg-muted">
                <Image
                  src={product?.image}
                  alt={product?.herbName}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3 flex gap-2">
                  <button
                    onClick={() => toggleFavorite(product?.id)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-smooth ${
                      product?.isFavorite 
                        ? 'bg-error text-white' :'bg-white/80 text-text-secondary hover:text-error'
                    }`}
                  >
                    <Icon name="Heart" size={16} className={product?.isFavorite ? 'fill-current' : ''} />
                  </button>
                  <button
                    onClick={() => handleRemove(product?.id)}
                    className="w-8 h-8 bg-white/80 rounded-full flex items-center justify-center text-text-secondary hover:text-error transition-smooth"
                  >
                    <Icon name="Trash2" size={16} />
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-4">
                <div className="mb-3">
                  <h4 className="text-lg font-headline font-semibold text-text-primary mb-1">
                    {product?.herbName}
                  </h4>
                  <p className="text-sm text-text-secondary">
                    {product?.farmName} • {product?.farmer}
                  </p>
                  <p className="text-xs text-text-secondary flex items-center mt-1">
                    <Icon name="MapPin" size={12} className="mr-1" />
                    {product?.location}
                  </p>
                </div>

                {/* Scores */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <div className="text-lg font-bold text-success">
                      {product?.purityScore}%
                    </div>
                    <div className="text-xs text-text-secondary">Purity</div>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <div className="text-lg font-bold text-primary">
                      {product?.sustainabilityScore}%
                    </div>
                    <div className="text-xs text-text-secondary">Sustainability</div>
                  </div>
                </div>

                {/* Certifications */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-1">
                    {product?.certifications?.slice(0, 2)?.map((cert, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-success/10 text-success text-xs font-medium rounded border border-success/20"
                      >
                        {cert}
                      </span>
                    ))}
                    {product?.certifications?.length > 2 && (
                      <span className="px-2 py-1 bg-muted text-text-secondary text-xs rounded">
                        +{product?.certifications?.length - 2}
                      </span>
                    )}
                  </div>
                </div>

                {/* Dates */}
                <div className="text-xs text-text-secondary mb-4">
                  <div>Saved: {formatDate(product?.savedDate)}</div>
                  <div>Last viewed: {formatDate(product?.lastViewed)}</div>
                </div>

                {/* Actions */}
                <Button
                  variant="default"
                  fullWidth
                  onClick={() => onProductSelect?.(product)}
                  className="bg-primary hover:bg-primary/90"
                >
                  View Details
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
      {/* Summary Stats */}
      <div className="mt-8 p-6 bg-muted rounded-xl">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-2xl font-bold text-text-primary">
              {savedProducts?.length}
            </div>
            <div className="text-sm text-text-secondary">Total Saved</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-error">
              {savedProducts?.filter(p => p?.isFavorite)?.length}
            </div>
            <div className="text-sm text-text-secondary">Favorites</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-success">
              {Math.round(savedProducts?.reduce((acc, p) => acc + p?.purityScore, 0) / savedProducts?.length)}%
            </div>
            <div className="text-sm text-text-secondary">Avg Purity</div>
          </div>
          <div>
            <div className="text-2xl font-bold text-primary">
              {Math.round(savedProducts?.reduce((acc, p) => acc + p?.sustainabilityScore, 0) / savedProducts?.length)}%
            </div>
            <div className="text-sm text-text-secondary">Avg Sustainability</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SavedProductsList;