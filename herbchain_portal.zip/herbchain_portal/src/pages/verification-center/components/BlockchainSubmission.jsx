import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const BlockchainSubmission = ({ onNext, onBack, submissionData }) => {
  const [submissionStatus, setSubmissionStatus] = useState('preparing'); // preparing, submitting, confirming, completed
  const [progress, setProgress] = useState(0);
  const [estimatedTime, setEstimatedTime] = useState(180); // seconds
  const [transactionHash, setTransactionHash] = useState('');
  const [blockNumber, setBlockNumber] = useState('');

  const statusSteps = [
    { id: 'preparing', label: 'Preparing Data', icon: 'Package' },
    { id: 'encrypting', label: 'Encrypting Information', icon: 'Lock' },
    { id: 'distributing', label: 'Distributing to Network', icon: 'Network' },
    { id: 'confirming', label: 'Awaiting Confirmation', icon: 'Clock' },
    { id: 'completed', label: 'Verification Complete', icon: 'CheckCircle' }
  ];

  useEffect(() => {
    if (submissionStatus === 'preparing') {
      // Simulate preparation phase
      const timer = setTimeout(() => {
        setSubmissionStatus('submitting');
        setProgress(20);
      }, 2000);
      return () => clearTimeout(timer);
    }
    
    if (submissionStatus === 'submitting') {
      // Simulate blockchain submission
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 80) {
            setSubmissionStatus('confirming');
            setTransactionHash('0x7a8b9c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b');
            setEstimatedTime(120);
            clearInterval(interval);
            return 80;
          }
          return prev + 2;
        });
      }, 100);
      return () => clearInterval(interval);
    }
    
    if (submissionStatus === 'confirming') {
      // Simulate confirmation waiting
      const interval = setInterval(() => {
        setEstimatedTime(prev => {
          if (prev <= 0) {
            setSubmissionStatus('completed');
            setProgress(100);
            setBlockNumber('15,847,392');
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
        
        setProgress(prev => Math.min(prev + 0.2, 95));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [submissionStatus]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const getCurrentStepIndex = () => {
    switch (submissionStatus) {
      case 'preparing': return 0;
      case 'submitting': return submissionStatus === 'submitting' && progress < 40 ? 1 : 2;
      case 'confirming': return 3;
      case 'completed': return 4;
      default: return 0;
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="Zap" size={20} className="text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-headline font-semibold text-text-primary">
            Blockchain Submission
          </h2>
          <p className="text-sm text-text-secondary">
            Securing your harvest data on the blockchain
          </p>
        </div>
      </div>
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-text-primary">
            Verification Progress
          </span>
          <span className="text-sm text-text-secondary">
            {progress}%
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-3">
          <div 
            className="bg-gradient-to-r from-primary to-success h-3 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>
      {/* Status Steps */}
      <div className="space-y-4 mb-8">
        {statusSteps?.map((step, index) => {
          const currentIndex = getCurrentStepIndex();
          const isActive = index === currentIndex;
          const isCompleted = index < currentIndex;
          const isPending = index > currentIndex;
          
          return (
            <div key={step?.id} className={`flex items-center space-x-4 p-4 rounded-lg transition-all ${
              isActive ? 'bg-primary/5 border border-primary/20' :
              isCompleted ? 'bg-success/5 border border-success/20': 'bg-muted/50 border border-transparent'
            }`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                isActive ? 'bg-primary text-white animate-pulse' :
                isCompleted ? 'bg-success text-white': 'bg-muted text-text-secondary'
              }`}>
                {isCompleted ? (
                  <Icon name="Check" size={20} />
                ) : (
                  <Icon name={step?.icon} size={20} />
                )}
              </div>
              <div className="flex-1">
                <h3 className={`font-medium ${
                  isActive ? 'text-primary' :
                  isCompleted ? 'text-success': 'text-text-secondary'
                }`}>
                  {step?.label}
                </h3>
                
                {isActive && submissionStatus === 'confirming' && (
                  <p className="text-sm text-text-secondary">
                    Estimated time remaining: {formatTime(estimatedTime)}
                  </p>
                )}
                
                {isActive && submissionStatus === 'submitting' && (
                  <p className="text-sm text-text-secondary">
                    Processing your verification data...
                  </p>
                )}
              </div>
              {isActive && (
                <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              )}
            </div>
          );
        })}
      </div>
      {/* Transaction Details */}
      {transactionHash && (
        <div className="bg-muted rounded-lg p-4 mb-6">
          <h3 className="font-medium text-text-primary mb-3">
            Transaction Details
          </h3>
          
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-text-secondary">Transaction Hash:</span>
              <span className="font-mono text-text-primary break-all">
                {transactionHash?.slice(0, 20)}...
              </span>
            </div>
            
            {blockNumber && (
              <div className="flex justify-between">
                <span className="text-text-secondary">Block Number:</span>
                <span className="font-mono text-text-primary">
                  {blockNumber}
                </span>
              </div>
            )}
            
            <div className="flex justify-between">
              <span className="text-text-secondary">Network:</span>
              <span className="text-text-primary">HerbChain Mainnet</span>
            </div>
            
            <div className="flex justify-between">
              <span className="text-text-secondary">Gas Fee:</span>
              <span className="text-text-primary">0.0023 ETH</span>
            </div>
          </div>
        </div>
      )}
      {/* Completion Message */}
      {submissionStatus === 'completed' && (
        <div className="bg-success/10 border border-success/20 rounded-lg p-6 mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-success rounded-full flex items-center justify-center">
              <Icon name="CheckCircle" size={24} className="text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-success">
                Verification Complete!
              </h3>
              <p className="text-sm text-text-secondary">
                Your harvest has been successfully recorded on the blockchain
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
            <div className="bg-white rounded-lg p-4">
              <div className="text-2xl font-bold text-primary mb-1">
                +$127.50
              </div>
              <div className="text-sm text-text-secondary">
                Estimated Premium
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <div className="text-2xl font-bold text-success mb-1">
                98.7%
              </div>
              <div className="text-sm text-text-secondary">
                Quality Score
              </div>
            </div>
            
            <div className="bg-white rounded-lg p-4">
              <div className="text-2xl font-bold text-accent mb-1">
                #VH2024-0892
              </div>
              <div className="text-sm text-text-secondary">
                Verification ID
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Summary Data */}
      <div className="bg-muted/50 rounded-lg p-4 mb-6">
        <h3 className="font-medium text-text-primary mb-3">
          Verification Summary
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-text-secondary">Farm:</span>
            <span className="ml-2 text-text-primary">Green Valley Herbs</span>
          </div>
          <div>
            <span className="text-text-secondary">Herb:</span>
            <span className="ml-2 text-text-primary">Organic Basil</span>
          </div>
          <div>
            <span className="text-text-secondary">Quantity:</span>
            <span className="ml-2 text-text-primary">50 lbs</span>
          </div>
          <div>
            <span className="text-text-secondary">Grade:</span>
            <span className="ml-2 text-text-primary">Premium Grade A</span>
          </div>
        </div>
      </div>
      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={onBack}
          iconName="ArrowLeft"
          iconPosition="left"
          disabled={submissionStatus === 'submitting' || submissionStatus === 'confirming'}
        >
          Back
        </Button>
        
        <Button
          variant="default"
          onClick={onNext}
          iconName="ArrowRight"
          iconPosition="right"
          disabled={submissionStatus !== 'completed'}
          className="min-w-32"
        >
          Generate QR Code
        </Button>
      </div>
    </div>
  );
};

export default BlockchainSubmission;