import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const UserDataControl = () => {
  const [activeControl, setActiveControl] = useState('access');

  const dataControls = [
    {
      id: 'access',
      icon: 'Eye',
      title: 'Access Your Data',
      description: 'View and download all personal data we have collected about you',
      features: [
        'Complete data export in JSON format',
        'Blockchain transaction history',
        'Account activity logs',
        'Communication preferences'
      ]
    },
    {
      id: 'correct',
      icon: 'Edit',
      title: 'Correct Information',
      description: 'Update or correct any inaccurate personal information in your profile',
      features: [
        'Edit profile information',
        'Update contact details',
        'Correct farm location data',
        'Modify certification records'
      ]
    },
    {
      id: 'restrict',
      icon: 'Shield',
      title: 'Restrict Processing',
      description: 'Limit how we use your data in certain circumstances',
      features: [
        'Pause marketing communications',
        'Limit data sharing with partners',
        'Restrict analytics tracking',
        'Control research participation'
      ]
    },
    {
      id: 'delete',
      icon: 'Trash2',
      title: 'Delete Account',
      description: 'Request deletion of your account and associated personal data',
      features: [
        'Complete account removal',
        'Personal data deletion',
        'Blockchain records anonymization',
        'Communication history removal'
      ]
    }
  ];

  const dataCategories = [
    {
      icon: 'User',
      category: 'Personal Information',
      description: 'Name, email, phone, and contact details',
      retention: '7 years after account closure',
      userControl: 'Full control - edit, export, or delete',
      blockchainStored: false
    },
    {
      icon: 'MapPin',
      category: 'Location Data',
      description: 'Farm coordinates and regional information',
      retention: 'Permanent for traceability compliance',
      userControl: 'View and export only',
      blockchainStored: true
    },
    {
      icon: 'Leaf',
      category: 'Agricultural Records',
      description: 'Harvest data, quality metrics, and certifications',
      retention: 'Permanent for food safety compliance',
      userControl: 'View, export, and correct errors',
      blockchainStored: true
    },
    {
      icon: 'Activity',
      category: 'Usage Analytics',
      description: 'Platform interaction and behavior data',
      retention: '2 years for service improvement',
      userControl: 'Opt-out and deletion available',
      blockchainStored: false
    }
  ];

  const exportOptions = [
    {
      format: 'JSON',
      description: 'Machine-readable format for technical users',
      includes: 'All data fields with metadata'
    },
    {
      format: 'CSV',
      description: 'Spreadsheet format for easy viewing',
      includes: 'Tabular data without nested structures'
    },
    {
      format: 'PDF',
      description: 'Human-readable report format',
      includes: 'Formatted summary with explanations'
    }
  ];

  const deletionProcess = [
    {
      step: 1,
      title: 'Request Submission',
      description: 'Submit deletion request through secure portal',
      timeframe: 'Immediate'
    },
    {
      step: 2,
      title: 'Identity Verification',
      description: 'Verify your identity to prevent unauthorized deletions',
      timeframe: '1-2 business days'
    },
    {
      step: 3,
      title: 'Data Assessment',
      description: 'Review data for legal retention requirements',
      timeframe: '3-5 business days'
    },
    {
      step: 4,
      title: 'Deletion Execution',
      description: 'Remove personal data while preserving compliance records',
      timeframe: '7-14 business days'
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            User Data Control
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            Complete control over your personal data with transparent policies about what we collect, how long we keep it, and your options for managing it.
          </p>
        </div>

        {/* Data Control Options */}
        <div className="mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Your Data Rights
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Control Options */}
            <div className="space-y-4">
              {dataControls?.map((control) => (
                <div
                  key={control?.id}
                  onClick={() => setActiveControl(control?.id)}
                  className={`p-6 rounded-xl border cursor-pointer transition-smooth ${
                    activeControl === control?.id
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 bg-card'
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      activeControl === control?.id ? 'bg-primary text-white' : 'bg-muted text-text-secondary'
                    }`}>
                      <Icon name={control?.icon} size={24} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-text-primary mb-2">{control?.title}</h4>
                      <p className="text-sm text-text-secondary">{control?.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Active Control Details */}
            <div className="bg-card rounded-xl p-8 border border-border">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center">
                  <Icon name={dataControls?.find(c => c?.id === activeControl)?.icon} size={32} className="text-white" />
                </div>
                <div>
                  <h4 className="font-headline text-xl font-semibold text-text-primary">
                    {dataControls?.find(c => c?.id === activeControl)?.title}
                  </h4>
                  <p className="text-text-secondary">
                    {dataControls?.find(c => c?.id === activeControl)?.description}
                  </p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {dataControls?.find(c => c?.id === activeControl)?.features?.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <Icon name="Check" size={16} className="text-success" />
                    <span className="text-text-secondary">{feature}</span>
                  </div>
                ))}
              </div>

              <Button variant="default" className="w-full">
                <Icon name="ArrowRight" size={16} className="mr-2" />
                {activeControl === 'access' && 'Request Data Export'}
                {activeControl === 'correct' && 'Update Information'}
                {activeControl === 'restrict' && 'Manage Restrictions'}
                {activeControl === 'delete' && 'Delete Account'}
              </Button>
            </div>
          </div>
        </div>

        {/* Data Categories */}
        <div className="mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Data Categories & Retention
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {dataCategories?.map((category, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border">
                <div className="flex items-start space-x-4 mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={category?.icon} size={24} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-semibold text-text-primary">{category?.category}</h4>
                      {category?.blockchainStored && (
                        <span className="px-2 py-1 bg-accent/10 text-accent text-xs rounded-full">
                          Blockchain
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-text-secondary mb-4">{category?.description}</p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="bg-muted/50 rounded-lg p-3">
                    <div className="text-xs font-medium text-text-primary mb-1">Retention Period</div>
                    <div className="text-sm text-text-secondary">{category?.retention}</div>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-3">
                    <div className="text-xs font-medium text-text-primary mb-1">Your Control</div>
                    <div className="text-sm text-text-secondary">{category?.userControl}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Export Options */}
        <div className="mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Data Export Options
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {exportOptions?.map((option, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border text-center hover:shadow-warm transition-smooth">
                <div className="w-16 h-16 bg-accent/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Icon name="Download" size={32} className="text-accent" />
                </div>
                <h4 className="font-semibold text-text-primary mb-2">{option?.format}</h4>
                <p className="text-sm text-text-secondary mb-4">{option?.description}</p>
                <div className="bg-muted/50 rounded-lg p-3">
                  <div className="text-xs text-text-secondary">{option?.includes}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Deletion Process */}
        <div className="bg-card rounded-2xl p-8 lg:p-12 border border-border">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Account Deletion Process
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {deletionProcess?.map((step, index) => (
              <div key={step?.step} className="text-center">
                <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-white">{step?.step}</span>
                </div>
                <h4 className="font-semibold text-text-primary mb-2">{step?.title}</h4>
                <p className="text-sm text-text-secondary mb-3">{step?.description}</p>
                <span className="text-xs text-accent font-medium bg-accent/10 px-3 py-1 rounded-full">
                  {step?.timeframe}
                </span>
              </div>
            ))}
          </div>

          <div className="bg-warning/10 rounded-lg p-6 mb-6">
            <div className="flex items-start space-x-3">
              <Icon name="AlertTriangle" size={20} className="text-warning mt-1 flex-shrink-0" />
              <div>
                <h5 className="font-semibold text-text-primary mb-2">Important Notice</h5>
                <p className="text-sm text-text-secondary">
                  Some data may be retained for legal compliance (food safety regulations, blockchain immutability). 
                  Personal identifiers will be removed while preserving necessary traceability records.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Button variant="destructive">
              <Icon name="Trash2" size={16} className="mr-2" />
              Request Account Deletion
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UserDataControl;