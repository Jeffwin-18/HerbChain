import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import QRScannerCamera from './components/QRScannerCamera';
import HerbJourneyTimeline from './components/HerbJourneyTimeline';
import FarmerProfileCard from './components/FarmerProfileCard';
import QualityTestResults from './components/QualityTestResults';
import BlockchainVerification from './components/BlockchainVerification';
import SocialSharingPanel from './components/SocialSharingPanel';
import SavedProductsList from './components/SavedProductsList';

const ConsumerQRScanner = () => {
  const [currentView, setCurrentView] = useState('scanner');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showOfflineMessage, setShowOfflineMessage] = useState(false);

  // Check online status
  useEffect(() => {
    const handleOnline = () => setShowOfflineMessage(false);
    const handleOffline = () => setShowOfflineMessage(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleStartScan = () => {
    setIsScanning(true);
    setScanResult(null);
  };

  const handleStopScan = () => {
    setIsScanning(false);
  };

  const handleScanResult = async (result) => {
    setIsLoading(true);
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setScanResult({
      ...result,
      herbData: {
        herbType: 'Organic Basil',
        batchId: 'BATCH-789',
        farmId: 'FARM-001',
        harvestDate: '2024-05-15',
        verificationStatus: 'verified'
      }
    });
    
    setCurrentView('results');
    setIsLoading(false);
  };

  const handleMessageFarmer = (farmerData) => {
    // In a real app, this would open a messaging interface
    console.log('Message farmer:', farmerData);
    alert(`Message feature would open for ${farmerData?.name}`);
  };

  const handleShare = (platform, message) => {
    console.log('Shared on:', platform, message);
    // In a real app, this would track sharing analytics
  };

  const handleProductSelect = (product) => {
    setScanResult({
      qrCode: product?.qrCode,
      herbData: {
        herbType: product?.herbName,
        farmName: product?.farmName,
        farmer: product?.farmer
      }
    });
    setCurrentView('results');
  };

  const handleRemoveProduct = (productId) => {
    console.log('Remove product:', productId);
    // In a real app, this would remove from saved products
  };

  const navigationTabs = [
    { id: 'scanner', label: 'QR Scanner', icon: 'QrCode' },
    { id: 'saved', label: 'Saved Products', icon: 'Bookmark' },
    { id: 'results', label: 'Verification Results', icon: 'Shield', disabled: !scanResult }
  ];

  const resultTabs = [
    { id: 'journey', label: 'Herb Journey', icon: 'Route' },
    { id: 'farmer', label: 'Meet the Farmer', icon: 'User' },
    { id: 'quality', label: 'Quality Tests', icon: 'FlaskConical' },
    { id: 'blockchain', label: 'Blockchain Proof', icon: 'Shield' },
    { id: 'share', label: 'Share Discovery', icon: 'Share' }
  ];

  const [activeResultTab, setActiveResultTab] = useState('journey');

  const renderContent = () => {
    if (currentView === 'scanner') {
      return (
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-headline font-bold text-text-primary mb-4">
              Discover Your Herb's Journey
            </h1>
            <p className="text-lg text-text-secondary max-w-2xl mx-auto">
              Scan any HerbChain QR code to reveal the complete story behind your herbs - 
              from seed to shelf with blockchain-verified authenticity.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Scanner */}
            <div>
              <QRScannerCamera
                onScanResult={handleScanResult}
                isScanning={isScanning}
                onStartScan={handleStartScan}
                onStopScan={handleStopScan}
              />
            </div>

            {/* Features */}
            <div className="space-y-6">
              <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
                <h3 className="text-xl font-headline font-semibold text-text-primary mb-4">
                  What You'll Discover
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon name="Route" size={20} className="text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary mb-1">Complete Journey Timeline</h4>
                      <p className="text-sm text-text-secondary">
                        From planting to harvest, see every step of your herb's growth
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                      <Icon name="User" size={20} className="text-success" />
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary mb-1">Meet Your Farmer</h4>
                      <p className="text-sm text-text-secondary">
                        Connect with the passionate growers behind your food
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                      <Icon name="FlaskConical" size={20} className="text-accent" />
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary mb-1">Quality Verification</h4>
                      <p className="text-sm text-text-secondary">
                        Lab-tested purity and nutritional analysis results
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                      <Icon name="Shield" size={20} className="text-warning" />
                    </div>
                    <div>
                      <h4 className="font-medium text-text-primary mb-1">Blockchain Proof</h4>
                      <p className="text-sm text-text-secondary">
                        Immutable verification that can't be faked or altered
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-card rounded-lg border border-border p-4 text-center">
                  <div className="text-2xl font-bold text-primary mb-1">15,847</div>
                  <div className="text-sm text-text-secondary">Products Verified</div>
                </div>
                <div className="bg-card rounded-lg border border-border p-4 text-center">
                  <div className="text-2xl font-bold text-success mb-1">1,234</div>
                  <div className="text-sm text-text-secondary">Trusted Farms</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (currentView === 'saved') {
      return (
        <SavedProductsList
          onProductSelect={handleProductSelect}
          onRemoveProduct={handleRemoveProduct}
        />
      );
    }

    if (currentView === 'results' && scanResult) {
      return (
        <div className="max-w-6xl mx-auto">
          {/* Results Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-success/10 text-success rounded-full text-sm font-medium mb-4">
              <Icon name="CheckCircle" size={16} />
              Verification Complete
            </div>
            <h1 className="text-3xl md:text-4xl font-headline font-bold text-text-primary mb-2">
              {scanResult?.herbData?.herbType || 'Verified Product'}
            </h1>
            <p className="text-lg text-text-secondary">
              QR Code: {scanResult?.qrCode}
            </p>
          </div>
          {/* Result Tabs */}
          <div className="flex flex-wrap gap-2 mb-8 border-b border-border">
            {resultTabs?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveResultTab(tab?.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-t-lg transition-smooth ${
                  activeResultTab === tab?.id
                    ? 'bg-primary text-primary-foreground border-b-2 border-primary'
                    : 'text-text-secondary hover:text-text-primary hover:bg-muted'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                {tab?.label}
              </button>
            ))}
          </div>
          {/* Result Content */}
          <div className="mb-8">
            {activeResultTab === 'journey' && (
              <HerbJourneyTimeline herbData={scanResult?.herbData} />
            )}
            {activeResultTab === 'farmer' && (
              <FarmerProfileCard
                farmer={scanResult?.herbData}
                onMessageFarmer={handleMessageFarmer}
              />
            )}
            {activeResultTab === 'quality' && (
              <QualityTestResults testData={scanResult?.herbData} />
            )}
            {activeResultTab === 'blockchain' && (
              <BlockchainVerification verificationData={scanResult} />
            )}
            {activeResultTab === 'share' && (
              <SocialSharingPanel
                herbData={scanResult?.herbData}
                onShare={handleShare}
              />
            )}
          </div>
          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              variant="outline"
              onClick={() => setCurrentView('scanner')}
              iconName="QrCode"
              iconPosition="left"
            >
              Scan Another Product
            </Button>
            <Button
              variant="default"
              iconName="Bookmark"
              iconPosition="left"
              className="bg-primary hover:bg-primary/90"
            >
              Save to Collection
            </Button>
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <>
      <Helmet>
        <title>QR Scanner - HerbChain Portal</title>
        <meta name="description" content="Scan QR codes to discover the complete journey of your herbs from farm to table with blockchain verification." />
        <meta name="keywords" content="QR scanner, herb verification, blockchain, traceability, organic herbs" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Header />
        
        {/* Offline Message */}
        {showOfflineMessage && (
          <div className="fixed top-16 left-0 right-0 z-40 bg-warning text-warning-foreground px-4 py-2 text-center text-sm">
            <Icon name="WifiOff" size={16} className="inline mr-2" />
            You're offline. Some features may be limited. Cached results are still available.
          </div>
        )}

        <main className="pt-16">
          <div className="container mx-auto px-4 py-8">
            {/* Navigation Tabs */}
            <div className="flex flex-wrap gap-2 mb-8 justify-center">
              {navigationTabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => !tab?.disabled && setCurrentView(tab?.id)}
                  disabled={tab?.disabled}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth ${
                    currentView === tab?.id
                      ? 'bg-primary text-primary-foreground'
                      : tab?.disabled
                      ? 'text-text-secondary/50 cursor-not-allowed' :'text-text-secondary hover:text-text-primary hover:bg-muted'
                  }`}
                >
                  <Icon name={tab?.icon} size={16} />
                  {tab?.label}
                </button>
              ))}
            </div>

            {/* Loading Overlay */}
            {isLoading && (
              <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
                <div className="bg-card rounded-xl border border-border p-8 text-center shadow-warm">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                  <h3 className="text-lg font-medium text-text-primary mb-2">
                    Verifying Product...
                  </h3>
                  <p className="text-text-secondary">
                    Checking blockchain records and quality data
                  </p>
                </div>
              </div>
            )}

            {/* Content */}
            {renderContent()}
          </div>
        </main>

        {/* Footer */}
        <footer className="bg-muted border-t border-border mt-16">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center">
              <p className="text-text-secondary text-sm">
                © {new Date()?.getFullYear()} HerbChain Portal. Empowering transparency in agriculture.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
};

export default ConsumerQRScanner;