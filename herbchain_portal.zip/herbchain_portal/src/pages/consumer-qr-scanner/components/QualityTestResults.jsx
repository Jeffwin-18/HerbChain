import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const QualityTestResults = ({ testData }) => {
  const [activeTab, setActiveTab] = useState('purity');

  const qualityData = {
    purity: {
      score: 99.8,
      status: 'Excellent',
      details: [
        { name: 'Heavy Metals', value: 0.001, limit: 0.1, unit: 'ppm', status: 'pass' },
        { name: 'Pesticides', value: 0, limit: 0.01, unit: 'ppm', status: 'pass' },
        { name: 'Microbial', value: 0.02, limit: 10, unit: 'cfu/g', status: 'pass' },
        { name: 'Moisture', value: 8.5, limit: 12, unit: '%', status: 'pass' }
      ]
    },
    nutrients: {
      score: 94.2,
      status: 'High',
      details: [
        { name: 'Vitamin C', value: 18.2, standard: 15, unit: 'mg/100g', status: 'above' },
        { name: 'Iron', value: 3.17, standard: 2.5, unit: 'mg/100g', status: 'above' },
        { name: 'Calcium', value: 177, standard: 150, unit: 'mg/100g', status: 'above' },
        { name: 'Antioxidants', value: 92, standard: 80, unit: 'ORAC', status: 'above' }
      ]
    },
    sustainability: {
      score: 95.5,
      status: 'Outstanding',
      details: [
        { name: 'Water Usage', value: 15, benchmark: 25, unit: 'L/kg', status: 'efficient' },
        { name: 'Carbon Footprint', value: 0.8, benchmark: 1.5, unit: 'kg CO2/kg', status: 'low' },
        { name: 'Soil Health', value: 9.2, benchmark: 7, unit: 'pH', status: 'optimal' },
        { name: 'Biodiversity', value: 85, benchmark: 60, unit: 'index', status: 'high' }
      ]
    }
  };

  const chartData = qualityData?.[activeTab]?.details?.map(item => ({
    name: item?.name,
    value: item?.value,
    benchmark: item?.standard || item?.limit || item?.benchmark,
    status: item?.status
  }));

  const getStatusColor = (status) => {
    switch (status) {
      case 'pass': case'above': case'efficient': case'low': case'optimal': case'high':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'fail':
        return 'text-error';
      default:
        return 'text-text-secondary';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'pass': case'above': case'efficient': case'low': case'optimal': case'high':
        return 'bg-success/10 border-success/20';
      case 'warning':
        return 'bg-warning/10 border-warning/20';
      case 'fail':
        return 'bg-error/10 border-error/20';
      default:
        return 'bg-muted border-border';
    }
  };

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 70) return 'text-warning';
    return 'text-error';
  };

  const tabs = [
    { id: 'purity', label: 'Purity Analysis', icon: 'FlaskConical' },
    { id: 'nutrients', label: 'Nutritional Profile', icon: 'Activity' },
    { id: 'sustainability', label: 'Sustainability Metrics', icon: 'Leaf' }
  ];

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <h3 className="text-2xl font-headline font-bold text-text-primary mb-2">
          Quality Test Results
        </h3>
        <p className="text-text-secondary">
          Comprehensive laboratory analysis and sustainability assessment
        </p>
      </div>
      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-border">
        {tabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => setActiveTab(tab?.id)}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-medium rounded-t-lg transition-smooth ${
              activeTab === tab?.id
                ? 'bg-primary text-primary-foreground border-b-2 border-primary'
                : 'text-text-secondary hover:text-text-primary hover:bg-muted'
            }`}
          >
            <Icon name={tab?.icon} size={16} />
            {tab?.label}
          </button>
        ))}
      </div>
      {/* Content */}
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
        {/* Score Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h4 className="text-lg font-headline font-semibold text-text-primary mb-1">
              {tabs?.find(t => t?.id === activeTab)?.label}
            </h4>
            <p className="text-text-secondary text-sm">
              Overall {activeTab} assessment
            </p>
          </div>
          <div className="text-right">
            <div className={`text-3xl font-bold ${getScoreColor(qualityData?.[activeTab]?.score)}`}>
              {qualityData?.[activeTab]?.score}%
            </div>
            <div className={`text-sm font-medium ${getScoreColor(qualityData?.[activeTab]?.score)}`}>
              {qualityData?.[activeTab]?.status}
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="mb-6">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="name" 
                  tick={{ fontSize: 12, fill: 'var(--color-text-secondary)' }}
                  axisLine={{ stroke: 'var(--color-border)' }}
                />
                <YAxis 
                  tick={{ fontSize: 12, fill: 'var(--color-text-secondary)' }}
                  axisLine={{ stroke: 'var(--color-border)' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'var(--color-card)',
                    border: '1px solid var(--color-border)',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="value" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="benchmark" fill="var(--color-muted)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed Results */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {qualityData?.[activeTab]?.details?.map((item, index) => (
            <div key={index} className={`p-4 rounded-lg border ${getStatusBg(item?.status)}`}>
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-medium text-text-primary">{item?.name}</h5>
                <Icon 
                  name={item?.status === 'pass' || item?.status === 'above' || item?.status === 'efficient' || item?.status === 'low' || item?.status === 'optimal' || item?.status === 'high' ? 'CheckCircle' : 'AlertCircle'} 
                  size={16} 
                  className={getStatusColor(item?.status)}
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-text-primary">
                  {item?.value} {item?.unit}
                </span>
                <span className="text-sm text-text-secondary">
                  {activeTab === 'purity' ? 'Limit' : 'Standard'}: {item?.standard || item?.limit || item?.benchmark} {item?.unit}
                </span>
              </div>
              <div className="mt-2">
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      item?.status === 'pass' || item?.status === 'above' || item?.status === 'efficient' || item?.status === 'low' || item?.status === 'optimal' || item?.status === 'high' ?'bg-success' :'bg-warning'
                    }`}
                    style={{ 
                      width: `${Math.min((item?.value / (item?.standard || item?.limit || item?.benchmark)) * 100, 100)}%` 
                    }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Certification Info */}
        <div className="mt-6 p-4 bg-muted rounded-lg">
          <div className="flex items-start gap-3">
            <Icon name="Award" size={20} className="text-warning mt-0.5" />
            <div>
              <h5 className="font-medium text-text-primary mb-1">
                Laboratory Certification
              </h5>
              <p className="text-sm text-text-secondary mb-2">
                Tests conducted by ISO 17025 certified laboratory - AgriTest Labs
              </p>
              <div className="flex items-center gap-4 text-xs text-text-secondary">
                <span>Test Date: {new Date()?.toLocaleDateString()}</span>
                <span>Certificate ID: QT-2024-{Math.random()?.toString(36)?.substr(2, 9)?.toUpperCase()}</span>
                <span>Valid Until: {new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)?.toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QualityTestResults;