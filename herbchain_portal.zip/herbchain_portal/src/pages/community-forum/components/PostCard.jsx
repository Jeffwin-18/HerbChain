import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const PostCard = ({ post, onClick }) => {
  const getStatusBadge = (status) => {
    const badges = {
      'verified-farmer': { color: 'bg-success/10 text-success', icon: 'Shield', label: 'Verified Farmer' },
      'expert': { color: 'bg-accent/10 text-accent', icon: 'Award', label: 'Expert' },
      'consumer': { color: 'bg-secondary/10 text-secondary', icon: 'User', label: 'Consumer' },
      'moderator': { color: 'bg-warning/10 text-warning', icon: 'Crown', label: 'Moderator' }
    };
    
    const badge = badges?.[status] || badges?.consumer;
    
    return (
      <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${badge?.color}`}>
        <Icon name={badge?.icon} size={12} />
        <span>{badge?.label}</span>
      </div>
    );
  };

  return (
    <div 
      onClick={() => onClick(post)}
      className="bg-card border border-border rounded-lg p-6 cursor-pointer transition-smooth hover:shadow-warm hover:border-primary/20 group"
    >
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
            {post?.author?.avatar ? (
              <Image 
                src={post?.author?.avatar} 
                alt={post?.author?.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-lg font-semibold text-primary">
                {post?.author?.name?.charAt(0)}
              </span>
            )}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-2">
            <h4 className="font-medium text-text-primary group-hover:text-primary transition-smooth">
              {post?.author?.name}
            </h4>
            {getStatusBadge(post?.author?.status)}
            {post?.author?.location && (
              <div className="flex items-center space-x-1 text-xs text-text-secondary">
                <Icon name="MapPin" size={12} />
                <span>{post?.author?.location}</span>
              </div>
            )}
          </div>
          
          <h3 className="font-headline font-semibold text-lg text-text-primary mb-2 group-hover:text-primary transition-smooth line-clamp-2">
            {post?.title}
          </h3>
          
          <p className="text-text-secondary text-sm mb-4 line-clamp-3">
            {post?.content}
          </p>
          
          {post?.images && post?.images?.length > 0 && (
            <div className="flex space-x-2 mb-4">
              {post?.images?.slice(0, 3)?.map((image, index) => (
                <div key={index} className="w-16 h-16 rounded-lg overflow-hidden bg-muted">
                  <Image 
                    src={image} 
                    alt={`Post image ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {post?.images?.length > 3 && (
                <div className="w-16 h-16 rounded-lg bg-muted flex items-center justify-center">
                  <span className="text-xs text-text-secondary font-medium">
                    +{post?.images?.length - 3}
                  </span>
                </div>
              )}
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1 text-sm text-text-secondary">
                <Icon name="MessageCircle" size={16} />
                <span>{post?.replies}</span>
              </div>
              <div className="flex items-center space-x-1 text-sm text-text-secondary">
                <Icon name="Heart" size={16} />
                <span>{post?.likes}</span>
              </div>
              <div className="flex items-center space-x-1 text-sm text-text-secondary">
                <Icon name="Eye" size={16} />
                <span>{post?.views}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2 text-xs text-text-secondary">
              <Icon name="Clock" size={14} />
              <span>{post?.timeAgo}</span>
            </div>
          </div>
          
          {post?.tags && post?.tags?.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {post?.tags?.map((tag, index) => (
                <span key={index} className="px-2 py-1 bg-muted text-text-secondary text-xs rounded-full">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PostCard;