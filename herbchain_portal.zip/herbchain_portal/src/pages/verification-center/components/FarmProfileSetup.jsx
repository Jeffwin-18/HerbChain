import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const FarmProfileSetup = ({ onNext, farmData, setFarmData }) => {
  const [errors, setErrors] = useState({});

  const farmTypes = [
    { value: 'organic', label: 'Organic Farm' },
    { value: 'conventional', label: 'Conventional Farm' },
    { value: 'biodynamic', label: 'Biodynamic Farm' },
    { value: 'hydroponic', label: 'Hydroponic Farm' },
    { value: 'greenhouse', label: 'Greenhouse Operation' }
  ];

  const certifications = [
    { value: 'usda-organic', label: 'USDA Organic' },
    { value: 'gmp', label: 'Good Manufacturing Practice (GMP)' },
    { value: 'gap', label: 'Good Agricultural Practice (GAP)' },
    { value: 'fair-trade', label: 'Fair Trade Certified' },
    { value: 'rainforest', label: 'Rainforest Alliance' },
    { value: 'none', label: 'No Certification' }
  ];

  const handleInputChange = (field, value) => {
    setFarmData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Clear error when user starts typing
    if (errors?.[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!farmData?.farmName?.trim()) {
      newErrors.farmName = 'Farm name is required';
    }
    
    if (!farmData?.ownerName?.trim()) {
      newErrors.ownerName = 'Owner name is required';
    }
    
    if (!farmData?.location?.trim()) {
      newErrors.location = 'Farm location is required';
    }
    
    if (!farmData?.farmType) {
      newErrors.farmType = 'Please select farm type';
    }
    
    if (!farmData?.farmSize?.trim()) {
      newErrors.farmSize = 'Farm size is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleNext = () => {
    if (validateForm()) {
      onNext();
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="MapPin" size={20} className="text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-headline font-semibold text-text-primary">
            Farm Profile Setup
          </h2>
          <p className="text-sm text-text-secondary">
            Tell us about your farm to get started with verification
          </p>
        </div>
      </div>
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Input
            label="Farm Name"
            type="text"
            placeholder="Enter your farm name"
            value={farmData?.farmName || ''}
            onChange={(e) => handleInputChange('farmName', e?.target?.value)}
            error={errors?.farmName}
            required
            className="lg:col-span-1"
          />
          
          <Input
            label="Owner/Manager Name"
            type="text"
            placeholder="Enter owner or manager name"
            value={farmData?.ownerName || ''}
            onChange={(e) => handleInputChange('ownerName', e?.target?.value)}
            error={errors?.ownerName}
            required
            className="lg:col-span-1"
          />
        </div>

        <Input
          label="Farm Location"
          type="text"
          placeholder="Enter complete farm address"
          description="Include city, state, and postal code for accurate location"
          value={farmData?.location || ''}
          onChange={(e) => handleInputChange('location', e?.target?.value)}
          error={errors?.location}
          required
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Select
            label="Farm Type"
            placeholder="Select farm type"
            options={farmTypes}
            value={farmData?.farmType || ''}
            onChange={(value) => handleInputChange('farmType', value)}
            error={errors?.farmType}
            required
            className="lg:col-span-1"
          />
          
          <Input
            label="Farm Size"
            type="text"
            placeholder="e.g., 5 acres, 2 hectares"
            value={farmData?.farmSize || ''}
            onChange={(e) => handleInputChange('farmSize', e?.target?.value)}
            error={errors?.farmSize}
            required
            className="lg:col-span-1"
          />
        </div>

        <Select
          label="Primary Certification"
          placeholder="Select your primary certification"
          description="Choose the main certification your farm holds"
          options={certifications}
          value={farmData?.certification || ''}
          onChange={(value) => handleInputChange('certification', value)}
          className="w-full"
        />

        <Input
          label="Years in Operation"
          type="number"
          placeholder="Enter number of years"
          value={farmData?.yearsInOperation || ''}
          onChange={(e) => handleInputChange('yearsInOperation', e?.target?.value)}
          min="0"
          max="100"
        />

        <Input
          label="Contact Phone"
          type="tel"
          placeholder="Enter contact phone number"
          value={farmData?.contactPhone || ''}
          onChange={(e) => handleInputChange('contactPhone', e?.target?.value)}
        />

        <Input
          label="Contact Email"
          type="email"
          placeholder="Enter contact email address"
          value={farmData?.contactEmail || ''}
          onChange={(e) => handleInputChange('contactEmail', e?.target?.value)}
        />
      </div>
      <div className="flex justify-end mt-8">
        <Button
          variant="default"
          onClick={handleNext}
          iconName="ArrowRight"
          iconPosition="right"
          className="min-w-32"
        >
          Continue
        </Button>
      </div>
    </div>
  );
};

export default FarmProfileSetup;