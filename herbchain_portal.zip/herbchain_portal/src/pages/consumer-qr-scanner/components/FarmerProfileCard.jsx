import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const FarmerProfileCard = ({ farmer, onMessageFarmer }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const farmerData = {
    id: 'farmer-001',
    name: 'Maria Rodriguez',
    farmName: 'Green Valley Organic Farm',
    location: 'Sonoma County, California',
    experience: '15 years',
    certifications: ['USDA Organic', 'Fair Trade', 'Rainforest Alliance'],
    avatar: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=400&fit=crop&crop=face',
    coverImage: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&h=400&fit=crop',
    rating: 4.9,
    totalReviews: 247,
    specialties: ['Organic Herbs', 'Sustainable Farming', 'Heirloom Varieties'],
    farmSize: '25 acres',
    establishedYear: 2009,
    sustainabilityScore: 95,
    bio: `Maria has been pioneering sustainable herb farming in Sonoma County for over 15 years. Her commitment to organic practices and soil health has made Green Valley Farm a leader in premium herb production.\n\nShe specializes in growing heirloom varieties of basil, oregano, and thyme using traditional methods combined with modern sustainable techniques.`,
    achievements: [
      'Best Organic Farm 2023 - Sonoma County',
      'Sustainability Excellence Award 2022',
      'Featured in Organic Farming Magazine'
    ],
    socialMedia: {
      instagram: '@greenvalleyfarm',
      facebook: 'Green Valley Organic Farm',
      website: 'www.greenvalleyfarm.com'
    }
  };

  const handleMessageClick = () => {
    onMessageFarmer?.(farmerData);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-warm">
        {/* Cover Image */}
        <div className="relative h-48 bg-muted">
          <Image
            src={farmerData?.coverImage}
            alt={`${farmerData?.farmName} landscape`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          
          {/* Farm Name Overlay */}
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-headline font-bold text-white mb-1">
              {farmerData?.farmName}
            </h3>
            <p className="text-white/90 text-sm flex items-center">
              <Icon name="MapPin" size={16} className="mr-1" />
              {farmerData?.location}
            </p>
          </div>
        </div>

        {/* Profile Content */}
        <div className="p-6">
          {/* Farmer Info */}
          <div className="flex items-start gap-4 mb-6">
            <div className="relative">
              <Image
                src={farmerData?.avatar}
                alt={farmerData?.name}
                className="w-16 h-16 rounded-full object-cover border-4 border-background"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-success rounded-full border-2 border-background flex items-center justify-center">
                <Icon name="Check" size={12} className="text-white" />
              </div>
            </div>

            <div className="flex-1">
              <h4 className="text-lg font-headline font-bold text-text-primary mb-1">
                {farmerData?.name}
              </h4>
              <p className="text-text-secondary text-sm mb-2">
                {farmerData?.experience} of farming experience
              </p>
              
              {/* Rating */}
              <div className="flex items-center gap-2">
                <div className="flex items-center">
                  {[...Array(5)]?.map((_, i) => (
                    <Icon
                      key={i}
                      name="Star"
                      size={16}
                      className={i < Math.floor(farmerData?.rating) ? 'text-warning fill-current' : 'text-muted'}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium text-text-primary">
                  {farmerData?.rating}
                </span>
                <span className="text-sm text-text-secondary">
                  ({farmerData?.totalReviews} reviews)
                </span>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-lg font-bold text-primary mb-1">
                {farmerData?.farmSize}
              </div>
              <div className="text-xs text-text-secondary">Farm Size</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-lg font-bold text-success mb-1">
                {farmerData?.sustainabilityScore}%
              </div>
              <div className="text-xs text-text-secondary">Sustainability</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-lg font-bold text-accent mb-1">
                {new Date()?.getFullYear() - farmerData?.establishedYear}
              </div>
              <div className="text-xs text-text-secondary">Years Active</div>
            </div>
          </div>

          {/* Certifications */}
          <div className="mb-6">
            <h5 className="text-sm font-medium text-text-primary mb-3">Certifications</h5>
            <div className="flex flex-wrap gap-2">
              {farmerData?.certifications?.map((cert, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-success/10 text-success text-xs font-medium rounded-full border border-success/20"
                >
                  {cert}
                </span>
              ))}
            </div>
          </div>

          {/* Specialties */}
          <div className="mb-6">
            <h5 className="text-sm font-medium text-text-primary mb-3">Specialties</h5>
            <div className="flex flex-wrap gap-2">
              {farmerData?.specialties?.map((specialty, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full border border-primary/20"
                >
                  {specialty}
                </span>
              ))}
            </div>
          </div>

          {/* Bio */}
          <div className="mb-6">
            <h5 className="text-sm font-medium text-text-primary mb-3">About the Farmer</h5>
            <div className="text-sm text-text-secondary leading-relaxed">
              {isExpanded ? (
                <div>
                  {farmerData?.bio?.split('\n')?.map((paragraph, index) => (
                    <p key={index} className="mb-3 last:mb-0">
                      {paragraph}
                    </p>
                  ))}
                </div>
              ) : (
                <p>{farmerData?.bio?.split('\n')?.[0]}...</p>
              )}
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-primary hover:text-primary/80 text-sm font-medium mt-2 transition-smooth"
              >
                {isExpanded ? 'Show Less' : 'Read More'}
              </button>
            </div>
          </div>

          {/* Achievements */}
          {isExpanded && (
            <div className="mb-6">
              <h5 className="text-sm font-medium text-text-primary mb-3">Recent Achievements</h5>
              <div className="space-y-2">
                {farmerData?.achievements?.map((achievement, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm text-text-secondary">
                    <Icon name="Award" size={16} className="text-warning" />
                    {achievement}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              variant="default"
              className="flex-1 bg-primary hover:bg-primary/90"
              onClick={handleMessageClick}
              iconName="MessageCircle"
              iconPosition="left"
            >
              Message Farmer
            </Button>
            <Button
              variant="outline"
              iconName="Heart"
              className="px-4"
            >
            </Button>
            <Button
              variant="outline"
              iconName="Share"
              className="px-4"
            >
            </Button>
          </div>

          {/* Social Links */}
          {isExpanded && (
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center justify-center gap-4">
                <a
                  href={`https://instagram.com/${farmerData?.socialMedia?.instagram?.replace('@', '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-text-secondary hover:text-primary transition-smooth"
                >
                  <Icon name="Instagram" size={20} />
                </a>
                <a
                  href={`https://facebook.com/${farmerData?.socialMedia?.facebook}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-text-secondary hover:text-primary transition-smooth"
                >
                  <Icon name="Facebook" size={20} />
                </a>
                <a
                  href={`https://${farmerData?.socialMedia?.website}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-text-secondary hover:text-primary transition-smooth"
                >
                  <Icon name="Globe" size={20} />
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FarmerProfileCard;