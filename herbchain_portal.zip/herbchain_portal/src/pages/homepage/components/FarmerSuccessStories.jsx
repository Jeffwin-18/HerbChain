import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const FarmerSuccessStories = () => {
  const [currentStory, setCurrentStory] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const successStories = [
    {
      id: 1,
      name: "Maria Rodriguez",
      farm: "Green Valley Herbs",
      location: "California, USA",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&h=400&fit=crop",
      story: `"Before HerbChain, I struggled to get fair prices for my organic herbs. Buyers couldn't verify my quality claims, so I was competing on price alone.\n\nNow, with blockchain verification, my herbs command premium prices because customers can see my organic certifications, soil tests, and harvest dates. My income has increased by 40% in just one year."`,
      metrics: {
        incomeIncrease: "40%",
        premiumPrice: "$2.50/lb",
        yearJoined: 2023,
        verifications: 156
      },
      specialties: ["Organic Basil", "Rosemary", "Thyme"],
      achievements: ["Organic Certified", "Top Quality Rating", "Premium Partner"]
    },
    {
      id: 2,
      name: "James Thompson",
      farm: "Mountain Peak Farm",
      location: "Colorado, USA",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=600&h=400&fit=crop",
      story: `"As a third-generation farmer, I was skeptical about blockchain technology. But HerbChain made it simple and showed immediate results.\n\nThe transparency has built incredible trust with my customers. They can trace every herb back to the exact field where it grew. This connection has transformed my business from commodity farming to premium artisanal production."`,
      metrics: {
        incomeIncrease: "55%",
        premiumPrice: "$3.20/lb",
        yearJoined: 2022,
        verifications: 203
      },
      specialties: ["Wild Thyme", "Sage", "Lavender"],
      achievements: ["Heritage Farm", "Sustainability Leader", "Innovation Award"]
    },
    {
      id: 3,
      name: "Sarah Chen",
      farm: "Sunrise Botanicals",
      location: "Oregon, USA",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      coverImage: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&h=400&fit=crop",
      story: `"Starting as a small urban farm, I needed to differentiate myself in a crowded market. HerbChain's verification system became my competitive advantage.\n\nCustomers love scanning QR codes to see my growing methods, harvest dates, and quality tests. The trust this creates has allowed me to expand from farmers markets to supplying premium restaurants."`,
      metrics: {
        incomeIncrease: "65%",
        premiumPrice: "$4.10/lb",
        yearJoined: 2023,
        verifications: 89
      },
      specialties: ["Fresh Mint", "Oregano", "Cilantro"],
      achievements: ["Urban Farm Pioneer", "Restaurant Partner", "Quality Excellence"]
    }
  ];

  // Auto-rotate stories
  useEffect(() => {
    if (!isPlaying) return;
    
    const interval = setInterval(() => {
      setCurrentStory((prev) => (prev + 1) % successStories?.length);
    }, 8000);

    return () => clearInterval(interval);
  }, [isPlaying, successStories?.length]);

  const currentFarmer = successStories?.[currentStory];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-conversion/10 text-conversion px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Icon name="TrendingUp" size={16} />
            <span>Success Stories</span>
          </div>
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Farmers Thriving with Blockchain
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Real stories from farmers who've transformed their businesses through 
            transparent, blockchain-verified herb production.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Story Content */}
            <div className="space-y-8">
              {/* Farmer Profile */}
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Image
                    src={currentFarmer?.avatar}
                    alt={currentFarmer?.name}
                    className="w-16 h-16 rounded-full object-cover border-4 border-white shadow-md"
                  />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-conversion rounded-full border-2 border-white flex items-center justify-center">
                    <Icon name="Check" size={12} className="text-white" />
                  </div>
                </div>
                <div>
                  <h3 className="font-headline text-xl font-bold text-text-primary">
                    {currentFarmer?.name}
                  </h3>
                  <p className="text-text-secondary font-medium">
                    {currentFarmer?.farm}
                  </p>
                  <p className="text-text-secondary text-sm flex items-center">
                    <Icon name="MapPin" size={14} className="mr-1" />
                    {currentFarmer?.location}
                  </p>
                </div>
              </div>

              {/* Story Text */}
              <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
                <div className="flex items-start space-x-3">
                  <Icon name="Quote" size={24} className="text-primary flex-shrink-0 mt-1" />
                  <div className="space-y-4">
                    {currentFarmer?.story?.split('\n\n')?.map((paragraph, index) => (
                      <p key={index} className="text-text-primary leading-relaxed">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </div>
              </div>

              {/* Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-conversion/10 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-conversion font-headline">
                    +{currentFarmer?.metrics?.incomeIncrease}
                  </div>
                  <div className="text-xs text-text-secondary font-medium">
                    Income Increase
                  </div>
                </div>
                <div className="bg-primary/10 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-primary font-headline">
                    {currentFarmer?.metrics?.premiumPrice}
                  </div>
                  <div className="text-xs text-text-secondary font-medium">
                    Premium Price
                  </div>
                </div>
                <div className="bg-accent/10 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-accent font-headline">
                    {currentFarmer?.metrics?.yearJoined}
                  </div>
                  <div className="text-xs text-text-secondary font-medium">
                    Year Joined
                  </div>
                </div>
                <div className="bg-secondary/10 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-secondary font-headline">
                    {currentFarmer?.metrics?.verifications}
                  </div>
                  <div className="text-xs text-text-secondary font-medium">
                    Verifications
                  </div>
                </div>
              </div>

              {/* Specialties & Achievements */}
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-text-primary mb-2">Specialties</h4>
                  <div className="flex flex-wrap gap-2">
                    {currentFarmer?.specialties?.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-text-primary mb-2">Achievements</h4>
                  <div className="flex flex-wrap gap-2">
                    {currentFarmer?.achievements?.map((achievement, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-conversion/10 text-conversion text-sm rounded-full"
                      >
                        {achievement}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Visual Content */}
            <div className="space-y-6">
              {/* Farm Image */}
              <div className="relative rounded-2xl overflow-hidden shadow-warm">
                <Image
                  src={currentFarmer?.coverImage}
                  alt={`${currentFarmer?.farm} - ${currentFarmer?.name}`}
                  className="w-full h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/95 backdrop-blur-sm rounded-lg p-4">
                    <h4 className="font-headline font-semibold text-text-primary mb-1">
                      {currentFarmer?.farm}
                    </h4>
                    <p className="text-text-secondary text-sm">
                      Verified blockchain partner since {currentFarmer?.metrics?.yearJoined}
                    </p>
                  </div>
                </div>
              </div>

              {/* Story Navigation */}
              <div className="flex items-center justify-between bg-card rounded-xl p-4 border border-border">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setCurrentStory((prev) => 
                      prev === 0 ? successStories?.length - 1 : prev - 1
                    )}
                    className="w-8 h-8 rounded-full bg-muted hover:bg-primary hover:text-white transition-colors flex items-center justify-center"
                  >
                    <Icon name="ChevronLeft" size={16} />
                  </button>
                  <div className="flex space-x-2">
                    {successStories?.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentStory(index)}
                        className={`w-2 h-2 rounded-full transition-colors ${
                          index === currentStory ? 'bg-primary' : 'bg-border'
                        }`}
                      />
                    ))}
                  </div>
                  <button
                    onClick={() => setCurrentStory((prev) => 
                      (prev + 1) % successStories?.length
                    )}
                    className="w-8 h-8 rounded-full bg-muted hover:bg-primary hover:text-white transition-colors flex items-center justify-center"
                  >
                    <Icon name="ChevronRight" size={16} />
                  </button>
                </div>

                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex items-center space-x-2 text-text-secondary hover:text-primary transition-colors"
                >
                  <Icon name={isPlaying ? "Pause" : "Play"} size={16} />
                  <span className="text-sm font-medium">
                    {isPlaying ? "Pause" : "Play"}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FarmerSuccessStories;