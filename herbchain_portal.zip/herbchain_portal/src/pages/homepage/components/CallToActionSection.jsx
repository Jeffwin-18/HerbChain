import React from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CallToActionSection = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-primary via-primary/90 to-secondary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-32 h-32 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-white rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-white rounded-full blur-2xl"></div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 1200 800" fill="none">
          <path
            d="M0,400 Q300,200 600,400 T1200,400 V800 H0 Z"
            fill="rgba(255,255,255,0.05)"
          />
        </svg>
      </div>

      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main CTA Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium">
                <Icon name="Sparkles" size={16} />
                <span>Join the Revolution</span>
              </div>
              
              <h2 className="font-headline text-4xl lg:text-5xl font-bold text-white leading-tight">
                Ready to Transform Your{' '}
                <span className="relative">
                  Herb Business?
                  <svg
                    className="absolute -bottom-2 left-0 w-full h-3 text-white/30"
                    viewBox="0 0 300 12"
                    fill="currentColor"
                  >
                    <path d="M0,8 Q75,2 150,8 T300,8 L300,12 L0,12 Z" />
                  </svg>
                </span>
              </h2>
              
              <p className="text-xl text-white/90 leading-relaxed max-w-2xl mx-auto">
                Join thousands of farmers and consumers who trust HerbChain for transparent, 
                blockchain-verified herb supply chains. Start building trust today.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link to="/verification-center">
                <Button 
                  variant="secondary" 
                  size="lg" 
                  className="bg-white text-primary hover:bg-white/90 w-full sm:w-auto font-semibold"
                  iconName="Leaf"
                  iconPosition="left"
                >
                  Start Verifying Herbs
                </Button>
              </Link>
              <Link to="/consumer-qr-scanner">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-white text-white hover:bg-white/10 w-full sm:w-auto"
                  iconName="QrCode"
                  iconPosition="left"
                >
                  Scan & Discover
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 pt-8 border-t border-white/20">
              <div className="text-center">
                <div className="text-3xl font-bold text-white font-headline mb-1">
                  342+
                </div>
                <div className="text-white/80 text-sm font-medium">
                  Verified Farms
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white font-headline mb-1">
                  28K+
                </div>
                <div className="text-white/80 text-sm font-medium">
                  Verifications
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white font-headline mb-1">
                  156K+
                </div>
                <div className="text-white/80 text-sm font-medium">
                  QR Scans
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white font-headline mb-1">
                  99.9%
                </div>
                <div className="text-white/80 text-sm font-medium">
                  Uptime
                </div>
              </div>
            </div>
          </div>

          {/* Feature Highlights */}
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Icon name="Shield" size={24} className="text-white" />
              </div>
              <h3 className="font-headline text-lg font-semibold text-white mb-2">
                Blockchain Security
              </h3>
              <p className="text-white/80 text-sm">
                Immutable records ensure your herb data is secure and tamper-proof.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Icon name="TrendingUp" size={24} className="text-white" />
              </div>
              <h3 className="font-headline text-lg font-semibold text-white mb-2">
                Premium Pricing
              </h3>
              <p className="text-white/80 text-sm">
                Verified herbs command higher prices through proven authenticity.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
              <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4 mx-auto">
                <Icon name="Users" size={24} className="text-white" />
              </div>
              <h3 className="font-headline text-lg font-semibold text-white mb-2">
                Consumer Trust
              </h3>
              <p className="text-white/80 text-sm">
                Build lasting relationships with transparency and quality assurance.
              </p>
            </div>
          </div>

          {/* Bottom Links */}
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8 mt-12 pt-8 border-t border-white/20">
            <Link 
              to="/quality-certification-hub" 
              className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors"
            >
              <Icon name="Award" size={16} />
              <span className="text-sm font-medium">View Certifications</span>
            </Link>
            <Link 
              to="/community-forum" 
              className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors"
            >
              <Icon name="MessageCircle" size={16} />
              <span className="text-sm font-medium">Join Community</span>
            </Link>
            <Link 
              to="/trust-security-center" 
              className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors"
            >
              <Icon name="Lock" size={16} />
              <span className="text-sm font-medium">Security Center</span>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToActionSection;