import React from 'react';
import Header from '../../components/ui/Header';
import SecurityHero from './components/SecurityHero';
import SecurityOverview from './components/SecurityOverview';
import BlockchainSecurity from './components/BlockchainSecurity';
import PrivacyPolicy from './components/PrivacyPolicy';
import ComplianceStandards from './components/ComplianceStandards';
import SecurityAudits from './components/SecurityAudits';
import IncidentResponse from './components/IncidentResponse';
import UserDataControl from './components/UserDataControl';
import Icon from '../../components/AppIcon';

const TrustSecurityCenter = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      {/* Main Content */}
      <main className="pt-16">
        <SecurityHero />
        <SecurityOverview />
        <BlockchainSecurity />
        <PrivacyPolicy />
        <ComplianceStandards />
        <SecurityAudits />
        <IncidentResponse />
        <UserDataControl />
        
        {/* Trust Building Footer */}
        <section className="py-16 bg-primary/5">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center">
                <Icon name="Shield" size={40} className="text-primary" />
              </div>
            </div>
            <h2 className="font-headline text-3xl font-bold text-text-primary mb-4">
              Questions About Security?
            </h2>
            <p className="text-lg text-text-secondary mb-8 max-w-2xl mx-auto">
              Our security team is available 24/7 to address your concerns and provide additional information about our security practices.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-smooth flex items-center justify-center">
                <Icon name="Mail" size={16} className="mr-2" />
                Contact Security Team
              </button>
              <button className="px-8 py-3 border border-primary text-primary rounded-lg hover:bg-primary/5 transition-smooth flex items-center justify-center">
                <Icon name="FileText" size={16} className="mr-2" />
                Security Documentation
              </button>
            </div>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="bg-text-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Shield" size={20} className="text-white" />
                </div>
                <div>
                  <h3 className="font-headline font-bold text-xl">HerbChain Portal</h3>
                  <p className="text-sm text-gray-300">Trust & Security Center</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4 max-w-md">
                Building trust through transparency, security, and blockchain technology for agricultural traceability.
              </p>
              <div className="flex space-x-4">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <Icon name="Twitter" size={16} />
                </div>
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <Icon name="Linkedin" size={16} />
                </div>
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <Icon name="Github" size={16} />
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Security</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Security Audits</li>
                <li>Incident Reports</li>
                <li>Bug Bounty</li>
                <li>Compliance</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Contact Security</li>
                <li>Privacy Policy</li>
                <li>Data Rights</li>
                <li>Documentation</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-gray-300">
              © {new Date()?.getFullYear()} HerbChain Portal. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <span className="text-sm text-gray-300">Secured by blockchain technology</span>
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={16} className="text-success" />
                <span className="text-sm text-success">SSL Secured</span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default TrustSecurityCenter;