import React, { useState } from 'react';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import ProgressIndicator from './components/ProgressIndicator';
import FarmProfileSetup from './components/FarmProfileSetup';
import HarvestDataEntry from './components/HarvestDataEntry';
import QualityDocumentation from './components/QualityDocumentation';
import BlockchainSubmission from './components/BlockchainSubmission';
import QRCodeGeneration from './components/QRCodeGeneration';

const VerificationCenter = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [farmData, setFarmData] = useState({});
  const [harvestData, setHarvestData] = useState({});
  const [qualityData, setQualityData] = useState({});
  const [submissionData, setSubmissionData] = useState({});

  const totalSteps = 5;

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleStepClick = (step) => {
    if (step <= currentStep) {
      setCurrentStep(step);
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <FarmProfileSetup
            onNext={handleNext}
            farmData={farmData}
            setFarmData={setFarmData}
          />
        );
      case 2:
        return (
          <HarvestDataEntry
            onNext={handleNext}
            onBack={handleBack}
            harvestData={harvestData}
            setHarvestData={setHarvestData}
          />
        );
      case 3:
        return (
          <QualityDocumentation
            onNext={handleNext}
            onBack={handleBack}
            qualityData={qualityData}
            setQualityData={setQualityData}
          />
        );
      case 4:
        return (
          <BlockchainSubmission
            onNext={handleNext}
            onBack={handleBack}
            submissionData={{ farmData, harvestData, qualityData }}
          />
        );
      case 5:
        return (
          <QRCodeGeneration
            onBack={handleBack}
            verificationData={{ farmData, harvestData, qualityData, submissionData }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/5 via-background to-success/5 py-12 lg:py-16">
          <div className="max-w-7xl mx-auto px-4 lg:px-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
                <Icon name="Shield" size={16} />
                <span>Blockchain Verification</span>
              </div>
              
              <h1 className="text-3xl lg:text-4xl font-headline font-bold text-text-primary mb-4">
                Verification Center
              </h1>
              
              <p className="text-lg text-text-secondary max-w-2xl mx-auto">
                Transform your harvest into blockchain-verified premium products. 
                Our step-by-step process ensures authenticity and maximizes your market value.
              </p>
            </div>

            {/* Key Benefits */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-card rounded-lg border border-border p-6 text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Icon name="TrendingUp" size={24} className="text-primary" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  Premium Pricing
                </h3>
                <p className="text-sm text-text-secondary">
                  Earn up to 40% more for verified organic herbs
                </p>
              </div>
              
              <div className="bg-card rounded-lg border border-border p-6 text-center">
                <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Icon name="Shield" size={24} className="text-success" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  Immutable Records
                </h3>
                <p className="text-sm text-text-secondary">
                  Permanent blockchain proof of quality and authenticity
                </p>
              </div>
              
              <div className="bg-card rounded-lg border border-border p-6 text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Icon name="Users" size={24} className="text-accent" />
                </div>
                <h3 className="font-semibold text-text-primary mb-2">
                  Consumer Trust
                </h3>
                <p className="text-sm text-text-secondary">
                  Build direct relationships with conscious consumers
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Verification Process */}
        <section className="py-8 lg:py-12">
          <div className="max-w-4xl mx-auto px-4 lg:px-6">
            <ProgressIndicator 
              currentStep={currentStep} 
              totalSteps={totalSteps}
            />
            
            {renderCurrentStep()}
          </div>
        </section>

        {/* Help Section */}
        <section className="py-12 bg-muted/30">
          <div className="max-w-4xl mx-auto px-4 lg:px-6">
            <div className="bg-card rounded-xl border border-border p-6 lg:p-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name="HelpCircle" size={24} className="text-accent" />
                </div>
                
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-text-primary mb-2">
                    Need Help with Verification?
                  </h3>
                  <p className="text-text-secondary mb-4">
                    Our support team is here to guide you through the verification process. 
                    Get help with documentation, quality standards, or technical issues.
                  </p>
                  
                  <div className="flex flex-wrap gap-3">
                    <Button variant="outline" size="sm" iconName="MessageCircle">
                      Live Chat Support
                    </Button>
                    <Button variant="outline" size="sm" iconName="Phone">
                      Call (555) 123-4567
                    </Button>
                    <Button variant="outline" size="sm" iconName="Mail">
                      Email Support
                    </Button>
                    <Button variant="outline" size="sm" iconName="BookOpen">
                      View Guide
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Recent Verifications */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 lg:px-6">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-headline font-bold text-text-primary mb-2">
                  Recent Verifications
                </h2>
                <p className="text-text-secondary">
                  Track your recent blockchain verifications and their performance
                </p>
              </div>
              
              <Button variant="outline" iconName="BarChart3">
                View All Analytics
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {[
                {
                  id: 'VH2024-0891',
                  herb: 'Organic Oregano',
                  date: 'Sep 8, 2024',
                  status: 'Verified',
                  scans: 47,
                  premium: '+$89.50'
                },
                {
                  id: 'VH2024-0890',
                  herb: 'Wild Thyme',
                  date: 'Sep 7, 2024',
                  status: 'Verified',
                  scans: 23,
                  premium: '+$156.75'
                },
                {
                  id: 'VH2024-0889',
                  herb: 'Lavender Buds',
                  date: 'Sep 6, 2024',
                  status: 'Verified',
                  scans: 89,
                  premium: '+$234.20'
                }
              ]?.map((verification) => (
                <div key={verification?.id} className="bg-card rounded-lg border border-border p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-success/10 rounded-full flex items-center justify-center">
                        <Icon name="CheckCircle" size={16} className="text-success" />
                      </div>
                      <span className="text-sm font-medium text-success">
                        {verification?.status}
                      </span>
                    </div>
                    <span className="text-xs text-text-secondary">
                      {verification?.date}
                    </span>
                  </div>
                  
                  <h3 className="font-semibold text-text-primary mb-1">
                    {verification?.herb}
                  </h3>
                  <p className="text-sm text-text-secondary mb-4">
                    ID: {verification?.id}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-lg font-bold text-accent">
                        {verification?.scans}
                      </div>
                      <div className="text-xs text-text-secondary">
                        Consumer Scans
                      </div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-success">
                        {verification?.premium}
                      </div>
                      <div className="text-xs text-text-secondary">
                        Premium Earned
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default VerificationCenter;