import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const FeaturedFarms = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'All Farms', icon: 'Grid3X3' },
    { id: 'organic', label: 'Organic', icon: 'Leaf' },
    { id: 'sustainable', label: 'Sustainable', icon: 'Recycle' },
    { id: 'premium', label: 'Premium', icon: 'Star' }
  ];

  const featuredFarms = [
    {
      id: 1,
      name: "Green Valley Herbs",
      location: "Oregon, USA",
      farmer: "Sarah Martinez",
      farmerImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Fair Trade', 'Sustainable'],
      qualityScore: 98.5,
      specialties: ['Basil', 'Oregano', 'Thyme'],
      category: 'organic',
      yearsCertified: 5,
      totalProducts: 24,
      description: "Family-owned farm specializing in premium organic herbs with traditional growing methods passed down through generations."
    },
    {
      id: 2,
      name: "Mountain Peak Botanicals",
      location: "Colorado, USA",
      farmer: "David Chen",
      farmerImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Biodynamic', 'Carbon Neutral'],
      qualityScore: 97.8,
      specialties: ['Lavender', 'Chamomile', 'Mint'],
      category: 'premium',
      yearsCertified: 8,
      totalProducts: 31,
      description: "High-altitude farming utilizing innovative sustainable practices and renewable energy systems for exceptional herb quality."
    },
    {
      id: 3,
      name: "Sunshine Organic Gardens",
      location: "California, USA",
      farmer: "Maria Rodriguez",
      farmerImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Water Wise', 'Pollinator Friendly'],
      qualityScore: 96.9,
      specialties: ['Rosemary', 'Sage', 'Cilantro'],
      category: 'sustainable',
      yearsCertified: 3,
      totalProducts: 18,
      description: "Innovative water conservation techniques and pollinator habitat preservation create a thriving ecosystem for premium herbs."
    },
    {
      id: 4,
      name: "Heritage Herb Farm",
      location: "Vermont, USA",
      farmer: "John Thompson",
      farmerImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Heirloom Varieties', 'Regenerative'],
      qualityScore: 99.2,
      specialties: ['Parsley', 'Dill', 'Chives'],
      category: 'premium',
      yearsCertified: 12,
      totalProducts: 42,
      description: "Preserving heirloom herb varieties through regenerative farming practices that enhance soil health and biodiversity."
    },
    {
      id: 5,
      name: "Desert Bloom Herbs",
      location: "Arizona, USA",
      farmer: "Lisa Park",
      farmerImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Drought Resistant', 'Solar Powered'],
      qualityScore: 95.7,
      specialties: ['Oregano', 'Marjoram', 'Tarragon'],
      category: 'sustainable',
      yearsCertified: 4,
      totalProducts: 16,
      description: "Desert-adapted farming techniques and solar energy systems create sustainable herb production in arid environments."
    },
    {
      id: 6,
      name: "Coastal Herb Collective",
      location: "Maine, USA",
      farmer: "Robert Kim",
      farmerImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      farmImage: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      certifications: ['Organic', 'Ocean Friendly', 'Community Supported'],
      qualityScore: 97.3,
      specialties: ['Sea Beans', 'Coastal Sage', 'Salt Marsh Herbs'],
      category: 'organic',
      yearsCertified: 6,
      totalProducts: 22,
      description: "Coastal farming methods utilizing ocean minerals and sustainable practices to produce unique maritime herb varieties."
    }
  ];

  const filteredFarms = selectedCategory === 'all' 
    ? featuredFarms 
    : featuredFarms?.filter(farm => farm?.category === selectedCategory);

  const getCertificationColor = (cert) => {
    const colors = {
      'Organic': 'bg-green-100 text-green-800',
      'Fair Trade': 'bg-blue-100 text-blue-800',
      'Sustainable': 'bg-emerald-100 text-emerald-800',
      'Biodynamic': 'bg-purple-100 text-purple-800',
      'Carbon Neutral': 'bg-gray-100 text-gray-800',
      'Water Wise': 'bg-cyan-100 text-cyan-800',
      'Pollinator Friendly': 'bg-yellow-100 text-yellow-800',
      'Heirloom Varieties': 'bg-orange-100 text-orange-800',
      'Regenerative': 'bg-lime-100 text-lime-800',
      'Drought Resistant': 'bg-amber-100 text-amber-800',
      'Solar Powered': 'bg-yellow-100 text-yellow-800',
      'Ocean Friendly': 'bg-teal-100 text-teal-800',
      'Community Supported': 'bg-pink-100 text-pink-800'
    };
    return colors?.[cert] || 'bg-gray-100 text-gray-800';
  };

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Featured Certified Farms
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Meet the exceptional farmers who are setting new standards for quality, sustainability, and transparency in herb production.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories?.map((category) => (
            <Button
              key={category?.id}
              variant={selectedCategory === category?.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category?.id)}
              className="transition-smooth"
            >
              <Icon name={category?.icon} size={16} className="mr-2" />
              {category?.label}
            </Button>
          ))}
        </div>

        {/* Farms Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFarms?.map((farm) => (
            <div key={farm?.id} className="bg-card rounded-xl border border-border overflow-hidden shadow-warm hover:shadow-lg transition-smooth">
              {/* Farm Image */}
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={farm?.farmImage}
                  alt={`${farm?.name} farm view`}
                  className="w-full h-full object-cover transition-smooth hover:scale-105"
                />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <div className="flex items-center space-x-1">
                    <Icon name="Star" size={16} className="text-yellow-500 fill-current" />
                    <span className="text-sm font-semibold">{farm?.qualityScore}</span>
                  </div>
                </div>
              </div>

              {/* Farm Content */}
              <div className="p-6">
                {/* Farm Header */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-headline text-xl font-bold text-text-primary mb-1">
                      {farm?.name}
                    </h3>
                    <div className="flex items-center text-text-secondary text-sm">
                      <Icon name="MapPin" size={14} className="mr-1" />
                      {farm?.location}
                    </div>
                  </div>
                  <div className="flex-shrink-0 ml-4">
                    <Image
                      src={farm?.farmerImage}
                      alt={`${farm?.farmer} portrait`}
                      className="w-12 h-12 rounded-full object-cover border-2 border-primary/20"
                    />
                  </div>
                </div>

                {/* Farmer Info */}
                <div className="mb-4">
                  <p className="text-sm text-text-secondary">
                    Farmer: <span className="font-medium text-text-primary">{farm?.farmer}</span>
                  </p>
                  <p className="text-sm text-text-secondary">
                    {farm?.yearsCertified} years certified • {farm?.totalProducts} products
                  </p>
                </div>

                {/* Description */}
                <p className="text-sm text-text-secondary mb-4 line-clamp-3">
                  {farm?.description}
                </p>

                {/* Specialties */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-text-primary mb-2">Specialties:</p>
                  <div className="flex flex-wrap gap-1">
                    {farm?.specialties?.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-md"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Certifications */}
                <div className="mb-6">
                  <p className="text-sm font-medium text-text-primary mb-2">Certifications:</p>
                  <div className="flex flex-wrap gap-1">
                    {farm?.certifications?.slice(0, 2)?.map((cert, index) => (
                      <span
                        key={index}
                        className={`px-2 py-1 text-xs rounded-md ${getCertificationColor(cert)}`}
                      >
                        {cert}
                      </span>
                    ))}
                    {farm?.certifications?.length > 2 && (
                      <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md">
                        +{farm?.certifications?.length - 2} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button variant="default" className="flex-1">
                    <Icon name="Eye" size={16} className="mr-2" />
                    View Profile
                  </Button>
                  <Button variant="outline" className="px-3">
                    <Icon name="MapPin" size={16} />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button variant="outline" className="px-8">
            <Icon name="Plus" size={16} className="mr-2" />
            Load More Farms
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedFarms;