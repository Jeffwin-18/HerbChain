import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const IncidentResponse = () => {
  const [activeTab, setActiveTab] = useState('procedures');

  const responseSteps = [
    {
      step: 1,
      title: "Detection & Assessment",
      timeframe: "0-15 minutes",
      description: "Automated monitoring systems detect potential security incidents and alert our response team",
      actions: [
        "Automated threat detection triggers alert",
        "Security team receives immediate notification",
        "Initial assessment of incident severity",
        "Stakeholder notification if required"
      ]
    },
    {
      step: 2,
      title: "Containment & Analysis",
      timeframe: "15-60 minutes",
      description: "Immediate containment measures are implemented while conducting detailed analysis",
      actions: [
        "Isolate affected systems to prevent spread",
        "Preserve evidence for forensic analysis",
        "Analyze attack vectors and impact scope",
        "Implement temporary security measures"
      ]
    },
    {
      step: 3,
      title: "Resolution & Recovery",
      timeframe: "1-24 hours",
      description: "Systems are restored to normal operation with enhanced security measures",
      actions: [
        "Remove threats and patch vulnerabilities",
        "Restore systems from secure backups",
        "Implement additional security controls",
        "Verify system integrity and functionality"
      ]
    },
    {
      step: 4,
      title: "Communication & Follow-up",
      timeframe: "24-72 hours",
      description: "Transparent communication with stakeholders and implementation of preventive measures",
      actions: [
        "Notify affected users and stakeholders",
        "Publish incident report and lessons learned",
        "Update security policies and procedures",
        "Conduct post-incident review and training"
      ]
    }
  ];

  const historicalIncidents = [
    {
      date: "March 15, 2024",
      type: "DDoS Attack",
      severity: "Medium",
      status: "Resolved",
      duration: "2 hours 15 minutes",
      impact: "Temporary service slowdown",
      resolution: "Traffic filtering and load balancing optimization implemented",
      affectedUsers: "~500 users experienced slower response times",
      preventiveMeasures: "Enhanced DDoS protection and monitoring systems deployed"
    },
    {
      date: "January 8, 2024",
      type: "Phishing Attempt",
      severity: "Low",
      status: "Resolved",
      duration: "45 minutes",
      impact: "No data compromise",
      resolution: "Malicious emails blocked, user education campaign launched",
      affectedUsers: "12 users received phishing emails, none compromised",
      preventiveMeasures: "Advanced email filtering and security awareness training"
    },
    {
      date: "November 22, 2023",
      type: "API Rate Limiting",
      severity: "Low",
      status: "Resolved",
      duration: "1 hour 30 minutes",
      impact: "Some API requests temporarily throttled",
      resolution: "Rate limiting algorithms optimized for legitimate traffic",
      affectedUsers: "~50 API users experienced temporary throttling",
      preventiveMeasures: "Improved rate limiting with user behavior analysis"
    }
  ];

  const contactChannels = [
    {
      icon: "Mail",
      title: "Email Security Team",
      contact: "security@herbchain.com",
      description: "For non-urgent security concerns and general inquiries",
      responseTime: "Within 4 hours"
    },
    {
      icon: "Phone",
      title: "Emergency Hotline",
      contact: "+1 (555) 123-SECURITY",
      description: "24/7 hotline for critical security incidents",
      responseTime: "Immediate"
    },
    {
      icon: "MessageSquare",
      title: "Secure Portal",
      contact: "security.herbchain.com",
      description: "Encrypted communication for sensitive security reports",
      responseTime: "Within 2 hours"
    },
    {
      icon: "Shield",
      title: "Bug Bounty Program",
      contact: "bugbounty@herbchain.com",
      description: "Report vulnerabilities through our responsible disclosure program",
      responseTime: "Within 24 hours"
    }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'High':
        return 'text-error bg-error/10';
      case 'Medium':
        return 'text-warning bg-warning/10';
      case 'Low':
        return 'text-success bg-success/10';
      default:
        return 'text-text-secondary bg-muted';
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Incident Response & Transparency
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            Our comprehensive incident response procedures ensure rapid resolution of security issues with full transparency about past incidents and preventive measures.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center mb-12">
          <div className="bg-card rounded-lg p-1 border border-border">
            <Button
              variant={activeTab === 'procedures' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('procedures')}
              className="mr-1"
            >
              <Icon name="Shield" size={16} className="mr-2" />
              Response Procedures
            </Button>
            <Button
              variant={activeTab === 'history' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('history')}
              className="mr-1"
            >
              <Icon name="History" size={16} className="mr-2" />
              Incident History
            </Button>
            <Button
              variant={activeTab === 'contact' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('contact')}
            >
              <Icon name="MessageCircle" size={16} className="mr-2" />
              Report Security Issue
            </Button>
          </div>
        </div>

        {/* Response Procedures Tab */}
        {activeTab === 'procedures' && (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <h3 className="font-headline text-2xl font-semibold text-text-primary mb-4">
                Our 4-Step Response Process
              </h3>
              <p className="text-text-secondary max-w-2xl mx-auto">
                When security incidents occur, we follow a proven methodology to ensure rapid response, minimal impact, and transparent communication.
              </p>
            </div>

            <div className="space-y-8">
              {responseSteps?.map((step, index) => (
                <div key={step?.step} className="bg-card rounded-xl p-8 border border-border">
                  <div className="flex items-start space-x-6">
                    <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center flex-shrink-0">
                      <span className="text-2xl font-bold text-white">{step?.step}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                        <h4 className="font-headline text-xl font-semibold text-text-primary">
                          {step?.title}
                        </h4>
                        <span className="text-sm text-accent font-medium bg-accent/10 px-3 py-1 rounded-full mt-2 lg:mt-0 w-fit">
                          {step?.timeframe}
                        </span>
                      </div>
                      <p className="text-text-secondary mb-6 leading-relaxed">
                        {step?.description}
                      </p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {step?.actions?.map((action, actionIndex) => (
                          <div key={actionIndex} className="flex items-start space-x-3">
                            <Icon name="Check" size={16} className="text-success mt-1 flex-shrink-0" />
                            <span className="text-sm text-text-secondary">{action}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Incident History Tab */}
        {activeTab === 'history' && (
          <div>
            <div className="text-center mb-12">
              <h3 className="font-headline text-2xl font-semibold text-text-primary mb-4">
                Historical Incident Transparency
              </h3>
              <p className="text-text-secondary max-w-2xl mx-auto">
                Complete transparency about past security incidents, their resolution, and preventive measures implemented.
              </p>
            </div>

            <div className="space-y-6">
              {historicalIncidents?.map((incident, index) => (
                <div key={index} className="bg-card rounded-xl p-8 border border-border">
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-6">
                    <div>
                      <div className="flex items-center space-x-4 mb-2">
                        <h4 className="font-semibold text-text-primary text-lg">{incident?.type}</h4>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getSeverityColor(incident?.severity)}`}>
                          {incident?.severity}
                        </span>
                        <span className="px-3 py-1 bg-success/10 text-success text-xs rounded-full">
                          {incident?.status}
                        </span>
                      </div>
                      <p className="text-text-secondary">{incident?.date}</p>
                    </div>
                    <div className="text-right mt-4 lg:mt-0">
                      <div className="text-sm text-text-secondary">Duration</div>
                      <div className="font-semibold text-text-primary">{incident?.duration}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                      <h5 className="font-semibold text-text-primary mb-3">Impact & Resolution</h5>
                      <div className="space-y-3">
                        <div>
                          <span className="text-sm font-medium text-text-secondary">Impact:</span>
                          <p className="text-sm text-text-secondary">{incident?.impact}</p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-text-secondary">Affected Users:</span>
                          <p className="text-sm text-text-secondary">{incident?.affectedUsers}</p>
                        </div>
                        <div>
                          <span className="text-sm font-medium text-text-secondary">Resolution:</span>
                          <p className="text-sm text-text-secondary">{incident?.resolution}</p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h5 className="font-semibold text-text-primary mb-3">Preventive Measures</h5>
                      <p className="text-sm text-text-secondary">{incident?.preventiveMeasures}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-12">
              <p className="text-text-secondary mb-4">
                No incidents have resulted in data breaches or permanent service disruption
              </p>
              <Button variant="outline">
                <Icon name="Download" size={16} className="mr-2" />
                Download Full Incident Reports
              </Button>
            </div>
          </div>
        )}

        {/* Contact Tab */}
        {activeTab === 'contact' && (
          <div>
            <div className="text-center mb-12">
              <h3 className="font-headline text-2xl font-semibold text-text-primary mb-4">
                Report Security Issues
              </h3>
              <p className="text-text-secondary max-w-2xl mx-auto">
                Multiple channels available for reporting security concerns, from general inquiries to critical incidents.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              {contactChannels?.map((channel, index) => (
                <div key={index} className="bg-card rounded-xl p-8 border border-border hover:shadow-warm transition-smooth">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name={channel?.icon} size={24} className="text-primary" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-text-primary mb-2">{channel?.title}</h4>
                      <p className="text-text-secondary mb-4">{channel?.description}</p>
                      <div className="space-y-2">
                        <div className="text-sm">
                          <span className="font-medium text-text-primary">Contact:</span>
                          <span className="text-primary ml-2">{channel?.contact}</span>
                        </div>
                        <div className="text-sm">
                          <span className="font-medium text-text-primary">Response Time:</span>
                          <span className="text-text-secondary ml-2">{channel?.responseTime}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-primary/5 rounded-2xl p-8 text-center">
              <Icon name="Award" size={48} className="text-primary mx-auto mb-4" />
              <h4 className="font-headline text-xl font-semibold text-text-primary mb-4">
                Responsible Disclosure Program
              </h4>
              <p className="text-text-secondary mb-6 max-w-2xl mx-auto">
                We appreciate security researchers who help us maintain the highest security standards. Our bug bounty program rewards responsible disclosure of security vulnerabilities.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="default">
                  <Icon name="Shield" size={16} className="mr-2" />
                  View Bug Bounty Program
                </Button>
                <Button variant="outline">
                  <Icon name="FileText" size={16} className="mr-2" />
                  Disclosure Guidelines
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default IncidentResponse;