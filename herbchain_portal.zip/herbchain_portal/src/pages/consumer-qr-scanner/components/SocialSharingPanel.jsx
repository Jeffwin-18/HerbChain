import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SocialSharingPanel = ({ herbData, onShare }) => {
  const [shareMessage, setShareMessage] = useState('');
  const [isSharing, setIsSharing] = useState(false);

  const shareData = {
    herbName: 'Organic Basil',
    farmName: 'Green Valley Organic Farm',
    farmer: 'Maria Rodriguez',
    location: 'Sonoma County, CA',
    purityScore: 99.8,
    sustainabilityScore: 95.5,
    qrCode: 'HBC-2024-FARM-001-BASIL-BATCH-789',
    verificationUrl: `https://herbchain.com/verify/${herbData?.qrCode || 'demo'}`
  };

  const defaultMessages = {
    discovery: `Just discovered the amazing story behind my ${shareData?.herbName}! 🌿 Grown by ${shareData?.farmer} at ${shareData?.farmName} with ${shareData?.purityScore}% purity and ${shareData?.sustainabilityScore}% sustainability score. #HerbChain #KnowYourSource`,
    quality: `Impressed by the quality transparency! This ${shareData?.herbName} scored ${shareData?.purityScore}% purity in lab tests. Thanks to blockchain technology, I can trace it back to ${shareData?.farmer}'s farm in ${shareData?.location}. #QualityMatters #BlockchainVerified`,
    farmer: `Shoutout to ${shareData?.farmer} from ${shareData?.farmName}! 👨‍🌾 Their sustainable farming practices achieved a ${shareData?.sustainabilityScore}% sustainability score. Supporting farmers who care about our planet! #SustainableFarming #SupportLocal`,
    custom: shareMessage
  };

  const [selectedTemplate, setSelectedTemplate] = useState('discovery');

  const socialPlatforms = [
    {
      name: 'Twitter',
      icon: 'Twitter',
      color: 'text-blue-500',
      bgColor: 'bg-blue-50 hover:bg-blue-100',
      shareUrl: (text) => `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareData?.verificationUrl)}`
    },
    {
      name: 'Facebook',
      icon: 'Facebook',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50 hover:bg-blue-100',
      shareUrl: (text) => `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareData?.verificationUrl)}&quote=${encodeURIComponent(text)}`
    },
    {
      name: 'LinkedIn',
      icon: 'Linkedin',
      color: 'text-blue-700',
      bgColor: 'bg-blue-50 hover:bg-blue-100',
      shareUrl: (text) => `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareData?.verificationUrl)}&summary=${encodeURIComponent(text)}`
    },
    {
      name: 'WhatsApp',
      icon: 'MessageCircle',
      color: 'text-green-600',
      bgColor: 'bg-green-50 hover:bg-green-100',
      shareUrl: (text) => `https://wa.me/?text=${encodeURIComponent(text + ' ' + shareData?.verificationUrl)}`
    }
  ];

  const handleShare = async (platform) => {
    setIsSharing(true);
    
    const message = selectedTemplate === 'custom' ? shareMessage : defaultMessages?.[selectedTemplate];
    
    try {
      if (navigator.share && platform?.name === 'Native') {
        await navigator.share({
          title: `${shareData?.herbName} - Verified by HerbChain`,
          text: message,
          url: shareData?.verificationUrl
        });
      } else {
        window.open(platform?.shareUrl(message), '_blank', 'width=600,height=400');
      }
      
      onShare?.(platform?.name, message);
    } catch (error) {
      console.error('Error sharing:', error);
    } finally {
      setIsSharing(false);
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard?.writeText(shareData?.verificationUrl);
      // You could add a toast notification here
    } catch (error) {
      console.error('Error copying link:', error);
    }
  };

  const generateQRCode = () => {
    // In a real app, you'd generate an actual QR code
    const canvas = document.createElement('canvas');
    const ctx = canvas?.getContext('2d');
    canvas.width = 200;
    canvas.height = 200;
    
    // Simple placeholder QR code pattern
    ctx.fillStyle = '#000000';
    for (let i = 0; i < 20; i++) {
      for (let j = 0; j < 20; j++) {
        if (Math.random() > 0.5) {
          ctx?.fillRect(i * 10, j * 10, 10, 10);
        }
      }
    }
    
    return canvas?.toDataURL();
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-card rounded-xl border border-border p-6 shadow-warm">
        <div className="mb-6">
          <h3 className="text-xl font-headline font-bold text-text-primary mb-2">
            Share Your Discovery
          </h3>
          <p className="text-text-secondary">
            Spread the word about transparent, quality herbs
          </p>
        </div>

        {/* Message Templates */}
        <div className="mb-6">
          <h4 className="text-sm font-medium text-text-primary mb-3">Choose a message template</h4>
          <div className="space-y-3">
            {Object.entries(defaultMessages)?.filter(([key]) => key !== 'custom')?.map(([key, message]) => (
              <label key={key} className="flex items-start gap-3 cursor-pointer">
                <input
                  type="radio"
                  name="template"
                  value={key}
                  checked={selectedTemplate === key}
                  onChange={(e) => setSelectedTemplate(e?.target?.value)}
                  className="mt-1 text-primary focus:ring-primary"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium text-text-primary capitalize mb-1">
                    {key === 'discovery' && '🌿 Discovery Story'}
                    {key === 'quality' && '🏆 Quality Focus'}
                    {key === 'farmer' && '👨‍🌾 Farmer Appreciation'}
                  </div>
                  <div className="text-sm text-text-secondary line-clamp-2">
                    {message}
                  </div>
                </div>
              </label>
            ))}
            
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="radio"
                name="template"
                value="custom"
                checked={selectedTemplate === 'custom'}
                onChange={(e) => setSelectedTemplate(e?.target?.value)}
                className="mt-1 text-primary focus:ring-primary"
              />
              <div className="flex-1">
                <div className="text-sm font-medium text-text-primary mb-1">
                  ✏️ Custom Message
                </div>
                <textarea
                  value={shareMessage}
                  onChange={(e) => setShareMessage(e?.target?.value)}
                  placeholder="Write your own message..."
                  className="w-full p-3 border border-border rounded-lg text-sm resize-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  rows={3}
                  disabled={selectedTemplate !== 'custom'}
                />
              </div>
            </label>
          </div>
        </div>

        {/* Preview */}
        <div className="mb-6 p-4 bg-muted rounded-lg">
          <h4 className="text-sm font-medium text-text-primary mb-2">Preview</h4>
          <div className="text-sm text-text-secondary">
            {selectedTemplate === 'custom' ? shareMessage || 'Enter your custom message...' : defaultMessages?.[selectedTemplate]}
          </div>
          <div className="mt-2 text-xs text-primary">
            {shareData?.verificationUrl}
          </div>
        </div>

        {/* Social Platforms */}
        <div className="mb-6">
          <h4 className="text-sm font-medium text-text-primary mb-3">Share on social media</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {socialPlatforms?.map((platform) => (
              <Button
                key={platform?.name}
                variant="outline"
                onClick={() => handleShare(platform)}
                disabled={isSharing || (selectedTemplate === 'custom' && !shareMessage?.trim())}
                className={`flex flex-col items-center gap-2 h-auto py-4 ${platform?.bgColor} border-transparent`}
              >
                <Icon name={platform?.icon} size={24} className={platform?.color} />
                <span className="text-xs font-medium">{platform?.name}</span>
              </Button>
            ))}
          </div>
        </div>

        {/* Additional Options */}
        <div className="space-y-3">
          <div className="flex gap-3">
            <Button
              variant="outline"
              fullWidth
              onClick={copyLink}
              iconName="Link"
              iconPosition="left"
            >
              Copy Link
            </Button>
            
            {navigator.share && (
              <Button
                variant="outline"
                fullWidth
                onClick={() => handleShare({ name: 'Native', shareUrl: () => '' })}
                iconName="Share"
                iconPosition="left"
              >
                Share
              </Button>
            )}
          </div>

          <Button
            variant="ghost"
            fullWidth
            iconName="QrCode"
            iconPosition="left"
          >
            Generate QR Code
          </Button>
        </div>

        {/* Sharing Stats */}
        <div className="mt-6 pt-6 border-t border-border">
          <div className="flex items-center justify-between text-sm">
            <span className="text-text-secondary">This product has been shared</span>
            <span className="font-medium text-text-primary">247 times</span>
          </div>
          <div className="flex items-center justify-between text-sm mt-1">
            <span className="text-text-secondary">Verification views</span>
            <span className="font-medium text-text-primary">1,834</span>
          </div>
        </div>

        {/* Privacy Note */}
        <div className="mt-4 p-3 bg-muted rounded-lg">
          <div className="flex items-start gap-2">
            <Icon name="Info" size={16} className="text-accent mt-0.5" />
            <div className="text-xs text-text-secondary">
              <strong>Privacy Note:</strong> Sharing this verification link helps build trust in our food system. 
              No personal information is shared, only the product's journey and quality data.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialSharingPanel;