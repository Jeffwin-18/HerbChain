import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const BlockchainSecurity = () => {
  const [activeStep, setActiveStep] = useState(0);

  const blockchainSteps = [
    {
      icon: "Leaf",
      title: "Data Entry",
      description: "Farmer enters harvest data",
      details: "When a farmer logs harvest information, the data is first validated locally before being prepared for blockchain submission. This includes quality checks, timestamp verification, and digital signatures."
    },
    {
      icon: "Hash",
      title: "Cryptographic Hashing",
      description: "Data converted to unique hash",
      details: "The harvest data is processed through SHA-256 cryptographic hashing, creating a unique digital fingerprint. This hash is mathematically impossible to reverse or forge, ensuring data integrity."
    },
    {
      icon: "Link",
      title: "Blockchain Recording",
      description: "Hash stored on immutable ledger",
      details: "The hash is recorded on our blockchain network with a timestamp and linked to previous blocks. This creates an unbreakable chain of custody that cannot be altered or deleted."
    },
    {
      icon: "QrCode",
      title: "QR Generation",
      description: "Unique QR code created",
      details: "A QR code is generated containing the blockchain transaction ID, allowing consumers to instantly verify the authenticity and trace the complete journey of their herbs."
    }
  ];

  const securityFeatures = [
    {
      icon: "Shield",
      title: "Immutable Records",
      description: "Once data is recorded on the blockchain, it cannot be changed or deleted, ensuring permanent traceability."
    },
    {
      icon: "Key",
      title: "Cryptographic Security",
      description: "Advanced encryption protects data integrity and prevents unauthorized access or tampering."
    },
    {
      icon: "Network",
      title: "Distributed Verification",
      description: "Multiple network nodes validate each transaction, eliminating single points of failure."
    },
    {
      icon: "Clock",
      title: "Timestamped Proof",
      description: "Every entry includes precise timestamps, creating an auditable timeline of events."
    }
  ];

  return (
    <section className="py-16 lg:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Blockchain Security Fundamentals
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto mb-8">
            Understanding how blockchain technology protects your agricultural data using agricultural metaphors and simple explanations.
          </p>
        </div>

        {/* Interactive Blockchain Process */}
        <div className="bg-card rounded-2xl p-8 lg:p-12 border border-border mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            How Blockchain Protects Your Data
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Steps Navigation */}
            <div className="space-y-4">
              {blockchainSteps?.map((step, index) => (
                <div
                  key={index}
                  onClick={() => setActiveStep(index)}
                  className={`p-4 rounded-lg border cursor-pointer transition-smooth ${
                    activeStep === index
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      activeStep === index ? 'bg-primary text-white' : 'bg-muted text-text-secondary'
                    }`}>
                      <Icon name={step?.icon} size={20} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-text-primary">{step?.title}</h4>
                      <p className="text-sm text-text-secondary">{step?.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Active Step Details */}
            <div className="bg-muted/50 rounded-xl p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center">
                  <Icon name={blockchainSteps?.[activeStep]?.icon} size={32} className="text-white" />
                </div>
                <div>
                  <h4 className="font-headline text-xl font-semibold text-text-primary">
                    {blockchainSteps?.[activeStep]?.title}
                  </h4>
                  <p className="text-text-secondary">{blockchainSteps?.[activeStep]?.description}</p>
                </div>
              </div>
              <p className="text-text-secondary leading-relaxed">
                {blockchainSteps?.[activeStep]?.details}
              </p>
            </div>
          </div>
        </div>

        {/* Security Features Grid */}
        <div>
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8 text-center">
            Why Blockchain is Like a Digital Seed Vault
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {securityFeatures?.map((feature, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border hover:shadow-warm transition-smooth">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={feature?.icon} size={24} className="text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-primary mb-2">{feature?.title}</h4>
                    <p className="text-text-secondary">{feature?.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default BlockchainSecurity;