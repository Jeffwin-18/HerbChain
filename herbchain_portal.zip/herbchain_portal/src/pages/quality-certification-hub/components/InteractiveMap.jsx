import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const InteractiveMap = () => {
  const [selectedFarm, setSelectedFarm] = useState(null);
  const [mapView, setMapView] = useState('farms'); // 'farms' or 'regions'

  const certifiedFarms = [
    {
      id: 1,
      name: "Green Valley Herbs",
      location: "Oregon, USA",
      coordinates: { lat: 45.5152, lng: -122.6784 },
      farmer: "Sarah Martinez",
      image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      certifications: ['Organic', 'Fair Trade'],
      specialties: ['Basil', 'Oregano', 'Thyme'],
      qualityScore: 98.5,
      established: 2019,
      size: "45 acres",
      seasonalCalendar: {
        spring: ['Basil', 'Cilantro'],
        summer: ['Oregano', 'Thyme', 'Rosemary'],
        fall: ['Sage', 'Parsley'],
        winter: ['Greenhouse Herbs']
      }
    },
    {
      id: 2,
      name: "Mountain Peak Botanicals",
      location: "Colorado, USA",
      coordinates: { lat: 39.7392, lng: -104.9903 },
      farmer: "David Chen",
      image: "https://images.unsplash.com/photo-1416879595882-3373a0480b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      certifications: ['Organic', 'Biodynamic'],
      specialties: ['Lavender', 'Chamomile', 'Mint'],
      qualityScore: 97.8,
      established: 2017,
      size: "62 acres",
      seasonalCalendar: {
        spring: ['Mint', 'Lemon Balm'],
        summer: ['Lavender', 'Chamomile'],
        fall: ['Echinacea', 'Calendula'],
        winter: ['Dried Herb Processing']
      }
    },
    {
      id: 3,
      name: "Sunshine Organic Gardens",
      location: "California, USA",
      coordinates: { lat: 34.0522, lng: -118.2437 },
      farmer: "Maria Rodriguez",
      image: "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      certifications: ['Organic', 'Water Wise'],
      specialties: ['Rosemary', 'Sage', 'Cilantro'],
      qualityScore: 96.9,
      established: 2020,
      size: "28 acres",
      seasonalCalendar: {
        spring: ['Cilantro', 'Parsley'],
        summer: ['Rosemary', 'Sage'],
        fall: ['Oregano', 'Thyme'],
        winter: ['Year-round Production']
      }
    },
    {
      id: 4,
      name: "Heritage Herb Farm",
      location: "Vermont, USA",
      coordinates: { lat: 44.2601, lng: -72.5806 },
      farmer: "John Thompson",
      image: "https://images.unsplash.com/photo-1464226184884-fa280b87c399?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      certifications: ['Organic', 'Heirloom'],
      specialties: ['Parsley', 'Dill', 'Chives'],
      qualityScore: 99.2,
      established: 2015,
      size: "38 acres",
      seasonalCalendar: {
        spring: ['Chives', 'Parsley'],
        summer: ['Dill', 'Fennel'],
        fall: ['Caraway', 'Coriander'],
        winter: ['Seed Processing']
      }
    },
    {
      id: 5,
      name: "Desert Bloom Herbs",
      location: "Arizona, USA",
      coordinates: { lat: 33.4484, lng: -112.0740 },
      farmer: "Lisa Park",
      image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80",
      certifications: ['Organic', 'Drought Resistant'],
      specialties: ['Oregano', 'Marjoram', 'Tarragon'],
      qualityScore: 95.7,
      established: 2021,
      size: "22 acres",
      seasonalCalendar: {
        spring: ['Tarragon', 'Marjoram'],
        summer: ['Desert Sage', 'Oregano'],
        fall: ['Rosemary', 'Thyme'],
        winter: ['Cool Season Herbs']
      }
    }
  ];

  const regionStats = [
    {
      region: "Pacific Northwest",
      farms: 847,
      avgQuality: 97.2,
      topHerbs: ['Basil', 'Oregano', 'Mint'],
      color: 'bg-green-500'
    },
    {
      region: "California Central Valley",
      farms: 623,
      avgQuality: 96.8,
      topHerbs: ['Rosemary', 'Sage', 'Cilantro'],
      color: 'bg-blue-500'
    },
    {
      region: "Rocky Mountain Region",
      farms: 412,
      avgQuality: 98.1,
      topHerbs: ['Lavender', 'Chamomile', 'Echinacea'],
      color: 'bg-purple-500'
    },
    {
      region: "Northeast Corridor",
      farms: 356,
      avgQuality: 97.9,
      topHerbs: ['Parsley', 'Dill', 'Chives'],
      color: 'bg-orange-500'
    },
    {
      region: "Southwest Desert",
      farms: 289,
      avgQuality: 96.3,
      topHerbs: ['Desert Sage', 'Oregano', 'Thyme'],
      color: 'bg-red-500'
    }
  ];

  const getCurrentSeason = () => {
    const month = new Date()?.getMonth();
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    if (month >= 8 && month <= 10) return 'fall';
    return 'winter';
  };

  const currentSeason = getCurrentSeason();

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 lg:px-6">
        <div className="text-center mb-12">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Explore Certified Farms Worldwide
          </h2>
          <p className="text-lg text-text-secondary max-w-2xl mx-auto">
            Discover the locations, growing practices, and seasonal calendars of our verified herb farms across different regions and climates.
          </p>
        </div>

        {/* Map Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between mb-8">
          <div className="flex space-x-2 mb-4 sm:mb-0">
            <Button
              variant={mapView === 'farms' ? 'default' : 'outline'}
              onClick={() => setMapView('farms')}
            >
              <Icon name="MapPin" size={16} className="mr-2" />
              Individual Farms
            </Button>
            <Button
              variant={mapView === 'regions' ? 'default' : 'outline'}
              onClick={() => setMapView('regions')}
            >
              <Icon name="Globe" size={16} className="mr-2" />
              Regional View
            </Button>
          </div>
          <div className="flex items-center space-x-4 text-sm text-text-secondary">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded-full"></div>
              <span>Certified Farms</span>
            </div>
            <div className="flex items-center space-x-2">
              <Icon name="Calendar" size={16} />
              <span>Current Season: {currentSeason?.charAt(0)?.toUpperCase() + currentSeason?.slice(1)}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Interactive Map */}
          <div className="lg:col-span-2">
            <div className="bg-card rounded-xl border border-border overflow-hidden">
              <div className="h-96 relative">
                {/* Embedded Google Map */}
                <iframe
                  width="100%"
                  height="100%"
                  loading="lazy"
                  title="Certified Farms Map"
                  referrerPolicy="no-referrer-when-downgrade"
                  src="https://www.google.com/maps?q=39.8283,-98.5795&z=4&output=embed"
                  className="w-full h-full"
                ></iframe>
                
                {/* Map Overlay with Farm Markers */}
                <div className="absolute inset-0 pointer-events-none">
                  {mapView === 'farms' && certifiedFarms?.map((farm, index) => (
                    <div
                      key={farm?.id}
                      className="absolute pointer-events-auto cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
                      style={{
                        left: `${20 + (index * 15)}%`,
                        top: `${30 + (index * 10)}%`
                      }}
                      onClick={() => setSelectedFarm(farm)}
                    >
                      <div className={`w-4 h-4 bg-primary rounded-full border-2 border-white shadow-lg hover:scale-125 transition-smooth ${
                        selectedFarm?.id === farm?.id ? 'ring-4 ring-primary/30' : ''
                      }`}></div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Map Legend */}
              <div className="p-4 bg-muted/30 border-t border-border">
                <div className="flex flex-wrap items-center justify-between text-sm">
                  <div className="flex items-center space-x-4">
                    <span className="text-text-secondary">Total Certified Farms:</span>
                    <span className="font-semibold text-text-primary">2,847</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-text-secondary">Average Quality Score:</span>
                    <span className="font-semibold text-text-primary">97.2</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Farm Details Panel */}
          <div className="lg:col-span-1">
            {selectedFarm ? (
              <div className="bg-card rounded-xl border border-border overflow-hidden sticky top-24">
                {/* Farm Image */}
                <div className="h-48 relative overflow-hidden">
                  <Image
                    src={selectedFarm?.image}
                    alt={`${selectedFarm?.name} farm view`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                    <div className="flex items-center space-x-1">
                      <Icon name="Star" size={14} className="text-yellow-500 fill-current" />
                      <span className="text-sm font-semibold">{selectedFarm?.qualityScore}</span>
                    </div>
                  </div>
                </div>

                {/* Farm Info */}
                <div className="p-6">
                  <h3 className="font-headline text-xl font-bold text-text-primary mb-2">
                    {selectedFarm?.name}
                  </h3>
                  <div className="flex items-center text-text-secondary text-sm mb-4">
                    <Icon name="MapPin" size={14} className="mr-1" />
                    {selectedFarm?.location}
                  </div>

                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Farmer:</span>
                      <span className="font-medium text-text-primary">{selectedFarm?.farmer}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Established:</span>
                      <span className="font-medium text-text-primary">{selectedFarm?.established}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-text-secondary">Farm Size:</span>
                      <span className="font-medium text-text-primary">{selectedFarm?.size}</span>
                    </div>
                  </div>

                  {/* Certifications */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-text-primary mb-2">Certifications</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedFarm?.certifications?.map((cert, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-md"
                        >
                          {cert}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Current Season Herbs */}
                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-text-primary mb-2">
                      Current Season ({currentSeason?.charAt(0)?.toUpperCase() + currentSeason?.slice(1)})
                    </h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedFarm?.seasonalCalendar?.[currentSeason]?.map((herb, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 bg-secondary/10 text-secondary text-xs rounded-md"
                        >
                          {herb}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2">
                    <Button variant="default" fullWidth>
                      <Icon name="Eye" size={16} className="mr-2" />
                      View Full Profile
                    </Button>
                    <Button variant="outline" fullWidth>
                      <Icon name="Calendar" size={16} className="mr-2" />
                      View Seasonal Calendar
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-card rounded-xl border border-border p-8 text-center sticky top-24">
                <Icon name="MapPin" size={48} className="text-muted-foreground mx-auto mb-4" />
                <h3 className="font-headline text-lg font-semibold text-text-primary mb-2">
                  Select a Farm
                </h3>
                <p className="text-text-secondary text-sm">
                  Click on any farm marker on the map to view detailed information about their growing practices and seasonal calendar.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Regional Statistics */}
        {mapView === 'regions' && (
          <div className="mt-12">
            <h3 className="font-headline text-2xl font-bold text-text-primary mb-8 text-center">
              Regional Farming Statistics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regionStats?.map((region, index) => (
                <div key={index} className="bg-card rounded-xl border border-border p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-4 h-4 rounded-full ${region?.color}`}></div>
                    <h4 className="font-headline text-lg font-semibold text-text-primary">
                      {region?.region}
                    </h4>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-text-secondary">Certified Farms:</span>
                      <span className="font-semibold text-text-primary">{region?.farms}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-secondary">Avg Quality Score:</span>
                      <span className="font-semibold text-text-primary">{region?.avgQuality}</span>
                    </div>
                    <div>
                      <span className="text-text-secondary text-sm">Top Herbs:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {region?.topHerbs?.map((herb, herbIndex) => (
                          <span
                            key={herbIndex}
                            className="px-2 py-1 bg-muted text-text-primary text-xs rounded-md"
                          >
                            {herb}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default InteractiveMap;