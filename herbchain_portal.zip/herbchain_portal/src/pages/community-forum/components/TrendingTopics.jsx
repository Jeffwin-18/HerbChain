import React from 'react';
import Icon from '../../../components/AppIcon';

const TrendingTopics = ({ topics, onTopicClick }) => {
  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="TrendingUp" size={20} className="text-primary" />
        <h3 className="font-headline font-semibold text-lg text-text-primary">
          Trending Topics
        </h3>
      </div>
      <div className="space-y-3">
        {topics?.map((topic, index) => (
          <div 
            key={topic?.id}
            onClick={() => onTopicClick(topic)}
            className="flex items-center justify-between p-3 rounded-lg hover:bg-muted cursor-pointer transition-smooth group"
          >
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-sm font-semibold">
                {index + 1}
              </div>
              <div>
                <h4 className="font-medium text-text-primary group-hover:text-primary transition-smooth line-clamp-1">
                  {topic?.title}
                </h4>
                <p className="text-xs text-text-secondary">
                  {topic?.posts} posts • {topic?.engagement} engagement
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1 text-xs text-success">
                <Icon name="TrendingUp" size={12} />
                <span>+{topic?.growth}%</span>
              </div>
              <Icon name="ChevronRight" size={16} className="text-text-secondary group-hover:text-primary transition-smooth" />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full text-center text-sm text-primary hover:text-primary/80 transition-smooth font-medium">
          View All Trending Topics
        </button>
      </div>
    </div>
  );
};

export default TrendingTopics;