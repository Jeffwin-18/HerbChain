import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityHero = () => {
  return (
    <section className="relative bg-gradient-to-br from-primary/5 via-background to-accent/5 py-16 lg:py-24">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23059669%22%20fill-opacity%3D%220.03%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center">
                <Icon name="Shield" size={40} className="text-primary" />
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-success rounded-full flex items-center justify-center">
                <Icon name="Check" size={16} className="text-white" />
              </div>
            </div>
          </div>
          
          <h1 className="font-headline text-4xl lg:text-6xl font-bold text-text-primary mb-6">
            Trust & Security
            <span className="block text-primary">Center</span>
          </h1>
          
          <p className="text-xl lg:text-2xl text-text-secondary mb-8 leading-relaxed">
            Transparent security architecture and privacy policies that protect your data while building trust through blockchain immutability and agricultural expertise.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="flex items-center space-x-2 text-success">
              <Icon name="Shield" size={20} />
              <span className="font-medium">Bank-Level Security</span>
            </div>
            <div className="hidden sm:block w-px h-6 bg-border"></div>
            <div className="flex items-center space-x-2 text-primary">
              <Icon name="Lock" size={20} />
              <span className="font-medium">GDPR Compliant</span>
            </div>
            <div className="hidden sm:block w-px h-6 bg-border"></div>
            <div className="flex items-center space-x-2 text-accent">
              <Icon name="Eye" size={20} />
              <span className="font-medium">Full Transparency</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityHero;