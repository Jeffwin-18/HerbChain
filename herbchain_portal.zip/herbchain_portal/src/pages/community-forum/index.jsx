import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import CategoryCard from './components/CategoryCard';
import PostCard from './components/PostCard';
import UserProfileCard from './components/UserProfileCard';
import SearchFilters from './components/SearchFilters';
import TrendingTopics from './components/TrendingTopics';
import CommunityStats from './components/CommunityStats';

const CommunityForum = () => {
  const [activeView, setActiveView] = useState('categories');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSort, setSelectedSort] = useState('recent');
  const [currentUser, setCurrentUser] = useState(null);

  // Mock data for categories
  const categories = [
    {
      id: 'farmer-stories',
      name: 'Farmer Success Stories',
      description: 'Share your journey from traditional farming to blockchain-verified agriculture. Celebrate achievements and inspire others.',
      icon: 'Trophy',
      iconColor: 'text-success',
      bgColor: 'bg-success/10',
      postCount: 156,
      activeUsers: 23,
      lastActivity: '2 hours ago',
      recentUsers: [
        { name: 'Maria Rodriguez' },
        { name: 'John Chen' },
        { name: 'Sarah Johnson' }
      ]
    },
    {
      id: 'growing-tips',
      name: 'Growing Tips & Techniques',
      description: 'Exchange knowledge about herb cultivation, sustainable practices, and innovative growing methods.',
      icon: 'Sprout',
      iconColor: 'text-primary',
      bgColor: 'bg-primary/10',
      postCount: 342,
      activeUsers: 45,
      lastActivity: '30 minutes ago',
      recentUsers: [
        { name: 'David Kim' },
        { name: 'Lisa Wong' },
        { name: 'Ahmed Hassan' }
      ]
    },
    {
      id: 'blockchain',
      name: 'Blockchain Questions',
      description: 'Get help with blockchain integration, smart contracts, and technical implementation challenges.',
      icon: 'Link',
      iconColor: 'text-accent',
      bgColor: 'bg-accent/10',
      postCount: 89,
      activeUsers: 12,
      lastActivity: '1 hour ago',
      recentUsers: [
        { name: 'Tech Support' },
        { name: 'Mike Developer' },
        { name: 'Crypto Expert' }
      ]
    },
    {
      id: 'consumer-feedback',
      name: 'Consumer Feedback',
      description: 'Share your experiences with verified herbs and provide feedback to farmers and the community.',
      icon: 'MessageSquare',
      iconColor: 'text-secondary',
      bgColor: 'bg-secondary/10',
      postCount: 234,
      activeUsers: 67,
      lastActivity: '15 minutes ago',
      recentUsers: [
        { name: 'Happy Customer' },
        { name: 'Health Enthusiast' },
        { name: 'Organic Lover' }
      ]
    },
    {
      id: 'industry-news',
      name: 'Industry News',
      description: 'Stay updated with the latest developments in agricultural technology, regulations, and market trends.',
      icon: 'Newspaper',
      iconColor: 'text-warning',
      bgColor: 'bg-warning/10',
      postCount: 78,
      activeUsers: 34,
      lastActivity: '3 hours ago',
      recentUsers: [
        { name: 'News Bot' },
        { name: 'Industry Expert' },
        { name: 'Market Analyst' }
      ]
    },
    {
      id: 'general',
      name: 'General Discussion',
      description: 'Open discussions about anything related to sustainable agriculture, community building, and platform feedback.',
      icon: 'Users',
      iconColor: 'text-text-primary',
      bgColor: 'bg-muted',
      postCount: 445,
      activeUsers: 89,
      lastActivity: '5 minutes ago',
      recentUsers: [
        { name: 'Community Manager' },
        { name: 'Active Member' },
        { name: 'New User' }
      ]
    }
  ];

  // Mock data for recent posts
  const recentPosts = [
    {
      id: 1,
      title: 'How blockchain verification increased my herb sales by 300%',
      content: `After joining HerbChain Portal six months ago, I've seen incredible growth in my business. The blockchain verification process initially seemed complex, but the support team guided me through every step.\n\nCustomers now specifically seek out my verified herbs, and I can charge premium prices because buyers trust the authenticity. The QR codes on my products have become a selling point rather than just a requirement.`,
      author: {
        name: 'Maria Rodriguez',status: 'verified-farmer',location: 'California, USA',avatar: 'https://randomuser.me/api/portraits/women/32.jpg'
      },
      category: 'farmer-stories',replies: 23,likes: 156,views: 892,timeAgo: '2 hours ago',
      tags: ['success-story', 'blockchain', 'sales-growth'],
      images: [
        'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400','https://images.unsplash.com/photo-1464226184884-fa280b87c399?w=400'
      ]
    },
    {
      id: 2,
      title: 'Best practices for organic basil cultivation in greenhouse environments',content: `I've been growing organic basil for over 15 years, and I'd like to share some techniques that have consistently produced high-quality yields.\n\nTemperature control is crucial - maintain 65-75°F during the day and 60-65°F at night. Humidity should be kept between 40-60% to prevent fungal issues while ensuring optimal growth conditions.`,
      author: {
        name: 'David Kim',status: 'expert',location: 'Oregon, USA',avatar: 'https://randomuser.me/api/portraits/men/45.jpg'
      },
      category: 'growing-tips',replies: 34,likes: 89,views: 567,timeAgo: '4 hours ago',
      tags: ['basil', 'greenhouse', 'organic', 'cultivation'],
      images: [
        'https://images.unsplash.com/photo-1618164436241-4473940d1f5c?w=400'
      ]
    },
    {
      id: 3,
      title: 'Question about smart contract gas fees for small farmers',content: `I'm a small-scale farmer interested in joining the platform, but I'm concerned about the costs associated with blockchain transactions. Can someone explain how gas fees work and if there are any programs to help smaller operations get started?`,
      author: {
        name: 'Sarah Johnson',status: 'consumer',location: 'Texas, USA',avatar: 'https://randomuser.me/api/portraits/women/28.jpg'
      },
      category: 'blockchain',replies: 12,likes: 45,views: 234,timeAgo: '6 hours ago',
      tags: ['gas-fees', 'smart-contracts', 'small-farmers']
    },
    {
      id: 4,
      title: 'Amazing quality herbs from Johnson Family Farm!',
      content: `I recently purchased verified oregano and thyme from Johnson Family Farm through the HerbChain platform. The QR code verification showed the complete journey from seed to harvest.\n\nThe herbs arrived fresh, aromatic, and exactly as described. Being able to see the farm's practices and certifications gave me complete confidence in my purchase.`,
      author: {
        name: 'Lisa Wong',
        status: 'consumer',
        location: 'New York, USA',
        avatar: 'https://randomuser.me/api/portraits/women/35.jpg'
      },
      category: 'consumer-feedback',
      replies: 8,
      likes: 67,
      views: 345,
      timeAgo: '8 hours ago',
      tags: ['product-review', 'johnson-farm', 'oregano', 'thyme']
    },
    {
      id: 5,
      title: 'New USDA regulations for organic certification - What farmers need to know',
      content: `The USDA has announced updated guidelines for organic certification that will take effect in Q2 2025. These changes will impact how blockchain verification integrates with traditional certification processes.\n\nKey changes include enhanced documentation requirements and new digital record-keeping standards that align perfectly with blockchain technology.`,
      author: {
        name: 'Industry Expert',
        status: 'expert',
        location: 'Washington, DC',
        avatar: 'https://randomuser.me/api/portraits/men/52.jpg'
      },
      category: 'industry-news',
      replies: 19,
      likes: 78,
      views: 456,
      timeAgo: '12 hours ago',
      tags: ['usda', 'regulations', 'organic-certification', '2025']
    }
  ];

  // Mock data for trending topics
  const trendingTopics = [
    {
      id: 1,
      title: 'Sustainable farming practices',
      posts: 45,
      engagement: '2.3k',
      growth: 15
    },
    {
      id: 2,
      title: 'Blockchain integration tips',
      posts: 23,
      engagement: '1.8k',
      growth: 28
    },
    {
      id: 3,
      title: 'Herb quality standards',
      posts: 34,
      engagement: '1.5k',
      growth: 12
    },
    {
      id: 4,
      title: 'Consumer feedback analysis',
      posts: 19,
      engagement: '1.2k',
      growth: 22
    },
    {
      id: 5,
      title: 'Market pricing strategies',
      posts: 28,
      engagement: '1.1k',
      growth: 8
    }
  ];

  // Mock data for community stats
  const communityStats = {
    activeMembers: '2,847',
    memberGrowth: 12,
    totalPosts: '8,934',
    postGrowth: 18,
    verifiedFarmers: '456',
    farmerGrowth: 25,
    experts: '89',
    expertGrowth: 15
  };

  // Mock data for featured users
  const featuredUsers = [
    {
      id: 1,
      name: 'Maria Rodriguez',
      status: 'verified-farmer',
      location: 'California, USA',
      bio: 'Organic herb farmer specializing in Mediterranean varieties. 15+ years experience in sustainable agriculture.',
      avatar: 'https://randomuser.me/api/portraits/women/32.jpg',
      posts: 45,
      reputation: 892,
      joined: '2023',
      badges: [
        { name: 'Top Contributor', icon: 'Award' },
        { name: 'Verified Farmer', icon: 'Shield' }
      ],
      specialties: ['Basil', 'Oregano', 'Thyme', 'Rosemary']
    },
    {
      id: 2,
      name: 'David Kim',
      status: 'expert',
      location: 'Oregon, USA',
      bio: 'Agricultural consultant and greenhouse specialist. Helping farmers optimize their growing operations.',
      avatar: 'https://randomuser.me/api/portraits/men/45.jpg',
      posts: 78,
      reputation: 1234,
      joined: '2022',
      badges: [
        { name: 'Expert', icon: 'Award' },
        { name: 'Helpful', icon: 'Heart' }
      ],
      specialties: ['Greenhouse', 'Hydroponics', 'Climate Control']
    },
    {
      id: 3,
      name: 'Tech Support',
      status: 'moderator',
      location: 'Remote',
      bio: 'Official HerbChain support team member. Here to help with technical questions and platform issues.',
      posts: 234,
      reputation: 2156,
      joined: '2022',
      badges: [
        { name: 'Moderator', icon: 'Crown' },
        { name: 'Tech Expert', icon: 'Code' }
      ],
      specialties: ['Blockchain', 'Smart Contracts', 'Platform Support']
    }
  ];

  const handleCategoryClick = (category) => {
    setSelectedCategory(category?.id);
    setActiveView('posts');
  };

  const handlePostClick = (post) => {
    // In a real app, this would navigate to the post detail page
    console.log('Opening post:', post?.title);
  };

  const handleTopicClick = (topic) => {
    setSearchQuery(topic?.title);
    setActiveView('posts');
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedSort('recent');
  };

  const filteredPosts = recentPosts?.filter(post => {
    const matchesSearch = searchQuery === '' || 
      post?.title?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
      post?.content?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
      post?.tags?.some(tag => tag?.toLowerCase()?.includes(searchQuery?.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'all' || post?.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  useEffect(() => {
    // Simulate user authentication check
    setCurrentUser({
      name: 'John Doe',
      status: 'consumer',
      avatar: null
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Community Forum - HerbChain Portal</title>
        <meta name="description" content="Connect with farmers, consumers, and experts in the HerbChain community. Share knowledge, ask questions, and build relationships in sustainable agriculture." />
      </Helmet>
      <Header />
      <main className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h1 className="font-headline font-bold text-4xl md:text-5xl text-text-primary mb-4">
                Community Forum
              </h1>
              <p className="text-xl text-text-secondary max-w-3xl mx-auto mb-8">
                Connect with farmers, consumers, and experts. Share knowledge, ask questions, and build relationships in the sustainable agriculture community.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4">
                <Button 
                  variant="default" 
                  size="lg"
                  iconName="Plus"
                  iconPosition="left"
                  className="bg-primary hover:bg-primary/90"
                >
                  Start New Discussion
                </Button>
                <Button 
                  variant="outline" 
                  size="lg"
                  iconName="Users"
                  iconPosition="left"
                >
                  Join Community
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              <div className="text-center p-4 bg-card/50 backdrop-blur-sm rounded-lg border border-border/50">
                <div className="font-headline font-bold text-2xl text-primary mb-1">2.8k+</div>
                <div className="text-sm text-text-secondary">Active Members</div>
              </div>
              <div className="text-center p-4 bg-card/50 backdrop-blur-sm rounded-lg border border-border/50">
                <div className="font-headline font-bold text-2xl text-accent mb-1">8.9k+</div>
                <div className="text-sm text-text-secondary">Total Posts</div>
              </div>
              <div className="text-center p-4 bg-card/50 backdrop-blur-sm rounded-lg border border-border/50">
                <div className="font-headline font-bold text-2xl text-success mb-1">456</div>
                <div className="text-sm text-text-secondary">Verified Farmers</div>
              </div>
              <div className="text-center p-4 bg-card/50 backdrop-blur-sm rounded-lg border border-border/50">
                <div className="font-headline font-bold text-2xl text-warning mb-1">89</div>
                <div className="text-sm text-text-secondary">Expert Contributors</div>
              </div>
            </div>
          </div>
        </section>

        {/* Navigation Tabs */}
        <section className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-16 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex space-x-8 overflow-x-auto">
              <button
                onClick={() => setActiveView('categories')}
                className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap transition-smooth ${
                  activeView === 'categories' ?'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                Categories
              </button>
              <button
                onClick={() => setActiveView('posts')}
                className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap transition-smooth ${
                  activeView === 'posts' ?'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                Recent Posts
              </button>
              <button
                onClick={() => setActiveView('trending')}
                className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap transition-smooth ${
                  activeView === 'trending' ?'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                Trending
              </button>
              <button
                onClick={() => setActiveView('members')}
                className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap transition-smooth ${
                  activeView === 'members' ?'border-primary text-primary' :'border-transparent text-text-secondary hover:text-text-primary hover:border-border'
                }`}
              >
                Featured Members
              </button>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              {/* Main Content Area */}
              <div className="lg:col-span-3">
                {activeView === 'categories' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-headline font-semibold text-2xl text-text-primary">
                        Discussion Categories
                      </h2>
                      <Button variant="outline" size="sm" iconName="Grid3X3">
                        View All
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {categories?.map((category) => (
                        <CategoryCard
                          key={category?.id}
                          category={category}
                          onClick={handleCategoryClick}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {activeView === 'posts' && (
                  <div>
                    <SearchFilters
                      searchQuery={searchQuery}
                      setSearchQuery={setSearchQuery}
                      selectedCategory={selectedCategory}
                      setSelectedCategory={setSelectedCategory}
                      selectedSort={selectedSort}
                      setSelectedSort={setSelectedSort}
                      onClearFilters={handleClearFilters}
                    />
                    
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-headline font-semibold text-2xl text-text-primary">
                        {selectedCategory === 'all' ? 'All Posts' : 
                         categories?.find(c => c?.id === selectedCategory)?.name || 'Posts'}
                      </h2>
                      <div className="text-sm text-text-secondary">
                        {filteredPosts?.length} posts found
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      {filteredPosts?.map((post) => (
                        <PostCard
                          key={post?.id}
                          post={post}
                          onClick={handlePostClick}
                        />
                      ))}
                    </div>
                    
                    {filteredPosts?.length === 0 && (
                      <div className="text-center py-12">
                        <Icon name="Search" size={48} className="text-text-secondary mx-auto mb-4" />
                        <h3 className="font-headline font-semibold text-lg text-text-primary mb-2">
                          No posts found
                        </h3>
                        <p className="text-text-secondary mb-4">
                          Try adjusting your search criteria or browse different categories.
                        </p>
                        <Button variant="outline" onClick={handleClearFilters}>
                          Clear Filters
                        </Button>
                      </div>
                    )}
                  </div>
                )}

                {activeView === 'trending' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-headline font-semibold text-2xl text-text-primary">
                        Trending Discussions
                      </h2>
                    </div>
                    
                    <div className="space-y-6">
                      {recentPosts?.slice(0, 3)?.map((post) => (
                        <PostCard
                          key={post?.id}
                          post={post}
                          onClick={handlePostClick}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {activeView === 'members' && (
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-headline font-semibold text-2xl text-text-primary">
                        Featured Community Members
                      </h2>
                    </div>
                    
                    <div className="space-y-6">
                      {featuredUsers?.map((user) => (
                        <UserProfileCard key={user?.id} user={user} />
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Sidebar */}
              <div className="lg:col-span-1 space-y-6">
                <TrendingTopics 
                  topics={trendingTopics} 
                  onTopicClick={handleTopicClick}
                />
                
                <CommunityStats stats={communityStats} />
                
                {/* Quick Actions */}
                <div className="bg-card border border-border rounded-lg p-6">
                  <h3 className="font-headline font-semibold text-lg text-text-primary mb-4">
                    Quick Actions
                  </h3>
                  
                  <div className="space-y-3">
                    <Button variant="outline" fullWidth iconName="Plus" iconPosition="left">
                      New Discussion
                    </Button>
                    <Button variant="outline" fullWidth iconName="Search" iconPosition="left">
                      Advanced Search
                    </Button>
                    <Button variant="outline" fullWidth iconName="Bell" iconPosition="left">
                      Notifications
                    </Button>
                    <Button variant="outline" fullWidth iconName="Settings" iconPosition="left">
                      Forum Settings
                    </Button>
                  </div>
                </div>

                {/* Community Guidelines */}
                <div className="bg-card border border-border rounded-lg p-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <Icon name="Shield" size={20} className="text-primary" />
                    <h3 className="font-headline font-semibold text-lg text-text-primary">
                      Community Guidelines
                    </h3>
                  </div>
                  
                  <div className="space-y-3 text-sm text-text-secondary">
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Be respectful and constructive in discussions</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Share accurate information and cite sources</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Help others learn and grow in the community</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="X" size={16} className="text-error mt-0.5 flex-shrink-0" />
                      <span>No spam, self-promotion, or off-topic content</span>
                    </div>
                  </div>
                  
                  <Button variant="ghost" size="sm" className="w-full mt-4 text-primary">
                    Read Full Guidelines
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-text-secondary text-sm">
              © {new Date()?.getFullYear()} HerbChain Portal. Building trust through transparency.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CommunityForum;