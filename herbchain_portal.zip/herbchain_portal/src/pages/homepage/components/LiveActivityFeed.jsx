import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const LiveActivityFeed = () => {
  const [activities, setActivities] = useState([]);
  const [isLive, setIsLive] = useState(true);

  // Mock activity data
  const mockActivities = [
    {
      id: 1,
      type: "verification",
      farm: "Green Valley Herbs",
      herb: "Organic Basil",
      location: "California, USA",
      timestamp: new Date(Date.now() - 120000), // 2 minutes ago
      status: "verified",
      batchId: "GVH-2024-001",
      qrScans: 23
    },
    {
      id: 2,
      type: "scan",
      consumer: "Sarah M.",
      herb: "Wild Thyme",
      farm: "Mountain Peak Farm",
      timestamp: new Date(Date.now() - 300000), // 5 minutes ago
      status: "scanned",
      location: "Denver, CO"
    },
    {
      id: 3,
      type: "registration",
      farm: "Sunrise Botanicals",
      location: "Oregon, USA",
      timestamp: new Date(Date.now() - 480000), // 8 minutes ago
      status: "approved",
      specialties: ["Mint", "Oregano", "Cilantro"]
    },
    {
      id: 4,
      type: "verification",
      farm: "Heritage Herb Gardens",
      herb: "Chamomile",
      location: "Vermont, USA",
      timestamp: new Date(Date.now() - 720000), // 12 minutes ago
      status: "processing",
      batchId: "HHG-2024-089"
    },
    {
      id: 5,
      type: "scan",
      consumer: "Mike R.",
      herb: "Fresh Mint",
      farm: "Sunrise Botanicals",
      timestamp: new Date(Date.now() - 900000), // 15 minutes ago
      status: "scanned",
      location: "Portland, OR"
    },
    {
      id: 6,
      type: "verification",
      farm: "Coastal Herb Co.",
      herb: "Sea Salt Rosemary",
      location: "Maine, USA",
      timestamp: new Date(Date.now() - 1080000), // 18 minutes ago
      status: "verified",
      batchId: "CHC-2024-156",
      qrScans: 41
    }
  ];

  // Initialize activities
  useEffect(() => {
    setActivities(mockActivities);
  }, []);

  // Simulate live updates
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      const newActivity = {
        id: Date.now(),
        type: Math.random() > 0.6 ? "verification" : "scan",
        farm: ["Green Valley Herbs", "Mountain Peak Farm", "Sunrise Botanicals", "Heritage Herb Gardens"]?.[Math.floor(Math.random() * 4)],
        herb: ["Organic Basil", "Wild Thyme", "Fresh Mint", "Chamomile", "Rosemary"]?.[Math.floor(Math.random() * 5)],
        location: ["California, USA", "Colorado, USA", "Oregon, USA", "Vermont, USA"]?.[Math.floor(Math.random() * 4)],
        timestamp: new Date(),
        status: Math.random() > 0.3 ? "verified" : "processing",
        batchId: `${Math.random()?.toString(36)?.substr(2, 3)?.toUpperCase()}-2024-${Math.floor(Math.random() * 999)?.toString()?.padStart(3, '0')}`,
        qrScans: Math.floor(Math.random() * 50) + 1
      };

      setActivities(prev => [newActivity, ...prev?.slice(0, 9)]);
    }, 15000); // New activity every 15 seconds

    return () => clearInterval(interval);
  }, [isLive]);

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return timestamp?.toLocaleDateString();
  };

  const getActivityIcon = (type, status) => {
    if (type === "verification") {
      return status === "verified" ? "CheckCircle" : "Clock";
    }
    if (type === "scan") return "QrCode";
    if (type === "registration") return "UserPlus";
    return "Activity";
  };

  const getActivityColor = (type, status) => {
    if (type === "verification") {
      return status === "verified" ? "text-conversion" : "text-warning";
    }
    if (type === "scan") return "text-accent";
    if (type === "registration") return "text-primary";
    return "text-text-secondary";
  };

  const getActivityBg = (type, status) => {
    if (type === "verification") {
      return status === "verified" ? "bg-conversion/10" : "bg-warning/10";
    }
    if (type === "scan") return "bg-accent/10";
    if (type === "registration") return "bg-primary/10";
    return "bg-muted";
  };

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 bg-accent/10 text-accent px-4 py-2 rounded-full text-sm font-medium mb-4">
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
              <span>Live Activity</span>
            </div>
            <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Real-Time Blockchain Activity
            </h2>
            <p className="text-lg text-text-secondary max-w-2xl mx-auto">
              Watch as farmers verify their herbs and consumers discover authentic products 
              through our transparent blockchain network.
            </p>
          </div>

          {/* Activity Feed */}
          <div className="bg-card rounded-2xl border border-border shadow-warm overflow-hidden">
            {/* Feed Header */}
            <div className="flex items-center justify-between p-6 border-b border-border bg-muted/20">
              <div className="flex items-center space-x-3">
                <Icon name="Activity" size={20} className="text-primary" />
                <h3 className="font-headline text-lg font-semibold text-text-primary">
                  Network Activity
                </h3>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-conversion animate-pulse' : 'bg-text-secondary'}`}></div>
                  <span className="text-sm font-medium text-text-secondary">
                    {isLive ? 'Live' : 'Paused'}
                  </span>
                </div>
                <button
                  onClick={() => setIsLive(!isLive)}
                  className="text-text-secondary hover:text-primary transition-colors"
                >
                  <Icon name={isLive ? "Pause" : "Play"} size={16} />
                </button>
              </div>
            </div>

            {/* Activity List */}
            <div className="divide-y divide-border max-h-96 overflow-y-auto">
              {activities?.map((activity, index) => (
                <div 
                  key={activity?.id}
                  className={`p-4 hover:bg-muted/30 transition-colors ${
                    index === 0 && isLive ? 'animate-pulse-soft' : ''
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    {/* Activity Icon */}
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      getActivityBg(activity?.type, activity?.status)
                    }`}>
                      <Icon 
                        name={getActivityIcon(activity?.type, activity?.status)} 
                        size={18} 
                        className={getActivityColor(activity?.type, activity?.status)}
                      />
                    </div>

                    {/* Activity Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          {activity?.type === "verification" && (
                            <div>
                              <p className="text-sm font-medium text-text-primary">
                                <span className="font-semibold">{activity?.farm}</span> {
                                  activity?.status === "verified" ? "verified" : "is processing"
                                } <span className="text-primary">{activity?.herb}</span>
                              </p>
                              <div className="flex items-center space-x-4 text-xs text-text-secondary">
                                <span className="flex items-center space-x-1">
                                  <Icon name="MapPin" size={12} />
                                  <span>{activity?.location}</span>
                                </span>
                                <span className="flex items-center space-x-1">
                                  <Icon name="Hash" size={12} />
                                  <span>{activity?.batchId}</span>
                                </span>
                                {activity?.qrScans && (
                                  <span className="flex items-center space-x-1">
                                    <Icon name="Eye" size={12} />
                                    <span>{activity?.qrScans} scans</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          )}

                          {activity?.type === "scan" && (
                            <div>
                              <p className="text-sm font-medium text-text-primary">
                                <span className="font-semibold">{activity?.consumer}</span> scanned{' '}
                                <span className="text-accent">{activity?.herb}</span> from{' '}
                                <span className="font-semibold">{activity?.farm}</span>
                              </p>
                              <div className="flex items-center space-x-4 text-xs text-text-secondary">
                                <span className="flex items-center space-x-1">
                                  <Icon name="MapPin" size={12} />
                                  <span>{activity?.location}</span>
                                </span>
                              </div>
                            </div>
                          )}

                          {activity?.type === "registration" && (
                            <div>
                              <p className="text-sm font-medium text-text-primary">
                                <span className="font-semibold">{activity?.farm}</span> joined the network
                              </p>
                              <div className="flex items-center space-x-4 text-xs text-text-secondary">
                                <span className="flex items-center space-x-1">
                                  <Icon name="MapPin" size={12} />
                                  <span>{activity?.location}</span>
                                </span>
                                <span>Specializes in {activity?.specialties?.join(", ")}</span>
                              </div>
                            </div>
                          )}
                        </div>

                        <span className="text-xs text-text-secondary whitespace-nowrap ml-4">
                          {getTimeAgo(activity?.timestamp)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Feed Footer */}
            <div className="p-4 bg-muted/20 border-t border-border text-center">
              <p className="text-sm text-text-secondary">
                Showing recent activity from our blockchain network
              </p>
            </div>
          </div>

          {/* Activity Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div className="bg-card rounded-lg p-4 border border-border text-center">
              <div className="text-2xl font-bold text-conversion font-headline">156,789</div>
              <div className="text-xs text-text-secondary font-medium">Total QR Scans</div>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border text-center">
              <div className="text-2xl font-bold text-primary font-headline">28,956</div>
              <div className="text-xs text-text-secondary font-medium">Verifications</div>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border text-center">
              <div className="text-2xl font-bold text-accent font-headline">342</div>
              <div className="text-xs text-text-secondary font-medium">Active Farms</div>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border text-center">
              <div className="text-2xl font-bold text-secondary font-headline">99.9%</div>
              <div className="text-xs text-text-secondary font-medium">Network Uptime</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LiveActivityFeed;