import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const HeroSection = () => {
  const [stats, setStats] = useState({
    herbsVerified: 0,
    activeFarms: 0,
    transactions: 0
  });

  // Animate counters on mount
  useEffect(() => {
    const animateCounter = (target, key) => {
      let current = 0;
      const increment = target / 100;
      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setStats(prev => ({ ...prev, [key]: Math.floor(current) }));
      }, 20);
    };

    animateCounter(12847, 'herbsVerified');
    animateCounter(342, 'activeFarms');
    animateCounter(28956, 'transactions');
  }, []);

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-background via-muted to-background overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-accent rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-secondary rounded-full blur-3xl"></div>
      </div>
      <div className="relative z-10 container mx-auto px-4 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Main Headline */}
            <div className="space-y-4">
              <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
                <Icon name="Leaf" size={16} />
                <span>Blockchain-Powered Transparency</span>
              </div>
              <h1 className="font-headline text-5xl lg:text-6xl font-bold text-text-primary leading-tight">
                Every Herb Has a{' '}
                <span className="text-primary relative">
                  Story
                  <svg
                    className="absolute -bottom-2 left-0 w-full h-3 text-primary/20"
                    viewBox="0 0 200 12"
                    fill="currentColor"
                  >
                    <path d="M0,8 Q50,2 100,8 T200,8 L200,12 L0,12 Z" />
                  </svg>
                </span>
              </h1>
              <p className="text-xl text-text-secondary leading-relaxed max-w-lg">
                Transform herb supply chain transparency through immutable blockchain records. 
                Bridge the gap between farmers and consumers with verifiable authenticity.
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/verification-center">
                <Button 
                  variant="default" 
                  size="lg" 
                  className="bg-primary hover:bg-primary/90 text-white w-full sm:w-auto"
                  iconName="Leaf"
                  iconPosition="left"
                >
                  Start Verifying Your Herbs
                </Button>
              </Link>
              <Link to="/consumer-qr-scanner">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="w-full sm:w-auto"
                  iconName="QrCode"
                  iconPosition="left"
                >
                  Scan & Discover
                </Button>
              </Link>
            </div>

            {/* Live Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-primary font-headline">
                  {stats?.herbsVerified?.toLocaleString()}
                </div>
                <div className="text-sm text-text-secondary font-medium">Herbs Verified</div>
              </div>
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-accent font-headline">
                  {stats?.activeFarms?.toLocaleString()}
                </div>
                <div className="text-sm text-text-secondary font-medium">Active Farms</div>
              </div>
              <div className="text-center">
                <div className="text-2xl lg:text-3xl font-bold text-conversion font-headline">
                  {stats?.transactions?.toLocaleString()}
                </div>
                <div className="text-sm text-text-secondary font-medium">Transactions</div>
              </div>
            </div>
          </div>

          {/* Right Content - Blockchain Visualization */}
          <div className="relative">
            <div className="relative bg-card rounded-2xl p-8 shadow-warm border border-border">
              {/* Blockchain Flow Animation */}
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h3 className="font-headline text-xl font-semibold text-text-primary mb-2">
                    Live Blockchain Activity
                  </h3>
                  <p className="text-text-secondary text-sm">
                    Real-time verification happening now
                  </p>
                </div>

                {/* Animated Blocks */}
                <div className="space-y-4">
                  {[
                    { farm: "Green Valley Herbs", herb: "Organic Basil", status: "Verified", time: "2 min ago" },
                    { farm: "Mountain Peak Farm", herb: "Wild Thyme", status: "Processing", time: "5 min ago" },
                    { farm: "Sunrise Botanicals", herb: "Fresh Mint", status: "Confirmed", time: "8 min ago" }
                  ]?.map((item, index) => (
                    <div 
                      key={index}
                      className="flex items-center space-x-4 p-4 bg-muted/50 rounded-lg border border-border/50 transition-all duration-300 hover:shadow-md"
                    >
                      <div className={`w-3 h-3 rounded-full ${
                        item?.status === 'Verified' ? 'bg-conversion animate-pulse' :
                        item?.status === 'Processing'? 'bg-warning animate-pulse' : 'bg-accent'
                      }`}></div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-text-primary truncate">
                          {item?.herb}
                        </div>
                        <div className="text-xs text-text-secondary">
                          {item?.farm} • {item?.time}
                        </div>
                      </div>
                      <div className={`text-xs px-2 py-1 rounded-full font-medium ${
                        item?.status === 'Verified' ? 'bg-conversion/10 text-conversion' :
                        item?.status === 'Processing'? 'bg-warning/10 text-warning' : 'bg-accent/10 text-accent'
                      }`}>
                        {item?.status}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Blockchain Network Visualization */}
                <div className="relative mt-8 p-6 bg-gradient-to-r from-primary/5 to-accent/5 rounded-lg border border-primary/10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                        <Icon name="Database" size={16} color="white" />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-text-primary">Blockchain Network</div>
                        <div className="text-xs text-text-secondary">99.9% Uptime</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-conversion rounded-full animate-pulse"></div>
                      <span className="text-xs text-conversion font-medium">Active</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center animate-pulse">
              <Icon name="Shield" size={24} className="text-primary" />
            </div>
            <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center animate-pulse">
              <Icon name="Zap" size={16} className="text-accent" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;