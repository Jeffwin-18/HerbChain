import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QRScannerCamera = ({ onScanResult, isScanning, onStartScan, onStopScan }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [hasPermission, setHasPermission] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (isScanning) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => stopCamera();
  }, [isScanning]);

  const startCamera = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const stream = await navigator.mediaDevices?.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });

      if (videoRef?.current) {
        videoRef.current.srcObject = stream;
        videoRef?.current?.play();
        setHasPermission(true);
        
        // Simulate QR detection for demo
        setTimeout(() => {
          simulateQRDetection();
        }, 3000);
      }
    } catch (err) {
      setError('Camera access denied. Please enable camera permissions.');
      setHasPermission(false);
    } finally {
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (videoRef?.current && videoRef?.current?.srcObject) {
      const tracks = videoRef?.current?.srcObject?.getTracks();
      tracks?.forEach(track => track?.stop());
      videoRef.current.srcObject = null;
    }
  };

  const simulateQRDetection = () => {
    // Mock QR scan result
    const mockResult = {
      qrCode: 'HBC-2024-FARM-001-BASIL-BATCH-789',
      timestamp: new Date()?.toISOString(),
      scanned: true
    };
    
    onScanResult(mockResult);
    onStopScan();
  };

  const handleManualEntry = () => {
    const mockCode = prompt('Enter QR Code manually:');
    if (mockCode) {
      const mockResult = {
        qrCode: mockCode,
        timestamp: new Date()?.toISOString(),
        scanned: false,
        manual: true
      };
      onScanResult(mockResult);
    }
  };

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className="relative bg-card rounded-2xl overflow-hidden shadow-warm border border-border">
        {/* Camera View */}
        <div className="relative aspect-square bg-muted">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-sm text-text-secondary">Starting camera...</p>
              </div>
            </div>
          )}

          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/90 backdrop-blur-sm">
              <div className="text-center p-6">
                <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
                <p className="text-sm text-error mb-4">{error}</p>
                <Button variant="outline" size="sm" onClick={() => window.location?.reload()}>
                  Retry
                </Button>
              </div>
            </div>
          )}

          <video
            ref={videoRef}
            className="w-full h-full object-cover"
            playsInline
            muted
          />
          
          <canvas ref={canvasRef} className="hidden" />

          {/* Scanning Overlay */}
          {isScanning && hasPermission && (
            <div className="absolute inset-0">
              {/* Corner Brackets */}
              <div className="absolute top-8 left-8 w-8 h-8 border-l-4 border-t-4 border-primary rounded-tl-lg"></div>
              <div className="absolute top-8 right-8 w-8 h-8 border-r-4 border-t-4 border-primary rounded-tr-lg"></div>
              <div className="absolute bottom-8 left-8 w-8 h-8 border-l-4 border-b-4 border-primary rounded-bl-lg"></div>
              <div className="absolute bottom-8 right-8 w-8 h-8 border-r-4 border-b-4 border-primary rounded-br-lg"></div>

              {/* Scanning Line */}
              <div className="absolute inset-x-8 top-1/2 h-0.5 bg-primary animate-pulse"></div>

              {/* Instructions */}
              <div className="absolute bottom-4 left-4 right-4 text-center">
                <p className="text-white text-sm bg-black/50 rounded-lg px-3 py-2 backdrop-blur-sm">
                  Position QR code within the frame
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="p-4 bg-card">
          <div className="flex items-center justify-between gap-4">
            {!isScanning ? (
              <Button 
                variant="default" 
                fullWidth 
                onClick={onStartScan}
                iconName="Camera"
                iconPosition="left"
                className="bg-primary hover:bg-primary/90"
              >
                Start Scanning
              </Button>
            ) : (
              <Button 
                variant="destructive" 
                fullWidth 
                onClick={onStopScan}
                iconName="Square"
                iconPosition="left"
              >
                Stop Scanning
              </Button>
            )}
          </div>

          <div className="mt-3 pt-3 border-t border-border">
            <Button 
              variant="ghost" 
              size="sm" 
              fullWidth 
              onClick={handleManualEntry}
              iconName="Type"
              iconPosition="left"
            >
              Enter Code Manually
            </Button>
          </div>
        </div>
      </div>
      {/* Tips */}
      <div className="mt-4 p-4 bg-muted rounded-lg">
        <h4 className="font-medium text-sm text-text-primary mb-2 flex items-center">
          <Icon name="Lightbulb" size={16} className="mr-2 text-warning" />
          Scanning Tips
        </h4>
        <ul className="text-xs text-text-secondary space-y-1">
          <li>• Hold your device steady</li>
          <li>• Ensure good lighting</li>
          <li>• Keep QR code within the frame</li>
          <li>• Clean your camera lens if needed</li>
        </ul>
      </div>
    </div>
  );
};

export default QRScannerCamera;