import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';

const UserProfileCard = ({ user }) => {
  const getStatusConfig = (status) => {
    const configs = {
      'verified-farmer': { 
        color: 'text-success', 
        bgColor: 'bg-success/10', 
        icon: 'Shield', 
        label: 'Verified Farmer' 
      },
      'expert': { 
        color: 'text-accent', 
        bgColor: 'bg-accent/10', 
        icon: 'Award', 
        label: 'Expert' 
      },
      'consumer': { 
        color: 'text-secondary', 
        bgColor: 'bg-secondary/10', 
        icon: 'User', 
        label: 'Consumer' 
      },
      'moderator': { 
        color: 'text-warning', 
        bgColor: 'bg-warning/10', 
        icon: 'Crown', 
        label: 'Moderator' 
      }
    };
    
    return configs?.[status] || configs?.consumer;
  };

  const statusConfig = getStatusConfig(user?.status);

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-start space-x-4">
        <div className="flex-shrink-0">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
            {user?.avatar ? (
              <Image 
                src={user?.avatar} 
                alt={user?.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <span className="text-2xl font-semibold text-primary">
                {user?.name?.charAt(0)}
              </span>
            )}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-2">
            <h3 className="font-headline font-semibold text-lg text-text-primary">
              {user?.name}
            </h3>
            <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${statusConfig?.bgColor} ${statusConfig?.color}`}>
              <Icon name={statusConfig?.icon} size={12} />
              <span>{statusConfig?.label}</span>
            </div>
          </div>
          
          {user?.location && (
            <div className="flex items-center space-x-1 text-sm text-text-secondary mb-2">
              <Icon name="MapPin" size={14} />
              <span>{user?.location}</span>
            </div>
          )}
          
          {user?.bio && (
            <p className="text-text-secondary text-sm mb-3 line-clamp-2">
              {user?.bio}
            </p>
          )}
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <div className="font-semibold text-text-primary">{user?.posts}</div>
              <div className="text-xs text-text-secondary">Posts</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-text-primary">{user?.reputation}</div>
              <div className="text-xs text-text-secondary">Reputation</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-text-primary">{user?.joined}</div>
              <div className="text-xs text-text-secondary">Joined</div>
            </div>
          </div>
          
          {user?.badges && user?.badges?.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {user?.badges?.map((badge, index) => (
                <div key={index} className="flex items-center space-x-1 px-2 py-1 bg-muted rounded-full text-xs">
                  <Icon name={badge?.icon} size={12} className="text-primary" />
                  <span className="text-text-secondary">{badge?.name}</span>
                </div>
              ))}
            </div>
          )}
          
          {user?.specialties && user?.specialties?.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {user?.specialties?.map((specialty, index) => (
                <span key={index} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                  {specialty}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserProfileCard;