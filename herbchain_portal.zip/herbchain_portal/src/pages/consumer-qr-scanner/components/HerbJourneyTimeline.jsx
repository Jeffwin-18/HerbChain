import React from 'react';
import Icon from '../../../components/AppIcon';


const HerbJourneyTimeline = ({ herbData }) => {
  const timelineEvents = [
    {
      id: 1,
      title: 'Seed Planting',
      date: '2024-03-15',
      description: 'Organic basil seeds planted in nutrient-rich soil',
      icon: 'Sprout',
      status: 'completed',
      details: {
        temperature: '22°C',
        humidity: '65%',
        soilPH: '6.8'
      }
    },
    {
      id: 2,
      title: 'Germination',
      date: '2024-03-22',
      description: 'First seedlings emerged after 7 days',
      icon: 'Leaf',
      status: 'completed',
      details: {
        germinationRate: '95%',
        waterUsage: '2.5L per m²',
        organicFertilizer: 'Applied'
      }
    },
    {
      id: 3,
      title: 'Growth Phase',
      date: '2024-04-10',
      description: 'Healthy growth with regular organic care',
      icon: 'TreePine',
      status: 'completed',
      details: {
        height: '15cm',
        leafCount: '12-16 per plant',
        pestControl: 'Neem oil treatment'
      }
    },
    {
      id: 4,
      title: 'Quality Testing',
      date: '2024-05-01',
      description: 'Laboratory analysis for purity and nutrients',
      icon: 'FlaskConical',
      status: 'completed',
      details: {
        purityLevel: '99.8%',
        nutrientDensity: 'High',
        contaminants: 'None detected'
      }
    },
    {
      id: 5,
      title: 'Harvest',
      date: '2024-05-15',
      description: 'Hand-picked at optimal freshness',
      icon: 'Scissors',
      status: 'completed',
      details: {
        harvestTime: '6:00 AM',
        freshness: 'Peak condition',
        yield: '2.8kg per m²'
      }
    },
    {
      id: 6,
      title: 'Processing',
      date: '2024-05-15',
      description: 'Cleaned and packaged within 2 hours',
      icon: 'Package',
      status: 'completed',
      details: {
        processingTime: '45 minutes',
        packaging: 'Biodegradable',
        storage: 'Climate controlled'
      }
    },
    {
      id: 7,
      title: 'Blockchain Verification',
      date: '2024-05-16',
      description: 'Immutable record created on HerbChain',
      icon: 'Shield',
      status: 'completed',
      details: {
        blockHash: '0x7f9a...3b2c',
        transactionId: 'HBC789456123',
        verification: 'Complete'
      }
    }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-success';
      case 'in-progress':
        return 'text-warning';
      default:
        return 'text-text-secondary';
    }
  };

  const getStatusBg = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-success/10 border-success/20';
      case 'in-progress':
        return 'bg-warning/10 border-warning/20';
      default:
        return 'bg-muted border-border';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <h3 className="text-2xl font-headline font-bold text-text-primary mb-2">
          Herb Journey Timeline
        </h3>
        <p className="text-text-secondary">
          Follow your {herbData?.herbType || 'basil'} from seed to shelf
        </p>
      </div>
      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border"></div>

        <div className="space-y-6">
          {timelineEvents?.map((event, index) => (
            <div key={event?.id} className="relative flex items-start gap-6">
              {/* Timeline Node */}
              <div className={`relative z-10 flex items-center justify-center w-16 h-16 rounded-full border-2 ${getStatusBg(event?.status)}`}>
                <Icon 
                  name={event?.icon} 
                  size={24} 
                  className={getStatusColor(event?.status)}
                />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0 pb-6">
                <div className="bg-card rounded-xl border border-border p-6 shadow-sm hover:shadow-warm transition-smooth">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="text-lg font-headline font-semibold text-text-primary mb-1">
                        {event?.title}
                      </h4>
                      <p className="text-sm text-text-secondary">
                        {new Date(event.date)?.toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                      event?.status === 'completed' 
                        ? 'bg-success/10 text-success' :'bg-muted text-text-secondary'
                    }`}>
                      {event?.status === 'completed' ? 'Completed' : 'Pending'}
                    </div>
                  </div>

                  <p className="text-text-primary mb-4">
                    {event?.description}
                  </p>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {Object.entries(event?.details)?.map(([key, value]) => (
                      <div key={key} className="bg-muted rounded-lg p-3">
                        <div className="text-xs text-text-secondary font-medium mb-1 capitalize">
                          {key?.replace(/([A-Z])/g, ' $1')?.trim()}
                        </div>
                        <div className="text-sm font-medium text-text-primary">
                          {value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Summary Stats */}
      <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-primary mb-1">62</div>
          <div className="text-xs text-text-secondary">Days to Harvest</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-success mb-1">99.8%</div>
          <div className="text-xs text-text-secondary">Purity Level</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-accent mb-1">100%</div>
          <div className="text-xs text-text-secondary">Organic</div>
        </div>
        <div className="bg-card rounded-lg border border-border p-4 text-center">
          <div className="text-2xl font-bold text-warning mb-1">7</div>
          <div className="text-xs text-text-secondary">Verifications</div>
        </div>
      </div>
    </div>
  );
};

export default HerbJourneyTimeline;