import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SecurityAudits = () => {
  const [selectedAudit, setSelectedAudit] = useState(0);

  const auditReports = [
    {
      id: "2024-Q3",
      title: "Q3 2024 Security Assessment",
      auditor: "CyberSec Solutions",
      date: "September 15, 2024",
      type: "Penetration Testing",
      status: "Completed",
      score: "98/100",
      summary: "Comprehensive security assessment covering network infrastructure, application security, and data protection measures. All critical vulnerabilities have been addressed.",
      findings: {
        critical: 0,
        high: 1,
        medium: 3,
        low: 7,
        resolved: 11
      },
      keyFindings: [
        "Strong encryption implementation across all data transmission",
        "Robust access control mechanisms with multi-factor authentication",
        "Effective monitoring and logging systems in place",
        "Minor recommendations for enhanced API rate limiting"
      ]
    },
    {
      id: "2024-Q2",
      title: "Q2 2024 Blockchain Security Review",
      auditor: "BlockChain Auditors Inc",
      date: "June 20, 2024",
      type: "Blockchain Audit",
      status: "Completed",
      score: "96/100",
      summary: "Detailed review of smart contracts, consensus mechanisms, and blockchain infrastructure security. All smart contracts passed security validation.",
      findings: {
        critical: 0,
        high: 0,
        medium: 2,
        low: 5,
        resolved: 7
      },
      keyFindings: [
        "Smart contracts demonstrate excellent security practices",
        "Consensus mechanism properly implemented and secure",
        "Blockchain data integrity verification successful",
        "Recommendations for gas optimization implemented"
      ]
    },
    {
      id: "2024-Q1",
      title: "Q1 2024 Infrastructure Assessment",
      auditor: "SecureCloud Partners",
      date: "March 10, 2024",
      type: "Infrastructure Audit",
      status: "Completed",
      score: "94/100",
      summary: "Comprehensive evaluation of cloud infrastructure, server security, and network architecture. Strong security posture with minor optimization opportunities.",
      findings: {
        critical: 0,
        high: 2,
        medium: 4,
        low: 8,
        resolved: 14
      },
      keyFindings: [
        "Cloud infrastructure properly configured and secured",
        "Network segmentation effectively implemented",
        "Backup and disaster recovery procedures validated",
        "Enhanced monitoring capabilities recommended and implemented"
      ]
    }
  ];

  const upcomingAudits = [
    {
      title: "Q4 2024 Comprehensive Security Review",
      auditor: "Global Security Firm",
      scheduledDate: "December 2024",
      type: "Full Security Assessment",
      scope: "Complete platform security evaluation including new features"
    },
    {
      title: "Annual Compliance Audit",
      auditor: "Compliance Partners LLC",
      scheduledDate: "January 2025",
      type: "Regulatory Compliance",
      scope: "GDPR, CCPA, and industry-specific compliance verification"
    }
  ];

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical':
        return 'text-error bg-error/10';
      case 'high':
        return 'text-warning bg-warning/10';
      case 'medium':
        return 'text-accent bg-accent/10';
      case 'low':
        return 'text-success bg-success/10';
      default:
        return 'text-text-secondary bg-muted';
    }
  };

  const getScoreColor = (score) => {
    const numScore = parseInt(score);
    if (numScore >= 95) return 'text-success';
    if (numScore >= 85) return 'text-primary';
    if (numScore >= 75) return 'text-warning';
    return 'text-error';
  };

  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-headline text-3xl lg:text-4xl font-bold text-text-primary mb-4">
            Security Audits & Transparency
          </h2>
          <p className="text-lg text-text-secondary max-w-3xl mx-auto">
            Regular third-party security audits ensure our platform maintains the highest security standards. All audit results are published transparently.
          </p>
        </div>

        {/* Audit Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <div className="bg-card rounded-xl p-6 border border-border text-center">
            <div className="text-3xl font-bold text-success mb-2">12</div>
            <div className="text-sm text-text-secondary">Audits Completed</div>
          </div>
          <div className="bg-card rounded-xl p-6 border border-border text-center">
            <div className="text-3xl font-bold text-primary mb-2">96.7</div>
            <div className="text-sm text-text-secondary">Average Score</div>
          </div>
          <div className="bg-card rounded-xl p-6 border border-border text-center">
            <div className="text-3xl font-bold text-success mb-2">0</div>
            <div className="text-sm text-text-secondary">Critical Issues</div>
          </div>
          <div className="bg-card rounded-xl p-6 border border-border text-center">
            <div className="text-3xl font-bold text-accent mb-2">100%</div>
            <div className="text-sm text-text-secondary">Issues Resolved</div>
          </div>
        </div>

        {/* Recent Audit Reports */}
        <div className="mb-16">
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8">
            Recent Audit Reports
          </h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Audit List */}
            <div className="space-y-4">
              {auditReports?.map((audit, index) => (
                <div
                  key={audit?.id}
                  onClick={() => setSelectedAudit(index)}
                  className={`p-4 rounded-lg border cursor-pointer transition-smooth ${
                    selectedAudit === index
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50 bg-card'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-text-primary">{audit?.title}</h4>
                    <span className={`text-2xl font-bold ${getScoreColor(audit?.score)}`}>
                      {audit?.score}
                    </span>
                  </div>
                  <p className="text-sm text-text-secondary mb-2">{audit?.auditor}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-text-secondary">{audit?.date}</span>
                    <span className="px-2 py-1 bg-success/10 text-success text-xs rounded-full">
                      {audit?.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Audit Details */}
            <div className="lg:col-span-2">
              <div className="bg-card rounded-xl p-8 border border-border">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h4 className="font-headline text-xl font-semibold text-text-primary mb-2">
                      {auditReports?.[selectedAudit]?.title}
                    </h4>
                    <p className="text-text-secondary">
                      {auditReports?.[selectedAudit]?.auditor} • {auditReports?.[selectedAudit]?.date}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className={`text-3xl font-bold ${getScoreColor(auditReports?.[selectedAudit]?.score)}`}>
                      {auditReports?.[selectedAudit]?.score}
                    </div>
                    <div className="text-sm text-text-secondary">Security Score</div>
                  </div>
                </div>

                <p className="text-text-secondary mb-6 leading-relaxed">
                  {auditReports?.[selectedAudit]?.summary}
                </p>

                {/* Findings Summary */}
                <div className="mb-6">
                  <h5 className="font-semibold text-text-primary mb-4">Findings Summary</h5>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(auditReports?.[selectedAudit]?.findings)?.map(([severity, count]) => (
                      <div key={severity} className="text-center">
                        <div className={`text-2xl font-bold ${getSeverityColor(severity)?.split(' ')?.[0]}`}>
                          {count}
                        </div>
                        <div className="text-xs text-text-secondary capitalize">{severity}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Findings */}
                <div className="mb-6">
                  <h5 className="font-semibold text-text-primary mb-4">Key Findings</h5>
                  <ul className="space-y-2">
                    {auditReports?.[selectedAudit]?.keyFindings?.map((finding, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <Icon name="Check" size={16} className="text-success mt-1 flex-shrink-0" />
                        <span className="text-text-secondary text-sm">{finding}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex space-x-4">
                  <Button variant="outline" size="sm">
                    <Icon name="Download" size={16} className="mr-2" />
                    Download Report
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Icon name="ExternalLink" size={16} className="mr-2" />
                    View Details
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Upcoming Audits */}
        <div>
          <h3 className="font-headline text-2xl font-semibold text-text-primary mb-8">
            Upcoming Security Audits
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {upcomingAudits?.map((audit, index) => (
              <div key={index} className="bg-card rounded-xl p-6 border border-border">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name="Calendar" size={24} className="text-accent" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-text-primary mb-2">{audit?.title}</h4>
                    <p className="text-sm text-text-secondary mb-3">{audit?.scope}</p>
                    <div className="space-y-1">
                      <div className="text-xs text-text-secondary">
                        <strong>Auditor:</strong> {audit?.auditor}
                      </div>
                      <div className="text-xs text-text-secondary">
                        <strong>Scheduled:</strong> {audit?.scheduledDate}
                      </div>
                      <div className="text-xs text-text-secondary">
                        <strong>Type:</strong> {audit?.type}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SecurityAudits;