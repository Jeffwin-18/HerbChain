import React from 'react';
import Icon from '../../../components/AppIcon';

const CommunityStats = ({ stats }) => {
  const statItems = [
    {
      icon: 'Users',
      label: 'Active Members',
      value: stats?.activeMembers,
      change: stats?.memberGrowth,
      color: 'text-primary'
    },
    {
      icon: 'MessageCircle',
      label: 'Total Posts',
      value: stats?.totalPosts,
      change: stats?.postGrowth,
      color: 'text-accent'
    },
    {
      icon: 'Shield',
      label: 'Verified Farmers',
      value: stats?.verifiedFarmers,
      change: stats?.farmerGrowth,
      color: 'text-success'
    },
    {
      icon: 'Award',
      label: 'Expert Contributors',
      value: stats?.experts,
      change: stats?.expertGrowth,
      color: 'text-warning'
    }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Icon name="BarChart3" size={20} className="text-primary" />
        <h3 className="font-headline font-semibold text-lg text-text-primary">
          Community Stats
        </h3>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {statItems?.map((item, index) => (
          <div key={index} className="text-center p-4 rounded-lg bg-muted/50">
            <div className={`inline-flex items-center justify-center w-12 h-12 rounded-full bg-background mb-3 ${item?.color}`}>
              <Icon name={item?.icon} size={24} />
            </div>
            
            <div className="font-headline font-bold text-2xl text-text-primary mb-1">
              {item?.value}
            </div>
            
            <div className="text-sm text-text-secondary mb-2">
              {item?.label}
            </div>
            
            <div className="flex items-center justify-center space-x-1 text-xs text-success">
              <Icon name="TrendingUp" size={12} />
              <span>+{item?.change}% this month</span>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between text-sm">
          <span className="text-text-secondary">Last updated:</span>
          <span className="text-text-primary font-medium">
            {new Date()?.toLocaleDateString()}
          </span>
        </div>
      </div>
    </div>
  );
};

export default CommunityStats;